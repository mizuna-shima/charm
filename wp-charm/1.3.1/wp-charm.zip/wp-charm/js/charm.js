/*!
 * Charm.js ver 3.6.1
 * Charm.js License (Revised January 14, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/charm/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */

class Charm {
  /**** 設定項目ここから ---------------------------- ****/

  // 登録する名前の入力フォームアイテム共通Class
  static nameClass = "charm";
  // 入力の自動保存のClass名
  static syncNow = "charmnow";
  // 入力の自動保存のClass名（一時保存）
  static syncNowSession = "charmnowsession";
  // 登録ボタンのId
  static setNameId = "charmset";
  // 一時登録ボタンのId
  static setSessionId = "charmsession";
  // 削除ボタンのId
  static unsetNameId = "charmunset";
  // 一時登録の表記をするid
  static viewRegisterSession = "charmsessionmsg";
  // 一時保存の際に表示できるメッセージ
  static sessionString = "（一時保存しました）";
  // localStorageまたはsessionStorageの保存キー
  static storageKeyName = "charm";
  // 簡易暗号化 使う:1 使わない:0
  static useEncryption = 0;
  // 登録できる最大文字数 オーバーした文字は「…」で登録
  // 無制限にする場合は0
  static maxSize = 50;
  // 登録または一時登録ボタンで名前登録時にページを再読み込み
  // する:1 しない:0
  static setReload = 0;
  // 名前削除時にページを再読み込み（自動保存も含む）
  // する:1 しない:0
  static unsetReload = 0;
  // Web Storageが使えないとき ウィンドウを出す:1 出さない:0
  static showStorageError = 0;
  // 響き（欠けた名前を連呼する）回数のデフォルト
  static echoCountDefault = 2;
  // 詰まり回数のデフォルト
  static sttCountDefault = 2;
  // クラスモード使用時に設定するクラス名
  static charmClassList = {
    // 名前省略
    charmShort: "charm_short",
    // 先頭文字スキップ
    charmSkip: "charm_skip",
    // 末尾カット
    charmChop: "charm_chop",
    // 最後の文字
    charmLast: "charm_last",
    // 区切り
    charmParse: "charm_pause",
    // 響き
    charmEcho: "charm_echo",
    // 重複
    charmOverlap: "charm_overlap",
    // 詰まり
    charmStutter: "charm_stutter",
    // 逆順
    charmRev: "charm_rev",
    // ひらがな
    charmHira: "charm_hira",
    // カタカナ
    charmKana: "charm_kana",
    // カナMix
    charmMix: "charm_mix",
    // 最後の母音
    charmVowel: "charm_vowel",
    // 最後の母音（小さい文字）
    charmVowelMin: "charm_vowel_min",
    // イニシャル
    charmInitial: "charm_initial",
    // 記号設定の共通
    charmSymbol: "charm_symbol",
    // 回数設定の共通
    charmCount: "charm_count",
  };

  /** v1.2以前の設定 **/
  // 登録・削除ボタンのId
  static oldSet = "charm-setname";
  static oldUnset = "charm-unsetname";

  /**** 設定項目ここまで ---------------------------- ****/

  /** 本体起動 **/
  static run() {
    const runner = globalThis?.CharmRunner;
    if (typeof runner?.start === "function") {
      runner.start();
    } else {
      console.warn("CharmRunner is not available.");
    }
  }
  static addExtension(name, ex) {
    CharmRunner.addExtension(name, ex);
  }
  static addEExtension(name, ex) {
    CharmRunner.addEExtension(name, ex);
  }
}

if (typeof window !== "undefined") {
  window.Charm = Charm;
}

!function(){"use strict";class t{static#t;static#s=null;static#i=!1;static t(){this.#t=this.#h(this.i,100),this.#s=document.getElementsByClassName(Charm.nameClass),this.#i=this.#e(),this.#a(),this.h(),this.o(),this.l()}static h(){[{m:Charm.setNameId,u:Charm.oldSet,p:()=>this.C("local")},{m:Charm.setSessionId,u:null,p:()=>this.C("session")},{m:Charm.unsetNameId,u:Charm.oldUnset,p:this.S}].forEach((({m:t,u:s,p:i})=>{let h=document.getElementById(t);!h&&s&&(h=document.getElementById(s)),h&&(h.removeEventListener("click",i,!1),h.addEventListener("click",i,!1))}))}static o(){const t=document.getElementsByClassName(Charm.syncNow),s=document.getElementsByClassName(Charm.boundSession),i=this.#t,h=t=>{for(const s of[...t])for(const t of["input","compositionend"])s.removeEventListener(t,i,!1),s.addEventListener(t,i,!1)};h(t),h(s)}static#h(t,s){let i;return(...h)=>{i&&clearTimeout(i),i=setTimeout((()=>{t.apply(this,h)}),s)}}static#r(){for(const t of this.#s)!t||t.value.length<1||(CharmStorage.k={v:t.id,value:t.value})}static l(){[...this.#s].forEach((t=>{t.id in CharmStorage.k?t.value=CharmStorage.k[t.id]:t.value=t.defaultValue??""}))}static C(t){this.#r(),CharmStorage.I(CharmStorage.T[t]),this.l(),1===Charm.setReload&&location.reload()}static O(){this.C("local")}static M(){this.C("session")}static S(){CharmStorage.R(),t.l(),Charm.unsetReload&&location.reload()}static async i(s){const i=s.target,h=i.classList.contains(Charm.syncNow),e=i.id,a=i.value;if(""!==a)return CharmStorage.k={v:e,value:a,N:!0,L:h},void t.l();a||CharmStorage.A(e,h)}static#e(){const t=document.querySelector("script[data-charm-unset-reload]");return t?.hasAttribute("data-charm-unset-reload")||1===Charm.unsetReload}static B(t=null){this.#i&&(this.#a(t),location.reload())}static#a(t=null){if(this.#i)if("string"==typeof t)sessionStorage.setItem("focusId",t);else{const t=sessionStorage.getItem("focusId"),s=document.getElementById(t);s&&s.focus(),sessionStorage.removeItem("focusId")}}}class s{static#n="C3D1A4F7B6E2A5B8C9D1F2A3B7E6F4D9";static#c=BigInt("0x"+this.#n.match(/.{1,4}/g).reverse().join(""));static#o={};static#l=!0;static#m="";static#u=!1;static T=Object.freeze({$:!0,session:!1});static t(){this.#m=this.#d(),this.#p()}static#d(){const t=document.querySelector("script[data-charm-storage]");return t?.getAttribute("data-charm-storage")??Charm.storageKeyName}static#p(){let t=null,s=null;try{t=localStorage.getItem(this.#m),t||(t=sessionStorage.getItem(this.#m),this.#l=!t,s=!!t)}catch(s){this.#C(s),t=null}t?(t=JSON.parse(t),t&&"object"==typeof t||(t={})):t={},s&&(TextRenderer.D(!0),this.#l=this.T.session),this.#o=this.j(t)}static F(){this.#o={}}static I(t=this.T.$,s=null){if(TextRenderer.update(s),0===Object.keys(this.#o).length)return;let i=t?localStorage:sessionStorage,h=t?sessionStorage:localStorage;this.#l=t;let e=this.#o;e=this.j(e);try{i.setItem(this.#m,JSON.stringify(e)),h.removeItem(this.#m)}catch(t){this.#C(t)}finally{TextRenderer.D(!this.#l)}Charm.setReload&&!this.#u&&location.reload()}static R(){this.F(),TextRenderer.ini();try{localStorage.removeItem(this.#m),sessionStorage.removeItem(this.#m)}catch(t){this.#C(t)}finally{TextRenderer.D(!1)}}static get k(){return this.#o}static set k({v:t,value:s,N:i=!1,L:h=!0}){let e=s;Charm.maxSize&&e.length>Charm.maxSize&&(e=e.slice(0,Charm.maxSize)+"…"),t&&void 0!==e&&(this.#o[t]=e),this.#u=i,i&&this.I(h,t)}static A(t,s=!0){delete this.#o[t],TextRenderer.K(t);let i=null;Object.keys(this.#o).length?(i=t,this.I(s)):this.R(),CharmInput.B(i)}static#C(t){let s="その他のエラーが発生しました";t instanceof DOMException&&"QuotaExceededError"===t.name?s="ローカルストレージの容量がいっぱいです。名前変換は行わずにデフォルトネームを表示します。":t instanceof DOMException&&"SecurityError"===t.name&&(s="セキュリティ設定によりローカルストレージが使用できません。名前変換は行わずにデフォルトネームを表示します。"),Charm.showStorageError&&!this.#u&&alert(s),console.warn(s,t)}static j(t={}){return Charm.useEncryption?Object.fromEntries(Object.entries(t).map((([t,s])=>[t,this.#f(s)]))):t}static#f(t){if(!Charm.useEncryption)return t;const s=this.#c;return Array.from(t,((t,i)=>String.fromCharCode(t.charCodeAt(0)^Number(s>>(BigInt(31&i)<<2n)&0xffn)))).join("")}}class i{static H=Object.freeze(["&#8230;&#8230;","&#8230;","&#12540;","&#8213;&#8213;","&#12336;&#12336;","&#12336;","&#12316;","&#65281;","&#65281;&emsp;","&#65311;","&#65311;&emsp;","&#63;","&#33;","&#12289;","&#12290;","&#12539;","&#44;","&#65292;","&#8741;","&#47;","&#65295;","&#9675;&#9675;","&#9675;","&#215;&#215;","&#215;","&#9734;&#9734;","&#9734;","&#9733;&#9733;","&#9733;","&#9825;&#9825;","&#9825;","&#9734;&emsp;","&#9733;&emsp;","&#9825;&emsp;","&#9834;","&#9834;&emsp;","&#65281;&#65311;","&#65281;&#65311;&emsp;","&#x3063;","&#x3063;&#65281;","&#x3063;&#65281;&emsp;","&#x3063;&#12289;","&#x3063;&#8230;&#8230;","&#x30c3;","&#x30c3;&#65281;","&#x30c3;&#65281;&emsp;","&#x30c3;&#12289;","&#x30c3;&#8230;&#8230;"]);static#g="&#12289;";static#S="&#8230;&#8230;";static get P(){return this.#g}static get V(){return this.#S}}globalThis.CharmInput=t,globalThis.CharmRunner=class{static J=[];static U=[];static G={};static Z={};static async start(){await this.Y(),CharmStorage.t(),CharmInput.t(),TextRenderer.t(),await this.W()}static addExtension(t,s){this.G[t]=s,this.J.push(t)}static addEExtension(t,s){this.Z[t]=s,this.U.push(t)}static async q(t,s){for(const i of t){const t=s[i];t?.run instanceof Function&&await t.run()}}static async Y(){await this.q(this.J,this.G)}static async W(){await this.q(this.U,this.Z)}},globalThis.CharmStorage=s,globalThis.CUtil=i,globalThis.CustomOptions=class{#x;#y;#k;#v;#I;constructor(t,s){this.#x=t,this.#y=s,this.#k={short:!1,skip:!1,chop:!1,last:!1,stutter:!1,pause:!1,echo:!1,rev:!1,overlap:!1,vowel:!1,ini:!1,hira:!1,kana:!1,mix:!1},this.#v={count:void 0,symbol:void 0,vowelMin:!1},this.#I={short:this.#E.bind(this),skip:this.#b.bind(this),chop:this.#T.bind(this),last:this.#w.bind(this),stutter:this.#O.bind(this),pause:this.#M.bind(this),echo:this.#R.bind(this),rev:this.#N.bind(this),overlap:this.#L.bind(this),vowel:this.#A.bind(this),initial:this.#B.bind(this)},this.#$()}get custom(){return{expression:this.#k,option:this.#v}}#$(){for(const t in this.#I)if(this.#I[t]())break;this.#D(),this.#j(),this.#F()}#K(){const t=Charm.charmClassList.charmCount,s=[...Array(9)].findIndex(((s,i)=>this.#y.contains(`${t}${i+1}`)));return-1!==s?s+1:null}#H(){const t=Charm.charmClassList.charmSymbol,s=[...Array(48)].findIndex(((s,i)=>{const h=(i+1).toString().padStart(2,"0");return this.#y.contains(`${t}${h}`)||this.#y.contains(`${t}${i+1}`)}));return-1!==s?i.H[s]:null}#E(){if(this.#x.charmShort)this.#v.count=+this.#x.charmShort||1;else{if(!this.#y.contains(Charm.charmClassList.charmShort))return!1;this.#v.count=this.#K()||1}return this.#k.short=!0,!0}#P(t,s,i){return!(!this.#x[s]&&!this.#y.contains(Charm.charmClassList[i]))&&(this.#k[t]=!0,!0)}#b(){return this.#P("skip","charmSkip","charmSkip")}#T(){return this.#P("chop","charmChop","charmChop")}#w(){return this.#P("last","charmLast","charmLast")}#N(){return this.#P("rev","charmRev","charmRev")}#B(){return this.#P("initial","charmInitial","charmInitial")}#O(){return!("stutter"!==this.#x.charmCall&&!this.#y.contains(Charm.charmClassList.charmStutter))&&(this.#k.stutter=!0,"stutter"===this.#x.charmCall&&(this.#v.count=+this.#x.charmSttCount||Charm.sttCountDefault,this.#v.symbol=this.#x.charmBreak||i.P),this.#y.contains(Charm.charmClassList.charmStutter)&&(this.#v.count=this.#K()||Charm.sttCountDefault,this.#v.symbol=this.#H()||i.P),!0)}#M(){if("pause"===this.#x.charmCall)this.#v.symbol=this.#x.charmBreak||i.V;else{if(!this.#y.contains(Charm.charmClassList.charmParse))return!1;this.#v.symbol=this.#H()||i.V}return this.#k.pause=!0,!0}#R(){return!("echo"!==this.#x.charmCall&&!this.#y.contains(Charm.charmClassList.charmEcho))&&(this.#k.echo=!0,"echo"===this.#x.charmCall&&(this.#v.count=+this.#x.charmEchCount||Charm.echoCountDefault,this.#v.symbol=this.#x.charmBreak||i.V),this.#y.contains(Charm.charmClassList.charmEcho)&&(this.#v.count=this.#K()||Charm.echoCountDefault,this.#v.symbol=this.#H()||i.V),!0)}#L(){if(!this.#x.charmOverlap&&!this.#y.contains(Charm.charmClassList.charmOverlap))return!1;this.#k.overlap=!0;return this.#x.charmOverlap&&(this.#v.count=+this.#x.charmOvlCount||2),this.#y.contains(Charm.charmClassList.charmOverlap)&&(this.#v.count=this.#K()||2),!0}#A(){return!!(this.#x.charmVowel||this.#y.contains(Charm.charmClassList.charmVowel)||this.#x.charmVowelMin||this.#y.contains(Charm.charmClassList.charmVowelMin))&&(this.#k.vowel=!0,(this.#x.charmVowelMin||this.#y.contains(Charm.charmClassList.charmVowelMin))&&(this.#v.vowelMin=!0),this.#x.charmVowelCount?(this.#v.count=+this.#x.charmVowelCount||0,!0):(this.#v.count=this.#K()||0,!0))}#V(t,s,i){const h=this.#x[s];return!("on"!==h&&"1"!==h&&!this.#y.contains(Charm.charmClassList[i]))&&(this.#k[t]=!0,!0)}#D(){return this.#V("hira","charmHira","charmHira")}#j(){return this.#V("kana","charmKana","charmKana")}#F(){return this.#V("mix","charmMix","charmMix")}},globalThis.NameGeneration=class{#J;#U;#G;#Z;#Y;#z;constructor(t,s){this.#J=s.expression,this.#U=s.option,this.#G=t,this.#Z=t,this.#Y=[],this.#z={short:this.X.bind(this),skip:this._.bind(this),chop:this.tt.bind(this),last:this.st.bind(this),stutter:this.it.bind(this),pause:this.ht.bind(this),echo:this.et.bind(this),rev:this.rt.bind(this),overlap:this.nt.bind(this),vowel:this.ct.bind(this),initial:this.ot.bind(this),hira:this.lt.bind(this),kana:this.ut.bind(this),mix:this.dt.bind(this)},this.Ct()}get ft(){return this.#Z}Ct(){this.gt(),Object.keys(this.#J).forEach((t=>{if(this.#J[t]){const s=this.#z[t];"function"==typeof s&&s()}}))}gt(t=null){const s=t??this.#G,i=/[ぁぃぅぇぉゕゖっゃゅょゎァィゥェォヵㇰヶㇱㇲッㇳㇴㇵㇶㇷㇸㇹㇺャュョㇻㇼㇽㇾㇿヮｧｨｩｪｫｬｭｮｯ・ー]/,h=[];let e=0;for(;e<s.length;){let t=s[e];for(e++;e<s.length&&i.test(s[e]);)t+=s[e],e++;h.push(t)}if(t)return h;this.#Y=h}X(){const{count:t}=this.#U,s=this.#Y;if(t>=s.length)return void(this.#Z=s.join(""));const i=s.slice(0,t);i[t-1]=i[t-1].replace(/[っッーｯ・]/g,""),this.#Z=i.join("")}_(){this.#Y.shift(),this.#Z=this.#Y.join("")}tt(){this.#Y.pop(),this.#Z=this.#Y.join("")}st(){this.#Z=this.#Y[this.#Y.length-1]}it(){const{count:t,symbol:s}=this.#U,i=this.#Y[0]+s;this.#Z=i.repeat(t).slice(0,-s.length)}ht(){this.#Z=this.#Y.join(this.#U.symbol)}et(){const{count:t,symbol:s}=this.#U,i=this.#Y,h=[];for(let s=Math.min(t,i.length-1);s>0;s--)h.unshift(i.slice(-s).join(""));this.#Z=h.join(s)+s}rt(){this.#Z=this.#Y.reverse().join("")}nt(){this.#Z=this.#Y.map((t=>t.repeat(this.#U.count))).join("")}ct(){const t=["あ","ア","い","イ","う","ウ","え","エ","お","オ"],s=["ぁ","ァ","ぃ","ィ","ぅ","ゥ","ぇ","ェ","ぉ","ォ"],i=new Map([["あかさたなはまやらわがざだばぱゃぁゕゎ",0],["アカサタナハマヤラワガザダナパァヵㇵャㇻヮ",1],["いきしちにひみりゐぎじぢびぃヰ",2],["イキシチニヒミリギジヂビィㇱㇶㇼ",3],["うくすつぬふむゆるぐずづぶぷゅぅっ",4],["ウクスヌヌフムユルグズヅブプュゥㇰㇲッㇴㇷㇽ",5],["えけせてねへめれゑげぜでべぺぇゖ",6],["エケセテネヘメレゲゼデベペェヶㇸㇾ",7],["おこそとのほもよろをごぞどぼぽょぉ",8],["オコソトノホモヨロヲゴゾドボポョォㇳㇹㇺㇿ",9],["んー〜～〰ン",-1]]),h=this.#G.slice(-1),e=this.#U,a=Math.max(1,e.count??1),r=!e.vowelMin;for(const[e,n]of i)if(new RegExp(`[${e}]$`).test(h)){if(n>=0){const i=r?t[n]:s[n];this.#Z=i.repeat(a)}else this.#Z=h.repeat(a);return}this.#Z=""}ot(){const t=this.#Y[0].charAt(0);if(/^[a-zA-Zａ-ｚＡ-Ｚ]/.test(t))return void(this.#Z=t.normalize("NFKC").toUpperCase());if(!/^[ぁ-ゟァ-ヿ]/.test(t))return void(this.#Z="");const s=[[/^[がぎぐげごガギグゲゴ]/,"G"],[/^[ざじずぜぞザジズゼゾ]/,t=>/[じジ]/.test(t[0])?"J":"Z"],[/^[だぢでどダヂデド]/,t=>/[ぢヂ]/.test(t[0])?"J":"D"],[/^[づヅ]/,"Z"],[/^[ばびぶべぼバビブベボ]/,"B"],[/^[ぱぴぷぺぽパピプペポ]/,"P"],[/^[ゔヴ]/,"V"],[/^[あぁアァ]/,"A"],[/^[いぃイィゐヰ]/,"I"],[/^[うぅウゥ]/,"U"],[/^[えぇエェゑヱ]/,"E"],[/^[おぉオォ]/,"O"],[/^[か-こカ-コヵ]/,"K"],[/^[さ-そサ-ソ]/,"S"],[/^[た-とタ-ト]/,t=>/[ちチ]/.test(t[0])?"C":"T"],[/^[な-のナ-ノ]/,"N"],[/^[は-ほハ-ホ]/,t=>/[ふフ]/.test(t[0])?"F":"H"],[/^[ま-もマ-モ]/,"M"],[/^[ゃ-よャ-ヨ]/,"Y"],[/^[ら-ろラ-ロ]/,"R"],[/^[わをワヲ]/,"W"],[/^[んン]/,"N"]];for(const[i,h]of s){const s=t.match(i);if(s)return void(this.#Z="function"==typeof h?h(s):h)}this.#Z=""}St(t){return t.replace(/[ァ-ヶ]/g,(t=>String.fromCharCode(t.charCodeAt(0)-96)))}xt(t){return t.replace(/[ぁ-ゖ]/g,(t=>String.fromCharCode(t.charCodeAt(0)+96)))}lt(){this.#Z=this.St(this.#Z)}ut(){this.#Z=this.xt(this.#Z)}dt(){const t=this.gt(this.#Z);this.#Z=t.map(((t,s)=>s%2==0?this.xt(t):this.St(t))).join("")}},globalThis.TextRenderer=class{static#Q="data-charm-before";static#W={};static#q={};static t(){this.ini(),this.update()}static ini(){this.yt(),this.#W=[],this.#q={}}static update(t=null){if(t)return this.#q[t]=document.getElementsByClassName(t),void this.#X(t);this.#_()}static#_(){let t=CharmStorage.k;for(const s in t)t.hasOwnProperty(s)&&(this.#q[s]=document.getElementsByClassName(s),this.#X(s))}static#X(t){const s=this.#q[t];this.#W[t]||(this.#W[t]=[]);for(let i=0;i<s.length;i++){const h=s[i];if(!h.getAttribute(`${this.#Q}`)){const s=h.textContent;this.#W[t].includes(s)||this.#W[t].push(s);const i=this.#W[t].indexOf(s);h.setAttribute(this.#Q,i)}const e=CharmStorage.k[t];this.#tt(h,e)}}static#tt(t,s){let i=s;const h=new CustomOptions(t.dataset,t.classList);i=new NameGeneration(s,h.custom).ft,this.kt(t,i)}static yt(){let t=this.#W;for(const s in t)t.hasOwnProperty(s)&&this.K(s)}static K(t){if(!this.#W[t])return;const s=document.querySelectorAll(`.${t}[${this.#Q}]`);this.vt(s,t)}static vt(t,s){t.forEach((t=>{const i=parseInt(t.getAttribute(`${this.#Q}`));this.kt(t,this.#W[s][i]),t.removeAttribute(this.#Q)}))}static D(t=!0){let s=document.getElementById(Charm.viewRegisterSession);s&&(s.textContent=t?Charm.sessionString:"")}static kt(t,s){if(!t)return void console.warn("safelySetText: 無効な要素が渡されました");const i=(new DOMParser).parseFromString(s,"text/html");t.textContent=i.body.textContent||""}},document.addEventListener("DOMContentLoaded",(()=>{try{window.Charm?.run()}catch(t){console.error("Charm.run() failed:",t)}}))}();


/*! - 拡張用コードは以下に追記するか、外部ファイルとしてcharm.jsの後に読み込み - */