<?php
/*
Plugin Name: WP Charm
Plugin URI: https://lanama.net/
Description: 名前変換スクリプトCharm.jsをWordPress全てのページで読み込みます。
Version: 1.3.1
Author: 島ミズナ
Author URI: https://lanama.net/
License: Custom License
*/

/*!
 * Charm.js
 * Charm.js License (Revised January 14, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/charm/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */


// 直接アクセスを防止
if (!defined('ABSPATH')) {
    exit;
}

// 管理メニューにカスタムページを追加
add_action('admin_menu', 'wp_charm_menu');
function wp_charm_menu() {
    add_menu_page(
        'WP Charm',             // ページのタイトル
        'WP Charm',             // メニューのタイトル
        'manage_options',       // 必要な権限
        'wp-charm',             // メニューのスラッグ
        'wp_charm_page',        // メニューがクリックされたときの関数
        plugin_dir_url(__FILE__) . 'admin/icon.png',  // アイコン画像のURL
        100                      // メニューの表示位置（設定よりも下）
    );
}

// プラグイン一覧に設定リンクを追加
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wp_charm_action_links');
function wp_charm_action_links($links) {
    $settings_link = '<a href="admin.php?page=wp-charm">' . __('Settings') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// 管理ページのコンテンツ
function wp_charm_page() {
    include plugin_dir_path(__FILE__) . 'admin/editor-page.php';
}

// フォーム送信を処理
add_action('admin_post_save_wp_charm', 'save_wp_charm');
function save_wp_charm() {
    try {
        // Nonceを確認
        if (!isset($_POST['wp_charm_nonce']) || !wp_verify_nonce($_POST['wp_charm_nonce'], 'save_wp_charm')) {
            throw new Exception('Nonceの確認に失敗しました。');
        }

        // ユーザー権限を確認
        if (!current_user_can('manage_options')) {
            throw new Exception('権限が不足しています。');
        }

        // charm.jsファイルに保存
        if (isset($_POST['charm_js'])) {
            $charm_js = wp_unslash($_POST['charm_js']);
            file_put_contents(plugin_dir_path(__FILE__) . 'js/charm.js', mb_convert_encoding($charm_js, 'UTF-8', 'auto'));
        }

        // charm_extension.jsファイルに保存
        if (isset($_POST['charm_extension_js'])) {
            $charm_extension_js = wp_unslash($_POST['charm_extension_js']);
            file_put_contents(plugin_dir_path(__FILE__) . 'js/charm_extension.js', mb_convert_encoding($charm_extension_js, 'UTF-8', 'auto'));
        }

        // 成功メッセージ
        wp_safe_redirect(admin_url('admin.php?page=wp-charm&message=success'));
        exit;
    } catch (Exception $e) {
        // エラーメッセージ
        wp_safe_redirect(admin_url('admin.php?page=wp-charm&message=error'));
        exit;
    }
}

// フロントでカスタムJSを読み込む
add_action('wp_enqueue_scripts', 'enqueue_wp_charm_js');
function enqueue_wp_charm_js() {
    // 現在の日付を取得してパラメータとして追加
    $today = date('Ymd');
    $charm_js_url = plugins_url('js/charm.js', __FILE__) . '?ver=' . $today;
    $charm_extension_js_url = plugins_url('js/charm_extension.js', __FILE__) . '?ver=' . $today;

    wp_enqueue_script('charm-js', $charm_js_url, array(), null, true);
    wp_enqueue_script('charm-extension-js', $charm_extension_js_url, array('charm-js'), null, true);
}

// カスタムCSSを追加してアイコンを調整
add_action('admin_enqueue_scripts', 'wp_charm_admin_styles');
function wp_charm_admin_styles() {
    wp_enqueue_style('wp_charm_admin_css', plugins_url('admin/wp-charm-admin.css', __FILE__));
}
?>
