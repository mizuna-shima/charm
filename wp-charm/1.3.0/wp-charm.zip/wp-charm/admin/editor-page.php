<?php
// 直接アクセスを防止
if (!defined('ABSPATH')) {
    exit;
}

// charm.jsの現在のコンテンツを読み込む
$charm_js_path = plugin_dir_path(__FILE__) . '../js/charm.js';
$charm_js = file_exists($charm_js_path) ? mb_convert_encoding(file_get_contents($charm_js_path), 'UTF-8', 'auto') : '';

// charm_extension.jsの現在のコンテンツを読み込む
$charm_extension_js_path = plugin_dir_path(__FILE__) . '../js/charm_extension.js';
$charm_extension_js = file_exists($charm_extension_js_path) ? mb_convert_encoding(file_get_contents($charm_extension_js_path), 'UTF-8', 'auto') : '';

// メッセージの表示
if (isset($_GET['message'])) {
    if ($_GET['message'] == 'success') {
        echo '<div class="notice notice-success is-dismissible"><p>ファイルが正常に保存されました。</p></div>';
    } elseif ($_GET['message'] == 'error' && isset($_GET['error'])) {
        echo '<div class="notice notice-error is-dismissible"><p>エラーが発生しました: ' . esc_html($_GET['error']) . '</p></div>';
    } else {
        echo '<div class="notice notice-error is-dismissible"><p>エラーが発生しました。</p></div>';
    }
}
?>
<div class="wrap">
  <h1>WP Charm Editor</h1>
  <br>
  <p>Charm.jsはインストール直後の初期状態でも通常は問題なく使用することができます。<br>
  登録項目の追加やカスタム変換をする場合でも、スクリプトの編集は不要です。<br>
  項目の追加やカスタム変換の使い方は配布サイトをご確認ください。</p>
  <a href="https://lanama.net/scripts/charm/" target="_blank">
      <img src="<?php echo plugins_url('admin/banner_charm.png', dirname(__FILE__)); ?>" alt="Charm.js" style="width: 200px; height: 40px;">
  </a>
  <br>
  <p>バージョン変更や設定を変更する場合は、以下からスクリプトファイルを直接編集し、保存してください。</p>
  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
    <input type="hidden" name="action" value="save_wp_charm">
    <?php wp_nonce_field('save_wp_charm', 'wp_charm_nonce'); ?>
      <h2>charm.js</h2>
      <textarea name="charm_js" rows="20" cols="100" style="width: 100%;"><?php echo esc_textarea($charm_js); ?></textarea>
      <br>
      <p>拡張用コードは配布サイトの「More」ページの「Extension」から入手できます。<br>
      使いたい機能のコードを以下にペーストして保存してください。</p>
      <h2>charm_extension.js</h2>
      <textarea name="charm_extension_js" rows="20" cols="100" style="width: 100%;"><?php echo esc_textarea($charm_extension_js); ?></textarea>
    <?php submit_button('保存する'); ?>
  </form>
  <p>エラーが発生して保存ができないときは、FTPアプリ等を使用して新しいファイルを直接アップロードしてください。</p>
</div>
