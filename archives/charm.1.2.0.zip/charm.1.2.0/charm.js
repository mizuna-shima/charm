/*
  charm.js v1.2
  (C)2021 https://lanama.net 
  島ミズナ

  ■ Read Me このスクリプトについて

  このスクリプトは一定のルールのもと使用することが可能です。
  ルールをお守り頂ければ、ご使用者様ご自身でスクリプトを改修して運用することも可能です。

  改修している／していないにかかわらず、↓のルールを必ず確認、厳守してください。

  1.制作者（島ミズナ）の表記と、Read me（このファイルの17行目まで）を変更しないでください。
  2.公序良俗に反する使い方、成人向けサイトではしないでください
  3.スクリプト単体での再配布はしないでください。
  4.このスクリプトをご使用になって損害が生じても島ミズナは責を負いません。
*/

{
  // 登録する名前の入力エリア共通Class
  const nameClass = 'charm';
  // 登録ボタン
  const setname = document.getElementById('charm-setname');
  // 削除ボタン
  const unsetname = document.getElementById('charm-unsetname');
  // Cookieが使えない環境の場合にアラートを表示する（1で表示、0で表示しない）
  const canViewAlert = 1;
  // Cookie
  let allCookie;
  // 登録した名前
  let charm = [];
  // 響き（欠けた名前を連呼する）回数のデフォルト
  let echoCountDefault = 2;
  // 詰まり回数のデフォルト
  let sttCountDefault = 2;

  /**
   * Cookieに名前を登録する
   *    名前登録イベントで呼び出して使用
   */
  const setCookie =()=> {
    // cookieが使えるか確認
    if (!checkCanCookie()) {
      return false;
    }

    // 有効期限
    let expiration = 30; // 日数
    let date = new Date().getTime();
    let expire = new Date(date + (60 * 60 * 24 * 1000 * expiration));

    // 入力要素を取得
    let nameItems = document.getElementsByClassName(nameClass);
    
    // nameClassで指定したclassをもっている要素（input想定）のループ
    // 指定classの数だけループして id = value のペアをcookieにセット
    for (let i = 0; i < nameItems.length; i++) {
      let name = nameItems[i];
      // 入力エリアから取得した情報をエンコードしてセット
      let setRow = encodeURIComponent(name.id) + '=' + encodeURIComponent(name.value) + '; path=/; expires=' + expire.toUTCString() + ';';
      document.cookie = setRow;
    }

    return true;
  };

  /**
   * Cookieを使えるか判定、設定に応じてalertを出す
   * @return {boolean}     Cookieを使用できるか
   */
  function checkCanCookie() {

    let isCookie = true;
    // cookieが使えるか確認
    if (!navigator.cookieEnabled) { 
      isCookie = false;
    }

    if (!isCookie && canViewAlert) {
      alert('ご使用中の環境ではお名前登録できません。\n別の環境でお試しください。');
    }

    return isCookie;
  };

  /**
   * Cookieに登録してある名前を削除
   *    名前削除イベントで呼び出して使用
   */
  const unsetCookie =()=> {
    if (allCookie == '') {
      return;
    }

    // 入力エリア削除処理
    let nameItems = document.getElementsByClassName(nameClass);
    // 指定classの数だけループして id = value のペアをcookieにセット
    for (let i = 0; i < nameItems.length; i++) {
      let name = nameItems[i];
      name.value = '';
    }

    // cookie削除処理
    charm = [];
    // [; ]区切りで配列にする
    let namelist = allCookie.split('; '); 
    // 有効期限に過去日付を指定
    let date = new Date();
    date.setTime(date.getTime() - 60 * 60 * 24 * 1000);

    for (let i = 0; i < namelist.length; i++) {
      // [=]区切りで配列にする
      let pair = namelist[i].split('=');  
      // 空の情報をcookieにセット
      document.cookie = decodeURIComponent(pair[0]) + '=; path=/; expires=' + date.toUTCString();

      if (i == namelist.length - 1) {
        location.reload(true);
      }
    }
  };
  

  /**
   * Cookie登録してある名前を取得する
   *    viewName()から呼び出して使用
   */
  const readName = () => {

    allCookie = document.cookie;

    // Cookie登録してなければ終了
    if (allCookie == '') {
      return false;
    }
    // [; ]区切りで配列にする
    let namelist = allCookie.split('; '); 

    // 名前の個数分ループ
    for (let i = 0; i < namelist.length; i++) {
      // [=]区切りで配列にする
      let pair = namelist[i].split('=');  
      // エンコード前の文字列を配列にセット
      charm[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
    }
  }
  

  /**
   * 登録内容を表示する
   *    Cookie登録してある名前をreadName()経由で取得し、
   *    登録されていれば置換メソッドreplace()をループで実行
   * @param {boolean} deleteFlg 
   */
  const viewName = (deleteFlg = false) => {

    readName();

    // 名前が登録されているとき
    if (allCookie != '') {
      // 上部で定義した登録した名前の配列charmをループ処理
      for (key in charm) {
        replace(key, charm[key]);
        setFormName(key);
      }
    }
  }


  /**
   * 入力フォームに登録内容を挿入する
   * @param {String} key Cookieの登録key名 
   */
  const setFormName = (key) => {

    let formItem = document.getElementById(key);

    // keyの入力フォームが取得できないときはスキップ
    if (!formItem) {
      return;
    }
    
    formItem.value = charm[key];
  };


  /**
   * 名前置換メインメソッド
   *    表示メソッドviewName()から呼び出して使用
   *    置換先要素を取得、設定に合わせた置換処理を通して置換先要素にセットする
   * @param {String} key  登録情報配列のkey
   * @param {String} name 登録情報配列のvalue
   */
  const replace = (key, name) => {

    if (!name) {
      return;
    }

    // 置換する名前要素を取得
    let exeKey = document.getElementsByClassName(key);

    // 登録名を置き換え
    for (let j = 0; j < exeKey.length; j++) {
    
      // 区切った名前配列
      let splitName = nameSplit(name);
      let rName = name;

      // 名前省略指定のとき
      if (exeKey[j].dataset.charmShort) {
        let num = parseInt(exeKey[j].dataset.charmShort);
        // 名前文字列をカット
        splitName = replaceShortArray(splitName, num);
        rName = splitName.join('');
      }

      // 区切り指定のとき
      if (exeKey[j].dataset.charmCall === 'pause') {
        let pauseString =  exeKey[j].dataset.charmBreak ? exeKey[j].dataset.charmBreak : '……';
        rName = splitName.join(pauseString);
      }

      // 響き指定のとき
      if (exeKey[j].dataset.charmCall === 'echo') {
        // 響きの区切り文字
        let echoString = exeKey[j].dataset.charmBreak ? exeKey[j].dataset.charmBreak : '……';
        // 響き回数
        let echoCount = parseInt(exeKey[j].dataset.charmEchCount);
        echoCount = echoCount ? echoCount : echoCountDefault;
        rName = replaceEcho(splitName, echoString, echoCount);
      }

      // 詰まり指定のとき
      if (exeKey[j].dataset.charmCall === 'stutter') {
        // 詰まりの区切り文字
        let pauseString =  exeKey[j].dataset.charmBreak ? exeKey[j].dataset.charmBreak : '、';
        // 詰まり回数
        let stutterCount = parseInt(exeKey[j].dataset.charmSttCount);
        stutterCount = stutterCount ? stutterCount : sttCountDefault;
        rName = replaceStutter(splitName[0], pauseString, stutterCount);
      }
      
      // カタカナ変換指定のとき（最後に処理）
      if (exeKey[j].dataset.charmKana === 'on') {
        rName = replaceKana(rName);
      }
      
      exeKey[j].innerHTML = rName;
    }
  };


  /**
   * 名前を自然な区切りの配列にして返す
   *    小さい「ぁ」や「っ」など、1文字で使用しない文字を考慮して区切る
   *    「あいうえお」   ->  ['あ', 'い', 'う', 'え', 'お']
   *    「しゃしゅ」    ->  ['しゃ', 'しゅ']
   * @param {String} name
   * @return {Array}     自然な区切り位置で分割した名前配列
   */
  const nameSplit = (name) => {

    // 1文字ずつ分割
    let before = name.split('');

    // 返却する自然な区切りの配列
    let splitName = [];

    for (let i = 0; i < before.length; i++) {
      let pushString = before[i];

      for (let j = i + 1; j < before.length; j++) {
        // 次の文字が小さな文字と一部の記号だったら
        if (before[j].match(/[ぁぃぅぇぉゕゖっゃゅょゎァィゥェォヵㇰヶㇱㇲッㇳㇴㇵㇶㇷㇸㇹㇺャュョㇻㇼㇽㇾㇿヮｧｨｩｪｫｬｭｮｯ・ー]/g)) {
          // 前の区切りに含める
          pushString += before[j];
          // メインループで被らないように文字key進める
          i++;
        } else {
          break;
        }
      }
      splitName.push(pushString);
    }
    return splitName;
  };


  /**
   * 名前の文字配列を減らす
   *    指定の文字列を、指定の数に丸めて配列で返す（末尾が[っ][ッ]の場合は削除）
   * @param   {Array}   splitName  名前文字配列
   * @param   {integer} num        減らした結果の文字数（デフォルトあり）
   * @return  {String}             減らした結果の文字配列
   */
  const replaceShortArray = (splitName, num) => {

    // 名前の文字数が、指定文字数より小さいときは処理終了
    if (splitName.length < num) {
      return splitName;
    }

    let result = [];

    for (let i = 0; i < num; i++) {

      // 最後の配列
      if (i === num - 1) {
        // [っ][ッ][ー][・]を削除
        splitName[i] = splitName[i].replace(/[\u3063|\u30c3|\u30FC|ｯ|・]/, '');
      }
      // 配列を結果にセット
      result.push(splitName[i]);
    }

    return result;
  };


  /**
   * 指定の組み合わせと回数で配列の名前を区切り、響きを返す
   * 
   * @param   {Array}     name        響きに使用する名前配列
   * @param   {String}    echoString  区切りの間に挿入する文字列（デフォルトあり）
   * @param   {integer}   echoCount   欠けた名前を連呼する回数（デフォルトあり）
   * @return  {String}                響き文字列
   */
  const replaceEcho = (name, echoString, echoCount) => {

    // 返却文字列
    let result = echoString;

    // 名前の文字数と、指定の響き回数の小さい方に合わせる
    if (name.length - 1 > echoCount) {
      count = echoCount;
    } else {
      count = name.length - 1;
    }

    // 呼びかけられる回数
    for (let i = 1; i <= count; i++) {
      // 名前の自然な文字数分ループ
      for (let j = 0; j < name.length; j++) {
        // 呼ぶ合計数から呼んだ回数を引いて、それより大きいkeyをその呼びかけにセットする
        if (j > count - i) {
          result += name[j];
        }
      }

      // 呼びかけ回数1巡　区切り文字で区切る
      result += echoString;
    }

    return result;
  };


  /**
   * 指定の組み合わせと回数で配列の名前を区切り、詰まり文字列を返す
   * 
   * @param   {String}      sttName       詰まりに使用する名前1区切り
   * @param   {String}      sttPause      詰まりに使用する区切り文字列
   * @param   {integer}     stutterCount  どもらせる回数（デフォルトあり）
   * @return  {String}                    詰まり文字列
   */
  const replaceStutter = (sttName, pauseString, stutterCount) => {

    let result = '';

    for (let i = 0; i < stutterCount; i++) {

      if (i !== stutterCount - 1) {
        result += sttName + pauseString;
      } else {
        result += sttName;
      }
    }
    return result;
  };


  /**
   * ひらがな → カタカナ変換
   *    受け取った文字列のひらがな部分をカタカナに置換して返す
   * @param   {String}  name  名前文字列
   * @return  {String}        ひらがなをカタカナに置換した名前文字列
   */
  const replaceKana = (name) => {

    // 当てはまるものを置換してreturn
    return name.replace(/[\u3041-\u3096]/g, function (match) {
      let chr = match.charCodeAt(0) + 0x60;
      return String.fromCharCode(chr);
    });      
  };

  
  // 読み込み後実行処理
  
  // 登録ボタンと削除ボタンがあるとき
  if (setname != null && unsetname != null) {

    // 名前を表示（表示前に取得処理あり）
    viewName(); 

    // 登録イベント
    setname.addEventListener('click', function() {
      if(setCookie()) {
        viewName();
      }
    }, false);

    // 削除イベント
    unsetname.addEventListener('click', function() {
      unsetCookie();
      viewName(true);
    }, false);

  } else { // ボタンがない　=> 読み取り専用

    // 名前を表示（表示前に取得処理あり）
    viewName(); 
  }
}


