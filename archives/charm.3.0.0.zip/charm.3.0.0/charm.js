/*!
 * Charm.js License (Revised January 14, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/charm/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */

// Charm.js ver 3.0.0

class Charm {

  /**** 設定変更可能 ここから ****/

  // 登録する名前の入力フォームアイテム共通Class
  static nameClass = 'charm';
  // 登録ボタンのId
  static setNameId = 'charmset';
  // 一時登録ボタンのId
  static setSessionId = 'charmsession';
  // 削除ボタンのId
  static unsetNameId = 'charmunset';
  // 一時登録の表記をするid
  static viewRegistSession = 'charmsessionmsg';
  // 一時保存の際に表示できるメッセージ
  static sessionString = '（一時保存しました）';
  // localStorageまたはsessionStorageの保存キー
  static storageKeyName = 'charm';
  // 登録できる最大文字数
  // オーバーした文字は「…」で登録されます。この機能を使用しない場合は0を設定
  static maxSize = 50;
  // 名前登録時にページを再読み込みをするかどうか
  // 再読み込みをする場合は1、再読み込みをしない場合は0を設定
  static setReload = 0;
  // 名前削除時にページを再読み込みをするかどうか
  // 再読み込みをする場合は1、再読み込みをしない場合は0を設定
  static unsetReload = 1;
  // 名前登録時、ブラウザの設定で「Web Storage」が使えないときにウィンドウを出すかどうか
  // 出す場合は1を設定
  static showStorageError = 0;
  // 響き（欠けた名前を連呼する）回数のデフォルト
  static echoCountDefault = 2;
  // 詰まり回数のデフォルト
  static sttCountDefault = 2;
  // クラスモード使用時に設定するクラス名
  static charmClassList = {
    // 名前省略
    charmShort : 'charm_short',
    // 先頭文字スキップ
    charmSkip : 'charm_skip',
    // 末尾カット
    charmChop : 'charm_chop',
    // 最後の文字
    charmLast : 'charm_last',
    // 区切り
    charmParse : 'charm_pause',
    // 響き
    charmEcho : 'charm_echo',
    // 重複
    charmOverlap : 'charm_overlap',
    // 詰まり
    charmStutter : 'charm_stutter',
    // カタカナ変換
    charmKana : 'charm_kana',
    // 最後の母音
    charmVowel : 'charm_vowel',
    // 最後の母音（小さい文字）
    charmVowelMin : 'charm_vowel_min',
    // 記号設定の共通部分
    charmSymbol : 'charm_symbol',
    // 回数設定の共通部分
    charmCount : 'charm_count',
  }
  // クラスモード使用時に設定する記号
  static symbols = [
    '&#8230;&#8230;', // ……
    '&#8230;', // …
    '&#12540;', // ー
    '&#8213;&#8213;', // ――
    '&#12336;&#12336;', // 〰〰
    '&#12336;', // 〰
    '&#12316;', // 〜
    '&#65281;', // ！
    '&#65281;&emsp;', // ！　（！とスペース）
    '&#65311;', // ？
    '&#65311;&emsp;', // ？　（？とスペース）
    '&#63;', // 半角の「?」
    '&#33;', // 半角の「!」
    '&#12289;', // 、
    '&#12290;', // 。
    '&#12539;', // ・
    '&#44;', // ,
    '&#65292;', // ，
    '&#8741;', // ∥
    '&#47;', // /
    '&#65295;', // ／
    '&#9675;&#9675;', // ○○
    '&#9675;', // ○
    '&#215;&#215;', // ××
    '&#215;', // ×
    '&#9734;&#9734;', // ☆☆
    '&#9734;', // ☆
    '&#9733;&#9733;', // ★★
    '&#9733;', // ★
    '&#9825;&#9825;', // ♡♡
    '&#9825;', // ♡
    '&#9734;&emsp;', // ☆（☆とスペース）
    '&#9733;&emsp;', // ★（★とスペース）
    '&#9825;&emsp;', // ♡（♡とスペース）
    '&#9834;', // ♪
    '&#9834;&emsp;', // ♪（♪とスペース）
    '&#65281;&#65311;', // ！？
    '&#65281;&#65311;&emsp;', // ！？（！？とスペース）
    '&#x3063;', // 「っ」
    '&#x3063;&#65281;', // 「っ！」
    '&#x3063;&#65281;&emsp;', //「っ！　」
    '&#x3063;&#12289;', // 「っ、」
    '&#x3063;&#8230;&#8230;', // 「っ……」
    '&#x30c3;', // 「ッ」
    '&#x30c3;&#65281;', // 「ッ！」
    '&#x30c3;&#65281;&emsp;', //「ッ！　」
    '&#x30c3;&#12289;', // 「ッ、」
    '&#x30c3;&#8230;&#8230;', // 「ッ……」
  ];

  /** v1.2以前の設定ここから **/

  // 登録ボタンのId
  static oldSetName = 'charm-setname';
  // 削除ボタンのId
  static oldUnsetName = 'charm-unsetname';

  /**** 設定変更可能 ここまで 以降の行はシステム部分のため、触らないでください ****/

static strStutter="&#12289;";static strPauseEcho="&#8230;&#8230;";static attributeBeforeName="data-charm-before";constructor(){this.symbol={},this.charm={},this.tmpCharm={},this.isSession=!1,this.beforeList=[]}static run=()=>{let t=new Charm;return t.start(),t};start=()=>{let t=[{newId:Charm.setNameId,oldId:Charm.oldSetName,handler:this.setNameHandler(!0)},{newId:Charm.setSessionId,oldId:null,handler:this.setNameHandler(!1)},{newId:Charm.unsetNameId,oldId:Charm.oldUnsetName,handler:this.unsetNameHandler}];t.forEach(({newId:t,oldId:e,handler:s})=>{let a=document.getElementById(t);!a&&e&&(a=document.getElementById(e)),a&&(a.removeEventListener("click",s,!1),a.addEventListener("click",s,!1))}),this.viewName()};unsetStorage=()=>{let t=document.getElementsByClassName(Charm.nameClass);if(Array.from(t).forEach(t=>{t.value=""}),this.charm||this.tmpCharm){try{localStorage.removeItem(Charm.storageKeyName),sessionStorage.removeItem(Charm.storageKeyName)}catch(e){alert("Web Storageを利用できません。")}Charm.unsetReload?location.reload(!0):this.resetElements(),this.beforeList=[]}};resetElements=()=>{let t=document.querySelectorAll(`[${this.attributeBeforeName}]`);t.forEach(t=>{let e=parseInt(t.getAttribute(`${this.attributeBeforeName}`));this.writeText(t,this.beforeList[e]),t.removeAttribute(this.attributeBeforeName)});document.getElementById(Charm.viewRegistSession).textContent="",this.beforeList=this.charm=this.tmpCharm={}};setNameHandler=t=>()=>{this.setStorage(t)&&this.viewName()};unsetNameHandler=()=>{this.unsetStorage()};setStorage=(t=!0)=>{let e=document.getElementsByClassName(Charm.nameClass),s={};Array.from(e).forEach(t=>{if(!t||t.value.length<1)return;let e=t.value;Charm.maxSize&&e.length>Charm.maxSize&&(e=e.slice(0,Charm.maxSize)+"…"),s[t.id]=this.tmpCharm[t.id]=encodeURIComponent(e)});try{let a=t?localStorage:sessionStorage,h=t?sessionStorage:localStorage;a.setItem(Charm.storageKeyName,JSON.stringify(s)),h.removeItem(Charm.storageKeyName),Charm.setReload&&location.reload(!0)}catch(i){Charm.showStorageError&&alert("Web Storageを利用できません。ブラウザの設定を確認してください。")}return!0};viewName=()=>{if(this.readName(),this.charm){for(let t in this.charm)this.replaceEdit(t,this.charm[t]),this.setFormName(t);this.setSessionMessage()}};replaceEdit(t,e){if(!e)return;let s=Array.from(document.getElementsByClassName(t));s.forEach(t=>{let s=t.dataset,a=t.classList,h=new CustomOptions(s,a),i=new NameGeneration(e,h),r=i.generateName;this.setBeforeStrIndex(t),this.writeText(t,r)})}writeText=(t,e)=>{let s=new DOMParser,a=s.parseFromString(e,"text/html"),h=a.body.textContent||"";t.textContent=h};setBeforeStrIndex=t=>{if(Charm.unsetReload)return;let e=t.getAttribute(this.attributeBeforeName);if(null===e||""===e){let s=this.beforeList.length;this.beforeList[s]=t.textContent,t.setAttribute(this.attributeBeforeName,s)}};readName=()=>{this.isSession=!1;let t=null,e;try{(t=JSON.parse(localStorage.getItem(Charm.storageKeyName)))||(t=JSON.parse(sessionStorage.getItem(Charm.storageKeyName)),this.isSession=!!t)}catch(s){if(e=Object.keys(this.tmpCharm),!t&&e.length<1)return;!t&&e.length>0&&e.forEach(t=>this.charm[t]=decodeURIComponent(this.tmpCharm[t]));return}null!==t&&Object.keys(t).forEach(e=>this.charm[e]=decodeURIComponent(t[e]))};setSessionMessage=()=>{let t=document.getElementById(Charm.viewRegistSession);null!==t&&(this.isSession?t.textContent=Charm.sessionString:t.textContent="")};setFormName=t=>{let e=document.getElementById(t);e&&(e.value=this.charm[t])}}class CustomOptions{static checkMethods=["checkShort","checkSkip","checkChop","checkLast","checkStutter","checkPause","checkEcho","checkOverlap","checkVowel"];constructor(t,e){return this.dataset=t,this.classList=e,this.custom={expression:{short:!1,skip:!1,chop:!1,last:!1,stutter:!1,pause:!1,echo:!1,overlap:!1,vowel:!1,kana:!1},option:{count:void 0,symbol:void 0,vowelMin:!1}},this.executeChecks()}executeChecks=()=>{for(let t of CustomOptions.checkMethods)if("function"==typeof this[t]&&this[t]())break;return this.checkKana(),this.custom};getClassCount=()=>{let t=Charm.charmClassList.charmCount,e=[...Array(9)].findIndex((e,s)=>this.classList.contains(`${t}${s+1}`));return -1!==e?e+1:null};getClassSymbol=()=>{let t=Charm.charmClassList.charmSymbol,e=[...Array(48)].findIndex((e,s)=>{let a=(s+1).toString().padStart(2,"0");return this.classList.contains(`${t}${a}`)||this.classList.contains(`${t}${s+1}`)});return -1!==e?Charm.symbols[e]:null};checkShort=()=>{if(this.dataset.charmShort)this.custom.option.count=+this.dataset.charmShort||1;else{if(!this.classList.contains(Charm.charmClassList.charmShort))return!1;this.custom.option.count=this.getClassCount()||1}return this.custom.expression.short=!0,!0};checkChop=()=>!!(this.dataset.charmChop||this.classList.contains(Charm.charmClassList.charmChop))&&(this.custom.expression.chop=!0,!0);checkLast=()=>!!(this.dataset.charmLast||this.classList.contains(Charm.charmClassList.charmLast))&&(this.custom.expression.last=!0,!0);checkSkip=()=>!!(this.dataset.charmSkip||this.classList.contains(Charm.charmClassList.charmSkip))&&(this.custom.expression.skip=!0,!0);checkStutter=()=>!!("stutter"===this.dataset.charmCall||this.classList.contains(Charm.charmClassList.charmStutter))&&(this.custom.expression.stutter=!0,"stutter"===this.dataset.charmCall&&(this.custom.option.count=+this.dataset.charmSttCount||Charm.sttCountDefault,this.custom.option.symbol=this.dataset.charmBreak||Charm.strStutter),this.classList.contains(Charm.charmClassList.charmStutter)&&(this.custom.option.count=this.getClassCount()||Charm.sttCountDefault,this.custom.option.symbol=this.getClassSymbol()||Charm.strStutter),!0);checkPause=()=>{if("pause"===this.dataset.charmCall)this.custom.option.symbol=this.dataset.charmBreak||Charm.strPauseEcho;else{if(!this.classList.contains(Charm.charmClassList.charmParse))return!1;this.custom.option.symbol=this.getClassSymbol()||Charm.strPauseEcho}return this.custom.expression.pause=!0,!0};checkEcho=()=>!!("echo"===this.dataset.charmCall||this.classList.contains(Charm.charmClassList.charmEcho))&&(this.custom.expression.echo=!0,"echo"===this.dataset.charmCall&&(this.custom.option.count=+this.dataset.charmEchCount||Charm.echoCountDefault,this.custom.option.symbol=this.dataset.charmBreak||Charm.strPauseEcho),this.classList.contains(Charm.charmClassList.charmEcho)&&(this.custom.option.count=this.getClassCount()||Charm.echoCountDefault,this.custom.option.symbol=this.getClassSymbol()||Charm.strPauseEcho),!0);checkOverlap=()=>!!(this.dataset.charmOverlap||this.classList.contains(Charm.charmClassList.charmOverlap))&&(this.custom.expression.overlap=!0,this.dataset.charmOverlap&&(this.custom.option.count=+this.dataset.charmOvlCount||2),this.classList.contains(Charm.charmClassList.charmOverlap)&&(this.custom.option.count=this.getClassCount()||2),!0);checkVowel=()=>!!(this.dataset.charmVowel||this.classList.contains(Charm.charmClassList.charmVowel)||this.dataset.charmVowelMin||this.classList.contains(Charm.charmClassList.charmVowelMin))&&((this.custom.expression.vowel=!0,(this.dataset.charmVowelMin||this.classList.contains(Charm.charmClassList.charmVowelMin))&&(this.custom.option.vowelMin=!0),this.dataset.charmVowelCount)?(this.custom.option.count=+this.dataset.charmVowelCount||0,!0):(this.custom.option.count=this.getClassCount()||0,!0));checkKana=()=>!!("on"===this.dataset.charmKana||"1"==this.dataset.charmKana||this.classList.contains(Charm.charmClassList.charmKana))&&(this.custom.expression.kana=!0,!0)}class NameGeneration{static custom={short:"generateShort",skip:"generateSkip",chop:"generateChop",last:"generateLast",stutter:"generateStutter",pause:"generatePause",echo:"generateEcho",overlap:"generateOverlap",vowel:"generateVowel",kana:"generateKana"};constructor(t,e){this.custom=e,this.name=t,this.generateName=t,this.splitName=[],this.vowels={},this.executeGenerate()}executeGenerate=()=>{this.nameSplit(),Object.keys(this.custom.expression).forEach(t=>{if(this.custom.expression[t]){let e=NameGeneration.custom[t];"function"==typeof this[e]&&this[e]()}})};nameSplit=()=>{let t=this.name,e=/[ぁぃぅぇぉゕゖっゃゅょゎァィゥェォヵㇰヶㇱㇲッㇳㇴㇵㇶㇷㇸㇹㇺャュョㇻㇼㇽㇾㇿヮｧｨｩｪｫｬｭｮｯ・ー]/,s=[],a=0;for(;a<t.length;){let h=t[a];for(a++;a<t.length&&e.test(t[a]);)h+=t[a],a++;s.push(h)}this.splitName=s};generateShort=()=>{let t=this.custom.option.count;if(t>=this.splitName.length){this.generateName=this.splitName.join("");return}let e=this.splitName.slice(0,t);e[t-1]=e[t-1].replace(/[\u3063\u30c3\u30FCｯ・]/g,""),this.generateName=e.join("")};generateChop=()=>{this.splitName.pop(),this.generateName=this.splitName.join("")};generateLast=()=>{this.generateName=this.splitName[this.splitName.length-1]};generateSkip=()=>{this.splitName.shift(),this.generateName=this.splitName.join("")};generateStutter=()=>{let t=this.custom.option.count,e=this.custom.option.symbol,s=this.splitName[0],a=Array(t).fill(s+e).join("");a=a.slice(0,-e.length),this.generateName=a};generatePause=()=>{this.generateName=this.splitName.join(this.custom.option.symbol)};generateEcho=()=>{let t=this.custom.option.symbol,e=this.splitName,s=Math.min(this.custom.option.count,e.length-1),a=[];for(let h=s;h>0;h--)a.push(e.slice(h).join(""));this.generateName=a.join(t)+t};generateOverlap=()=>{this.generateName=this.splitName.map(t=>t.repeat(this.custom.option.count)).join("")};generateVowel=()=>{let t=["あ","ア","い","イ","う","ウ","え","エ","お","オ"],e=["ぁ","ァ","ぃ","ィ","ぅ","ゥ","ぇ","ェ","ぉ","ォ"],s={あかさたなはまやらわがざだばぱゃぁゕゎ:0,アカサタナハマヤラワガザダナパァヵㇵャㇻヮ:1,いきしちにひみりゐぎじぢびぃヰ:2,イキシチニヒミリギジヂビィㇱㇶㇼ:3,うくすつぬふむゆるぐずづぶぷゅぅっ:4,ウクスヌヌフムユルグズヅブプュゥㇰㇲッㇴㇷㇽ:5,えけせてねへめれゑげぜでべぺぇゖ:6,エケセテネヘメレゲゼデベペェヶㇸㇾ:7,おこそとのほもよろをごぞどぼぽょぉ:8,オコソトノホモヨロヲゴゾドボポョォㇳㇹㇺㇿ:9,"んー〜ン":-1},a=this.splitName[this.splitName.length-1],h=this.custom.option.count?this.custom.option.count+1:1,i=!this.custom.option.vowelMin,r=!1;Object.entries(s).forEach(([s,o])=>{if(RegExp(`[${s}]$`).test(a)){if(o>=0){let m=i?t[o]:e[o];this.generateName=m.repeat(h)}else this.generateName=a.repeat(h);r=!0}}),r||(this.generateName="")};generateKana=()=>{this.generateName=this.generateName.replace(/[\u3041-\u3096]/g,t=>String.fromCharCode(t.charCodeAt(0)+96))}}

try {
  Charm.run();
} catch (error) {
  console.error('An error occurred while creating a Charm instance: ', error);
}
