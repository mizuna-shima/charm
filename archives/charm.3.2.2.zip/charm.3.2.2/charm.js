/*!
 * Charm.js ver 3.2.2
 * Charm.js License (Revised January 14, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/charm/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */

class Charm {

  /**** 設定変更可能 ここから ****/

  // 登録する名前の入力フォームアイテム共通Class
  static nameClass = 'charm';
  // 入力フォーム即時登録のClass名
  static syncNow = 'charmnow';
  // 入力フォーム即時登録のClass名（一時登録）
  static syncNowSession = 'charmnowsession';
  // 登録ボタンのId
  static setNameId = 'charmset';
  // 一時登録ボタンのId
  static setSessionId = 'charmsession';
  // 削除ボタンのId
  static unsetNameId = 'charmunset';
  // 一時登録の表記をするid
  static viewRegistSession = 'charmsessionmsg';
  // 一時保存の際に表示できるメッセージ
  static sessionString = '（一時保存しました）';
  // localStorageまたはsessionStorageの保存キー
  static storageKeyName = 'charm';
  // 簡易暗号化 使う:1 使わない:0
  static useEncryption = 0;
  // 登録できる最大文字数
  // オーバーした文字は「…」で登録されます。この機能を使用しない場合は0を設定
  static maxSize = 50;
  // 名前登録時にページを再読み込み する:1 しない:0
  static setReload = 0;
  // 名前削除時にページを再読み込み する:1 しない:0
  static unsetReload = 1;
  // 名前登録時、ブラウザの設定で「Web Storage」が使えないときにウィンドウを出すかどうか
  // 出す場合は1を設定
  static showStorageError = 0;
  // 響き（欠けた名前を連呼する）回数のデフォルト
  static echoCountDefault = 2;
  // 詰まり回数のデフォルト
  static sttCountDefault = 2;
  // クラスモード使用時に設定するクラス名
  static charmClassList = {
    // 名前省略
    charmShort : 'charm_short',
    // 先頭文字スキップ
    charmSkip : 'charm_skip',
    // 末尾カット
    charmChop : 'charm_chop',
    // 最後の文字
    charmLast : 'charm_last',
    // 区切り
    charmParse : 'charm_pause',
    // 響き
    charmEcho : 'charm_echo',
    // 重複
    charmOverlap : 'charm_overlap',
    // 詰まり
    charmStutter : 'charm_stutter',
    // 逆順
    charmRev : 'charm_rev',
    // ひらがな
    charmHira : 'charm_hira',
    // カタカナ
    charmKana : 'charm_kana',
    // カナMix
    charmMix : 'charm_mix',
    // 最後の母音
    charmVowel : 'charm_vowel',
    // 最後の母音（小さい文字）
    charmVowelMin : 'charm_vowel_min',
    // 記号設定の共通
    charmSymbol : 'charm_symbol',
    // 回数設定の共通
    charmCount : 'charm_count',
  }
  // クラスモード使用時の記号
  static symbols = [
    '&#8230;&#8230;', // ……
    '&#8230;', // …
    '&#12540;', // ー
    '&#8213;&#8213;', // ――
    '&#12336;&#12336;', // 〰〰
    '&#12336;', // 〰
    '&#12316;', // 〜
    '&#65281;', // ！
    '&#65281;&emsp;', // ！　（！とスペース
    '&#65311;', // ？
    '&#65311;&emsp;', // ？　（？とスペース
    '&#63;', // 半角の「?」
    '&#33;', // 半角の「!」
    '&#12289;', // 、
    '&#12290;', // 。
    '&#12539;', // ・
    '&#44;', // ,
    '&#65292;', // ，
    '&#8741;', // ∥
    '&#47;', // /
    '&#65295;', // ／
    '&#9675;&#9675;', // ○○
    '&#9675;', // ○
    '&#215;&#215;', // ××
    '&#215;', // ×
    '&#9734;&#9734;', // ☆☆
    '&#9734;', // ☆
    '&#9733;&#9733;', // ★★
    '&#9733;', // ★
    '&#9825;&#9825;', // ♡♡
    '&#9825;', // ♡
    '&#9734;&emsp;', // ☆（☆とスペース
    '&#9733;&emsp;', // ★（★とスペース
    '&#9825;&emsp;', // ♡（♡とスペース
    '&#9834;', // ♪
    '&#9834;&emsp;', // ♪（♪とスペース
    '&#65281;&#65311;', // ！？
    '&#65281;&#65311;&emsp;', // ！？（！？とスペース
    '&#x3063;', // 「っ」
    '&#x3063;&#65281;', // 「っ！」
    '&#x3063;&#65281;&emsp;', //「っ！　」
    '&#x3063;&#12289;', // 「っ、」
    '&#x3063;&#8230;&#8230;', // 「っ……」
    '&#x30c3;', // 「ッ」
    '&#x30c3;&#65281;', // 「ッ！」
    '&#x30c3;&#65281;&emsp;', //「ッ！　」
    '&#x30c3;&#12289;', // 「ッ、」
    '&#x30c3;&#8230;&#8230;', // 「ッ……」
  ];

  /** v1.2以前の設定 **/
  // 登録ボタンのId
  static oldSetName = 'charm-setname';
  // 削除ボタンのId
  static oldUnsetName = 'charm-unsetname';

  /**** 以降の行はシステム部分のため、触らないでください ****/
static strStutter="&#12289;";static strPauseEcho="&#8230;&#8230;";static beforeNameMap="data-charm-before";static eKey="C3D1A4F7B6E2A5B8C9D1F2A3B7E6F4D9";constructor(){this.charm={},this.tmpCharm={},this.isSession=!1,this.beforeList=[],this.xKey=BigInt("0x"+Charm.eKey.match(/.{1,4}/g).reverse().join("")),this.debouncedSetNameSyncHandler=this.debounce(this.setNameSyncHandler,100)}static run=()=>{let t=new Charm;return t.start(),t};start=()=>{[{newId:Charm.setNameId,oldId:Charm.oldSetName,handler:this.setLocalNameHandler},{newId:Charm.setSessionId,oldId:null,handler:this.setSessionNameHandler},{newId:Charm.unsetNameId,oldId:Charm.oldUnsetName,handler:this.unsetStorage}].forEach((({newId:t,oldId:e,handler:s})=>{let a=document.getElementById(t);!a&&e&&(a=document.getElementById(e)),a&&(a.removeEventListener("click",s,!1),a.addEventListener("click",s,!1))}));const t=document.getElementsByClassName(Charm.syncNow),e=document.getElementsByClassName(Charm.syncNowSession),s=this.debouncedSetNameSyncHandler,a=t=>{Array.from(t).forEach((t=>{t.removeEventListener("input",s,!1),t.addEventListener("input",s,!1),t.removeEventListener("compositionend",s,!1),t.addEventListener("compositionend",s,!1)}))};a(t),a(e),this.setFocus(),this.viewName()};storageError=(t,e=!1)=>{let s="その他のエラーが発生しました";t instanceof DOMException&&"QuotaExceededError"===t.name?s="ローカルストレージの容量がいっぱいです":t instanceof DOMException&&"SecurityError"===t.name&&(s="セキュリティ設定によりローカルストレージが使用できません"),Charm.showStorageError&&!e&&alert(s),console.warn(s,t)};unsetStorage=()=>{const t=document.getElementsByClassName(Charm.nameClass);if(Array.from(t).forEach((t=>{t.value=""})),this.charm||this.tmpCharm){try{localStorage.removeItem(Charm.storageKeyName),sessionStorage.removeItem(Charm.storageKeyName)}catch(t){this.storageError(t)}Charm.unsetReload?location.reload(!0):this.resetElements(),this.beforeList=[]}};resetElements=()=>{document.querySelectorAll(`[${Charm.beforeNameMap}]`).forEach((t=>{const e=parseInt(t.getAttribute(`${Charm.beforeNameMap}`));this.writeText(t,this.beforeList[e]),t.removeAttribute(Charm.beforeNameMap)}));let t=document.getElementById(Charm.viewRegistSession);t&&(t.textContent=""),this.beforeList=this.charm=this.tmpCharm={}};setLocalNameHandler=()=>{this.setStorage(!0,!1).then((()=>{this.viewName()}))};setSessionNameHandler=()=>{this.setStorage(!1,!1).then((()=>{this.viewName()}))};debounce=(t,e)=>{let s;return(...a)=>{s&&clearTimeout(s),s=setTimeout((()=>{t.apply(this,a)}),e)}};setNameSyncHandler=t=>{const e=t.target,s=e.classList.contains(Charm.syncNow),a=e.id;""===e.value?a in this.charm&&(delete this.charm[a],this.setStorage(s,!0).then((()=>{Object.keys(this.charm).length||this.unsetStorage(),this.saveFocus(),location.reload(!0)}))):this.setStorage(s,!0).then((()=>{this.viewName()}))};saveFocus=()=>{const t=document.activeElement;t&&"INPUT"===t.tagName&&sessionStorage.setItem("focusedElementId",t.id)};setFocus=()=>{const t=sessionStorage.getItem("focusedElementId");if(t){const e=document.getElementById(t);e&&e.focus(),sessionStorage.removeItem("focusedElementId")}};xTransform=t=>{if(!Charm.useEncryption)return t;const e=this.xKey;return t.split("").map(((t,s)=>{const a=Number(e>>BigInt(s%32*4)&BigInt(255));return String.fromCharCode(t.charCodeAt(0)^a)})).join("")};setNameObj=async t=>new Promise((e=>{let s={};Array.from(t).forEach((t=>{if(!t||t.value.length<1)return;let e=t.value;Charm.maxSize&&e.length>Charm.maxSize&&(e=e.slice(0,Charm.maxSize)+"…"),s[t.id]=this.tmpCharm[t.id]=encodeURIComponent(this.xTransform(e))})),e(s)}));readName=async()=>new Promise((t=>{this.isSession=!1;let e,s=null;try{s=JSON.parse(localStorage.getItem(Charm.storageKeyName)),s||(s=JSON.parse(sessionStorage.getItem(Charm.storageKeyName)),this.isSession=!!s)}catch(a){return e=Object.keys(this.tmpCharm),!s&&e.length<1?void t():(!s&&e.length>0&&e.forEach((t=>this.charm[t]=this.xTransform(decodeURIComponent(this.tmpCharm[t])))),void t())}null!==s?(Object.keys(s).forEach((t=>this.charm[t]=this.xTransform(decodeURIComponent(s[t])))),t()):t()}));setStorage=async(t=!0,e=!1)=>{let s=document.getElementsByClassName(Charm.nameClass),a=await this.setNameObj(s);return this.updateStorage(t,a,e),!0};updateStorage=(t,e,s)=>{try{let a=t?localStorage:sessionStorage,r=t?sessionStorage:localStorage;a.setItem(Charm.storageKeyName,JSON.stringify(e)),r.removeItem(Charm.storageKeyName),this.charm=e,Charm.setReload&&!s&&location.reload(!0)}catch(t){this.storageError(t)}};viewName=async()=>{if(await this.readName(),this.charm){for(const t in this.charm)this.replaceEdit(t,this.charm[t]),this.setFormName(t);this.setSessionMessage()}};replaceEdit(t,e){if(!e)return;Array.from(document.getElementsByClassName(t)).forEach((t=>{const s=t.dataset,a=t.classList,r=new CustomOptions(s,a),i=new NameGeneration(e,r).generateName;this.setBeforeStrIndex(t),this.writeText(t,i)}))}writeText=(t,e)=>{const s=(new DOMParser).parseFromString(e,"text/html").body.textContent||"";t.textContent=s};setBeforeStrIndex=t=>{if(Charm.unsetReload)return;const e=t.getAttribute(Charm.beforeNameMap);if(null===e||""===e){const e=this.beforeList.length;this.beforeList[e]=t.textContent,t.setAttribute(Charm.beforeNameMap,e)}};setSessionMessage=()=>{let t=document.getElementById(Charm.viewRegistSession);null!==t&&(this.isSession?t.textContent=Charm.sessionString:t.textContent="")};setFormName=t=>{let e=document.getElementById(t);e&&(e.value=this.charm[t])}}class CustomOptions{static checkMethods=["checkShort","checkSkip","checkChop","checkLast","checkStutter","checkPause","checkEcho","checkRev","checkOverlap","checkVowel"];constructor(t,e){return this.dataset=t,this.classList=e,this.custom={expression:{short:!1,skip:!1,chop:!1,last:!1,stutter:!1,pause:!1,echo:!1,rev:!1,overlap:!1,vowel:!1,hira:!1,kana:!1,mix:!1},option:{count:void 0,symbol:void 0,vowelMin:!1}},this.executeChecks()}executeChecks=()=>{for(const t of CustomOptions.checkMethods)if("function"==typeof this[t]&&this[t]())break;return this.checkHira(),this.checkKana(),this.checkMix(),this.custom};getClassCount=()=>{const t=Charm.charmClassList.charmCount,e=[...Array(9)].findIndex(((e,s)=>this.classList.contains(`${t}${s+1}`)));return-1!==e?e+1:null};getClassSymbol=()=>{const t=Charm.charmClassList.charmSymbol,e=[...Array(48)].findIndex(((e,s)=>{const a=(s+1).toString().padStart(2,"0");return this.classList.contains(`${t}${a}`)||this.classList.contains(`${t}${s+1}`)}));return-1!==e?Charm.symbols[e]:null};checkShort=()=>{if(this.dataset.charmShort)this.custom.option.count=+this.dataset.charmShort||1;else{if(!this.classList.contains(Charm.charmClassList.charmShort))return!1;this.custom.option.count=this.getClassCount()||1}return this.custom.expression.short=!0,!0};checkChop=()=>!(!this.dataset.charmChop&&!this.classList.contains(Charm.charmClassList.charmChop))&&(this.custom.expression.chop=!0,!0);checkLast=()=>!(!this.dataset.charmLast&&!this.classList.contains(Charm.charmClassList.charmLast))&&(this.custom.expression.last=!0,!0);checkSkip=()=>!(!this.dataset.charmSkip&&!this.classList.contains(Charm.charmClassList.charmSkip))&&(this.custom.expression.skip=!0,!0);checkStutter=()=>!("stutter"!==this.dataset.charmCall&&!this.classList.contains(Charm.charmClassList.charmStutter))&&(this.custom.expression.stutter=!0,"stutter"===this.dataset.charmCall&&(this.custom.option.count=+this.dataset.charmSttCount||Charm.sttCountDefault,this.custom.option.symbol=this.dataset.charmBreak||Charm.strStutter),this.classList.contains(Charm.charmClassList.charmStutter)&&(this.custom.option.count=this.getClassCount()||Charm.sttCountDefault,this.custom.option.symbol=this.getClassSymbol()||Charm.strStutter),!0);checkPause=()=>{if("pause"===this.dataset.charmCall)this.custom.option.symbol=this.dataset.charmBreak||Charm.strPauseEcho;else{if(!this.classList.contains(Charm.charmClassList.charmParse))return!1;this.custom.option.symbol=this.getClassSymbol()||Charm.strPauseEcho}return this.custom.expression.pause=!0,!0};checkEcho=()=>!("echo"!==this.dataset.charmCall&&!this.classList.contains(Charm.charmClassList.charmEcho))&&(this.custom.expression.echo=!0,"echo"===this.dataset.charmCall&&(this.custom.option.count=+this.dataset.charmEchCount||Charm.echoCountDefault,this.custom.option.symbol=this.dataset.charmBreak||Charm.strPauseEcho),this.classList.contains(Charm.charmClassList.charmEcho)&&(this.custom.option.count=this.getClassCount()||Charm.echoCountDefault,this.custom.option.symbol=this.getClassSymbol()||Charm.strPauseEcho),!0);checkRev=()=>!(!this.dataset.charmRev&&!this.classList.contains(Charm.charmClassList.charmRev))&&(this.custom.expression.rev=!0,!0);checkOverlap=()=>{if(!this.dataset.charmOverlap&&!this.classList.contains(Charm.charmClassList.charmOverlap))return!1;this.custom.expression.overlap=!0;return this.dataset.charmOverlap&&(this.custom.option.count=+this.dataset.charmOvlCount||2),this.classList.contains(Charm.charmClassList.charmOverlap)&&(this.custom.option.count=this.getClassCount()||2),!0};checkVowel=()=>!!(this.dataset.charmVowel||this.classList.contains(Charm.charmClassList.charmVowel)||this.dataset.charmVowelMin||this.classList.contains(Charm.charmClassList.charmVowelMin))&&(this.custom.expression.vowel=!0,(this.dataset.charmVowelMin||this.classList.contains(Charm.charmClassList.charmVowelMin))&&(this.custom.option.vowelMin=!0),this.dataset.charmVowelCount?(this.custom.option.count=+this.dataset.charmVowelCount||0,!0):(this.custom.option.count=this.getClassCount()||0,!0));checkHira=()=>{const t=this.dataset.charmHira;return!("on"!==t&&"1"!=t&&!this.classList.contains(Charm.charmClassList.charmHira))&&(this.custom.expression.hira=!0,!0)};checkKana=()=>{const t=this.dataset.charmKana;return!("on"!==t&&"1"!=t&&!this.classList.contains(Charm.charmClassList.charmKana))&&(this.custom.expression.kana=!0,!0)};checkMix=()=>{const t=this.dataset.charmMix;return!("on"!==t&&"1"!=t&&!this.classList.contains(Charm.charmClassList.charmMix))&&(this.custom.expression.mix=!0,!0)}}class NameGeneration{static custom={short:"generateShort",skip:"generateSkip",chop:"generateChop",last:"generateLast",stutter:"generateStutter",pause:"generatePause",echo:"generateEcho",rev:"generateRev",overlap:"generateOverlap",vowel:"generateVowel",hira:"generateHira",kana:"generateKana",mix:"generateMix"};constructor(t,e){this.custom=e,this.name=t,this.generateName=t,this.splitName=[],this.vowels={},this.executeGenerate()}executeGenerate=()=>{this.nameSplit(),Object.keys(this.custom.expression).forEach((t=>{if(this.custom.expression[t]){const e=NameGeneration.custom[t];"function"==typeof this[e]&&this[e]()}}))};nameSplit=()=>{const t=this.name,e=/[ぁぃぅぇぉゕゖっゃゅょゎァィゥェォヵㇰヶㇱㇲッㇳㇴㇵㇶㇷㇸㇹㇺャュョㇻㇼㇽㇾㇿヮｧｨｩｪｫｬｭｮｯ・ー]/;let s=[],a=0;for(;a<t.length;){let r=t[a];for(a++;a<t.length&&e.test(t[a]);)r+=t[a],a++;s.push(r)}this.splitName=s};generateShort=()=>{const t=this.custom.option.count;if(t>=this.splitName.length)return void(this.generateName=this.splitName.join(""));let e=this.splitName.slice(0,t);e[t-1]=e[t-1].replace(/[\u3063\u30c3\u30FCｯ・]/g,""),this.generateName=e.join("")};generateChop=()=>{this.splitName.pop(),this.generateName=this.splitName.join("")};generateLast=()=>{this.generateName=this.splitName[this.splitName.length-1]};generateSkip=()=>{this.splitName.shift(),this.generateName=this.splitName.join("")};generateStutter=()=>{const t=this.custom.option,e=t.count,s=t.symbol,a=this.splitName[0];let r=Array(e).fill(a+s).join("");r=r.slice(0,-s.length),this.generateName=r};generatePause=()=>{this.generateName=this.splitName.join(this.custom.option.symbol)};generateEcho=()=>{const t=this.custom.option,e=t.symbol,s=this.splitName;let a=[];for(let e=Math.min(t.count,s.length-1);e>0;e--)a.push(s.slice(e).join(""));this.generateName=a.join(e)+e};generateRev=()=>{this.generateName=this.splitName.reverse().join("")};generateOverlap=()=>{this.generateName=this.splitName.map((t=>t.repeat(this.custom.option.count))).join("")};generateVowel=()=>{const t=["あ","ア","い","イ","う","ウ","え","エ","お","オ"],e=["ぁ","ァ","ぃ","ィ","ぅ","ゥ","ぇ","ェ","ぉ","ォ"],s=this.splitName[this.splitName.length-1],a=this.custom.option,r=a.count?a.count+1:1,i=!a.vowelMin;let o=!1;Object.entries({"あかさたなはまやらわがざだばぱゃぁゕゎ":0,"アカサタナハマヤラワガザダナパァヵㇵャㇻヮ":1,"いきしちにひみりゐぎじぢびぃヰ":2,"イキシチニヒミリギジヂビィㇱㇶㇼ":3,"うくすつぬふむゆるぐずづぶぷゅぅっ":4,"ウクスヌヌフムユルグズヅブプュゥㇰㇲッㇴㇷㇽ":5,"えけせてねへめれゑげぜでべぺぇゖ":6,"エケセテネヘメレゲゼデベペェヶㇸㇾ":7,"おこそとのほもよろをごぞどぼぽょぉ":8,"オコソトノホモヨロヲゴゾドボポョォㇳㇹㇺㇿ":9,"んー〜ン":-1}).forEach((([a,h])=>{if(new RegExp(`[${a}]$`).test(s)){if(h>=0){const s=i?t[h]:e[h];this.generateName=s.repeat(r)}else this.generateName=s.repeat(r);o=!0}})),o||(this.generateName="")};hiraTransform=t=>t.replace(/[\u30A1-\u30F6]/g,(t=>String.fromCharCode(t.charCodeAt(0)-96)));kanaTransform=t=>t.replace(/[\u3041-\u3096]/g,(t=>String.fromCharCode(t.charCodeAt(0)+96)));generateHira=()=>{this.generateName=this.hiraTransform(this.generateName)};generateKana=()=>{this.generateName=this.kanaTransform(this.generateName)};generateMix=()=>{this.name=this.generateName,this.nameSplit(),this.generateName=this.splitName.map(((t,e)=>e%2==0?this.kanaTransform(t):this.hiraTransform(t))).join("")}}try{Charm.run()}catch(t){console.error("An error occurred while creating a Charm instance: ",t)}