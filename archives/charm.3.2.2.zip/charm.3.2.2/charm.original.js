/*!
 * Charm.js ver 3.2.2
 * Charm.js License (Revised January 14, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/charm/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */

class Charm {

  /**** 設定変更可能 ここから ****/

  // 登録する名前の入力フォームアイテム共通Class
  static nameClass = 'charm';
  // 入力フォーム即時登録のClass名
  static syncNow = 'charmnow';
  // 入力フォーム即時登録のClass名（一時登録）
  static syncNowSession = 'charmnowsession';
  // 登録ボタンのId
  static setNameId = 'charmset';
  // 一時登録ボタンのId
  static setSessionId = 'charmsession';
  // 削除ボタンのId
  static unsetNameId = 'charmunset';
  // 一時登録の表記をするid
  static viewRegistSession = 'charmsessionmsg';
  // 一時保存の際に表示できるメッセージ
  static sessionString = '（一時保存しました）';
  // localStorageまたはsessionStorageの保存キー
  static storageKeyName = 'charm';
  // 簡易暗号化 使う:1 使わない:0
  static useEncryption = 0;
  // 登録できる最大文字数
  // オーバーした文字は「…」で登録されます。この機能を使用しない場合は0を設定
  static maxSize = 50;
  // 名前登録時にページを再読み込み する:1 しない:0
  static setReload = 0;
  // 名前削除時にページを再読み込み する:1 しない:0
  static unsetReload = 1;
  // 名前登録時、ブラウザの設定で「Web Storage」が使えないときにウィンドウを出すかどうか
  // 出す場合は1を設定
  static showStorageError = 0;
  // 響き（欠けた名前を連呼する）回数のデフォルト
  static echoCountDefault = 2;
  // 詰まり回数のデフォルト
  static sttCountDefault = 2;
  // クラスモード使用時に設定するクラス名
  static charmClassList = {
    // 名前省略
    charmShort : 'charm_short',
    // 先頭文字スキップ
    charmSkip : 'charm_skip',
    // 末尾カット
    charmChop : 'charm_chop',
    // 最後の文字
    charmLast : 'charm_last',
    // 区切り
    charmParse : 'charm_pause',
    // 響き
    charmEcho : 'charm_echo',
    // 重複
    charmOverlap : 'charm_overlap',
    // 詰まり
    charmStutter : 'charm_stutter',
    // 逆順
    charmRev : 'charm_rev',
    // ひらがな
    charmHira : 'charm_hira',
    // カタカナ
    charmKana : 'charm_kana',
    // カナMix
    charmMix : 'charm_mix',
    // 最後の母音
    charmVowel : 'charm_vowel',
    // 最後の母音（小さい文字）
    charmVowelMin : 'charm_vowel_min',
    // 記号設定の共通
    charmSymbol : 'charm_symbol',
    // 回数設定の共通
    charmCount : 'charm_count',
  }
  // クラスモード使用時の記号
  static symbols = [
    '&#8230;&#8230;', // ……
    '&#8230;', // …
    '&#12540;', // ー
    '&#8213;&#8213;', // ――
    '&#12336;&#12336;', // 〰〰
    '&#12336;', // 〰
    '&#12316;', // 〜
    '&#65281;', // ！
    '&#65281;&emsp;', // ！　（！とスペース
    '&#65311;', // ？
    '&#65311;&emsp;', // ？　（？とスペース
    '&#63;', // 半角の「?」
    '&#33;', // 半角の「!」
    '&#12289;', // 、
    '&#12290;', // 。
    '&#12539;', // ・
    '&#44;', // ,
    '&#65292;', // ，
    '&#8741;', // ∥
    '&#47;', // /
    '&#65295;', // ／
    '&#9675;&#9675;', // ○○
    '&#9675;', // ○
    '&#215;&#215;', // ××
    '&#215;', // ×
    '&#9734;&#9734;', // ☆☆
    '&#9734;', // ☆
    '&#9733;&#9733;', // ★★
    '&#9733;', // ★
    '&#9825;&#9825;', // ♡♡
    '&#9825;', // ♡
    '&#9734;&emsp;', // ☆（☆とスペース
    '&#9733;&emsp;', // ★（★とスペース
    '&#9825;&emsp;', // ♡（♡とスペース
    '&#9834;', // ♪
    '&#9834;&emsp;', // ♪（♪とスペース
    '&#65281;&#65311;', // ！？
    '&#65281;&#65311;&emsp;', // ！？（！？とスペース
    '&#x3063;', // 「っ」
    '&#x3063;&#65281;', // 「っ！」
    '&#x3063;&#65281;&emsp;', //「っ！　」
    '&#x3063;&#12289;', // 「っ、」
    '&#x3063;&#8230;&#8230;', // 「っ……」
    '&#x30c3;', // 「ッ」
    '&#x30c3;&#65281;', // 「ッ！」
    '&#x30c3;&#65281;&emsp;', //「ッ！　」
    '&#x30c3;&#12289;', // 「ッ、」
    '&#x30c3;&#8230;&#8230;', // 「ッ……」
  ];

  /** v1.2以前の設定 **/
  // 登録ボタンのId
  static oldSetName = 'charm-setname';
  // 削除ボタンのId
  static oldUnsetName = 'charm-unsetname';

  /**** 以降の行はシステム部分のため、触らないでください ****/

  // data指定の詰まりデフォルト文字
  static strStutter = '&#12289;'; // 、
  // data指定の区切り、響きデフォルト文字
  static strPauseEcho = '&#8230;&#8230;'; // ……
  // 変換前の文字列マッピング用data
  static beforeNameMap = 'data-charm-before';
  // 特殊キー
  static eKey = 'C3D1A4F7B6E2A5B8C9D1F2A3B7E6F4D9';

  constructor() {
    // 登録した名前
    this.charm = {};
    // ファイル内保持の名前（Storage無効対策）
    this.tmpCharm = {};
    // sessionStorageからの名前読み込みの場合はtrue
    this.isSession = false;
    // 変換前のデフォルトtextContent
    this.beforeList = [];
    this.xKey = BigInt('0x' + Charm.eKey.match(/.{1,4}/g).reverse().join(''));
    // デバウンスされたハンドラー設定
    this.debouncedSetNameSyncHandler = this.debounce(this.setNameSyncHandler, 100);
  }

  static run = () => {
    let instance = new Charm();
    instance.start();
    return instance;
  };

  start = () => {
    const buttonActions = [
      { newId: Charm.setNameId, oldId: Charm.oldSetName, handler: this.setLocalNameHandler },
      { newId: Charm.setSessionId, oldId: null, handler: this.setSessionNameHandler }, // 一時登録は過去仕様がない
      { newId: Charm.unsetNameId, oldId: Charm.oldUnsetName, handler: this.unsetStorage }
    ];
    buttonActions.forEach(({ newId, oldId, handler }) => {
      let button = document.getElementById(newId);
      if (!button && oldId) {
        // 新仕様のIDでボタンが見つからない場合、過去のIDをチェック
        button = document.getElementById(oldId);
      }
      if (button) {
        button.removeEventListener('click', handler, false); // 既存のリスナーを削除
        button.addEventListener('click', handler, false); // リスナーを再登録
      }
    });

    // syncNow関連classを持つinput要素にイベントリスナーを追加
    const syncNowLocal = document.getElementsByClassName(Charm.syncNow);
    const syncNowSession = document.getElementsByClassName(Charm.syncNowSession);
    const handler = this.debouncedSetNameSyncHandler;

    const addListeners = (elms) => {
      Array.from(elms).forEach(elm => {
        elm.removeEventListener('input', handler, false);
        elm.addEventListener('input', handler, false);
        elm.removeEventListener('compositionend', handler, false);
        elm.addEventListener('compositionend', handler, false);
      });
    };
    addListeners(syncNowLocal);
    addListeners(syncNowSession);
    // リロード前のfocus状況を再現
    this.setFocus();
    this.viewName();
  };

  /**
   * localStorageを使用しようとした際に発生するエラーを処理
   * @param {DOMException} e - localStorage操作によってスローされるエラーオブジェクト
   * @param {boolean} syncnow リアルタイム保存かどうか
   */
  storageError = (e, syncnow = false) => {
    let msg = "その他のエラーが発生しました";
    if (e instanceof DOMException && e.name === 'QuotaExceededError') {
      msg = 'ローカルストレージの容量がいっぱいです';
    } else if (e instanceof DOMException && e.name === 'SecurityError') {
      msg = 'セキュリティ設定によりローカルストレージが使用できません';
    }
    // アラート表示を有効にしている、かつsyncNowではない場合はアラート表示
    if (Charm.showStorageError && !syncnow) {
      alert(msg);
    }
    console.warn(msg, e);
  };

  /**
   * ストレージから名前を削除
   * このメソッドは、ローカルストレージとセッションストレージの両方から名前を削除し、
   * ページを再読み込みします。主に名前削除イベントで使用されます。
   */
  unsetStorage = () => {
    // 入力エリア削除処理
    const elms = document.getElementsByClassName(Charm.nameClass);
    Array.from(elms).forEach(elm => {
        elm.value = '';
    });
    if (!this.charm && !this.tmpCharm) return;
    // ストレージ削除処理
    try { 
      localStorage.removeItem(Charm.storageKeyName);
      sessionStorage.removeItem(Charm.storageKeyName);
    } catch (e) {
      this.storageError(e);
    }
    if (Charm.unsetReload) {
      // 再読み込み
      location.reload(true);
    } else {
      // 再読み込みせずにdata属性から再セット
      this.resetElements();
    }
    this.beforeList = [];
  }
  
  // data属性から再セット
  resetElements = () => {
    const elms = document.querySelectorAll(`[${Charm.beforeNameMap}]`);
    elms.forEach(elm => {
      const beforeIndex = parseInt(elm.getAttribute(`${Charm.beforeNameMap}`));
      this.writeText(elm, this.beforeList[beforeIndex]);
      elm.removeAttribute(Charm.beforeNameMap); // 属性を動的に削除
    });
    // 一時登録テキスト表示エリアエレメント
    let ssnMsg = document.getElementById(Charm.viewRegistSession);
    if (ssnMsg) {
      ssnMsg.textContent = '';
    }
    this.beforeList = this.charm = this.tmpCharm = {};
  }

  setLocalNameHandler = () => {
    this.setStorage(true, false).then(() => {
      this.viewName();
    });
  };
  
  setSessionNameHandler = () => {
    this.setStorage(false, false).then(() => {
      this.viewName();
    });
  };

  // デバウンス関数：一定時間内に連続して呼ばれた関数をまとめる
  debounce = (func, delay) => {
    let timeoutId;
    return (...args) => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        func.apply(this, args); // `this`を`func`に渡す
      }, delay);
    };
  };

  /**
   * リアルタイム自動保存・自動削除処理
   * 保存ボタンと削除ボタンではなく入力欄のイベントから発火
   * 入力欄の操作のみでstorage保存する
   * @param {Event} e 入力イベントオブジェクト。入力フィールドの値やIDを含む。
   */
  setNameSyncHandler = (e) => {
    const target = e.target;
    const isLocal = target.classList.contains(Charm.syncNow);
    const id = target.id;
    let nameStr = target.value;
    if (nameStr !== "") {
      // 入力した文字があるときは全体を保存
      this.setStorage(isLocal, true).then(() => {
        this.viewName();
      });
      return;
    }
    // 入力欄の文字を消した場合
    if (id in this.charm) {
      delete this.charm[id];
      this.setStorage(isLocal, true).then(() => {
        // 1つも登録されていない場合はstorageのキーごと削除
        if (!Object.keys(this.charm).length) {
          this.unsetStorage();
        }
        // focus状況を保存
        this.saveFocus();
        // 再読み込み Charm.unsetReloadの内容に関わらず強制
        location.reload(true);
      });
    }
  }

  /**
   * 現在focusしているinputのidをSessionStorageに保存
   * リアルタイム保存機能で入力欄の文字を消した場合に使用
   */
  saveFocus = () => {
    const focused = document.activeElement;
    if (focused && focused.tagName === 'INPUT') {
      sessionStorage.setItem('focusedElementId', focused.id);
    }
  }

  /**
   * リロード前にfocusしていたinputのidを読み込み、
   * 入力欄をfocusする
   */
  setFocus = () => {
    const focused = sessionStorage.getItem('focusedElementId');
    if (focused) {
      const elm = document.getElementById(focused);
      if (elm) {
          elm.focus();
      }
      // フォーカス状況の保存値を削除
      sessionStorage.removeItem('focusedElementId');
    }
  }


  xTransform = (t) => {
    if (!Charm.useEncryption) {
      return t;
    }
    const k = this.xKey;
    return t.split('').map((char, index) => {
      // シフトした後に0xFFでマスクして下位8ビットを取得
      const keyPart = Number((k >> BigInt((index % 32) * 4)) & BigInt(0xFF));
      return String.fromCharCode(char.charCodeAt(0) ^ keyPart);
    }).join('');
  }

  setNameObj = async (nameItems) => {
    return new Promise((resolve) => {
      // Storageに登録するobject
      let nameObj = {};
      // nameClassで指定したclassをもっている要素（input想定）のループ
      // 指定classの数だけループして id = value のペアをセット
      Array.from(nameItems).forEach(name => {
        if (!name || name.value.length < 1) return;
        let nameStr = name.value;
        // 文字数が登録上限数を超えていた場合はカットして丸める
        if (Charm.maxSize && nameStr.length > Charm.maxSize) {
          nameStr = nameStr.slice(0, Charm.maxSize) + '…';
        }
        // 保存用objectにも仮objectにも格納
        nameObj[name.id] = this.tmpCharm[name.id] = encodeURIComponent(this.xTransform(nameStr));
      });
      resolve(nameObj);
    });
  }

  /**
   * 登録してある名前を取得する
   *    viewName()から呼び出して使用
   */
  readName = async () => {
    return new Promise((resolve) => {
      this.isSession = false;
      let getItem = null;
      // JS上に格納したデータkey
      let charmTmpKeys;
    
      // localStorageとsessionStorageからのデータ取得を試みる
      try {
        getItem = JSON.parse(localStorage.getItem(Charm.storageKeyName));
        if (!getItem) {
          getItem = JSON.parse(sessionStorage.getItem(Charm.storageKeyName));
          this.isSession = !!getItem;
        }
      } catch (e) { // localStorageまたはsessionStorageへのアクセスに失敗
        charmTmpKeys = Object.keys(this.tmpCharm);
        // データが登録も登録操作もされていなければそれ以上処理しない
        if (!getItem && charmTmpKeys.length < 1) {
          resolve(); // 処理を完了        
          return;
        }
        // データは登録されていないが、登録操作はあった場合（Storage無効対策）
        if (!getItem && charmTmpKeys.length > 0) {
          charmTmpKeys.forEach(key => this.charm[key] = this.xTransform(decodeURIComponent(this.tmpCharm[key])));
        }
        resolve(); // 処理を完了
        return;
      }
      if (getItem === null) {
        resolve(); // 処理を完了
        return;
      }
      // データが登録されている場合
      Object.keys(getItem).forEach(key => this.charm[key] = this.xTransform(decodeURIComponent(getItem[key])));
      resolve(); // 処理を完了
    });
  }

  /**
   * ローカルストレージまたはセッションストレージに名前を設定
   * このメソッドは、ユーザーが入力した名前をローカルストレージまたはセッションストレージに保存
   * エスケープ処理と文字数の制限もこのメソッド内で行われる
   * 
   * @param {boolean} isLocal - trueの場合はローカルストレージ、falseの場合はセッションストレージに保存
   * @param {boolean} isSyncNow - リアルタイム保存での呼び出しかどうか
   * @return {boolean} 保存が成功したかどうか
   */
  setStorage = async (isLocal = true, isSyncNow = false) => {
    // 入力要素を取得
    let nameItems = document.getElementsByClassName(Charm.nameClass);
    // storageに登録するobject
    let nameObj = await this.setNameObj(nameItems); // 非同期関数の完了を待つ

    this.updateStorage(isLocal, nameObj, isSyncNow);
    return true;
  }

  /**
   * ストレージを更新するメソッド
   * 
   * @param {boolean} isLocal - trueの場合はローカルストレージ、falseの場合はセッションストレージに保存
   * @param {object} nameObj - 保存する名前のオブジェクト
   * @param {boolean} isSyncNow - リアルタイム保存での呼び出しかどうか
   */
  updateStorage = (isLocal, nameObj, isSyncNow) => {
    try {
      // 利用する方のStorage
      let onSt = (isLocal) ? localStorage : sessionStorage;
      // 利用しない方のStorage
      let offSt = (isLocal) ? sessionStorage : localStorage;
      onSt.setItem(Charm.storageKeyName, JSON.stringify(nameObj));
      offSt.removeItem(Charm.storageKeyName);
      this.charm = nameObj;
      if (Charm.setReload && !isSyncNow) location.reload(true); // 再読み込み
    } catch (e) {
      this.storageError(e);
    }
  }

  viewName = async () => {
    await this.readName(); // readNameの完了を待つ
    if (this.charm) {
      for (const key in this.charm) {
        this.replaceEdit(key, this.charm[key]);
        this.setFormName(key);
      }      
      this.setSessionMessage();
    }
  }

  /**
   * 名前置換メインメソッド
   *    表示メソッドviewName()から呼び出して使用
   *    置換先要素を取得、設定に合わせた置換処理を通して置換先要素にセットする
   * @param {String} key  登録情報配列のkey
   * @param {String} name 登録情報配列のvalue
   */
  replaceEdit(key, name) {
    // 名前が空の場合は何もせずに戻る
    if (!name) return;
  
    // 指定されたクラス名を持つ要素をすべて選択し、配列に変換する
    const elms = Array.from(document.getElementsByClassName(key));
    elms.forEach(elm => {
      const dataset = elm.dataset;
      const classList = elm.classList;
      // カスタム変換指定を取得
      const custom = new CustomOptions(dataset, classList);
      // カスタム変換指定を通して名前を加工（無指定の場合は加工されない）
      const nameGen  = new NameGeneration(name, custom);
      const rName = nameGen.generateName;
      // 変換前の内容を保存
      this.setBeforeStrIndex(elm);
      // 要素の内容を変換後の名前に更新
      this.writeText(elm, rName);
    });
  }

  /**
   * 指定されたElementに、エンティティ化された文字列を安全にテキストとして挿入
   * 
   * @param {Element} elm - テキストを挿入する対象のDOM Element
   * @param {string} rName - 置換後にセットする予定の名前文字列
   */
  writeText =(elm, rName)=> {
    const parser = new DOMParser();
    // DOMParserを使用して、エンティティ化された文字列を解析
    const doc = parser.parseFromString(rName, 'text/html');
    // 解析結果から安全なテキストを取得
    // もし何らかの理由でtextContentが空であれば、空文字列をデフォルト値として使用
    const safeText = doc.body.textContent || "";
    elm.textContent = safeText;
  }

  /**
   * 変換前の文字を内部に保持する
   * @param {Element} elm
   */
  setBeforeStrIndex = (elm) => {
    // 登録削除時にリロードする設定の場合は以降の処理を行わない
    if (Charm.unsetReload) return;
    const elmBeforeIndex = elm.getAttribute(Charm.beforeNameMap);
    // 変換前の文字を内部保存する前の場合は保持する（登録と一時登録を繰り返す場合の対処）
    if (elmBeforeIndex === null || elmBeforeIndex === '') {
      const beforeIndex = this.beforeList.length;
      this.beforeList[beforeIndex] = elm.textContent;
      elm.setAttribute(Charm.beforeNameMap, beforeIndex);
    }
  }

  /**
   * 一時登録メッセージを表示する（セッション保存専用）
   */
  setSessionMessage = () => {
    // 表示エリアエレメント
    let ssnMsg = document.getElementById(Charm.viewRegistSession);
    if (ssnMsg !== null) {
      if (this.isSession) {
        ssnMsg.textContent = Charm.sessionString;
      } else {
        ssnMsg.textContent = '';
      }
    }
  }

  /**
   * 入力フォームに登録内容を挿入する
   * @param {String} key 登録key名 
   */
  setFormName = (key) => {
    let formItem = document.getElementById(key);
    // keyの入力フォームが取得できないときはスキップ
    if (!formItem) {
      return;
    }
    formItem.value = this.charm[key];
  }
}


class CustomOptions {
  
  // ひらがな・カタカナ・Mix変換以外のチェック処理すべて
  static checkMethods = [
    'checkShort',
    'checkSkip',
    'checkChop',
    'checkLast',
    'checkStutter',
    'checkPause',
    'checkEcho',
    'checkRev',
    'checkOverlap',
    'checkVowel'
  ];

  /**
   * コンストラクター：データセットとクラスリストを元にオプションを初期化
   * @param {Object} dataset - HTML要素のdata属性集合
   * @param {DOMTokenList} classList - HTML要素のクラスリスト
   */
  constructor(dataset, classList) {
    this.dataset = dataset;
    this.classList = classList;
    this.custom = {
      expression: {
        short: false,
        skip: false,
        chop: false,
        last: false,
        stutter: false,
        pause: false,
        echo: false,
        rev: false,
        overlap: false,
        vowel: false,
        hira: false,
        kana: false,
        mix: false,
      },
      option: {
        count: undefined,
        symbol: undefined,
        vowelMin: false,
      }
    };
    return this.executeChecks();
  }

  /**
   * カスタムの指定内容を抽出
   */
  executeChecks = () => {
    for (const method of CustomOptions.checkMethods) {
      if (typeof this[method] === 'function' && this[method]()) {
        // メソッドが true を返したら他の処理は停止
        break;
      }
    }
    // ひらがな変換指定チェック（他のカスタムと同時指定可能なので別処理とする）
    this.checkHira();
    // カタカナ変換指定チェック（他のカスタムと同時指定可能なので別処理とする）
    this.checkKana();
    // Mix変換指定チェック（他のカスタムと同時指定可能なので別処理とする）
    this.checkMix();
    return this.custom;
  }

  /**
   * オプションの回数を取得するためのクラス名をチェック
   * @returns {number|null} 見つかったオプションの回数、またはnull
   */
  getClassCount = () => {
    const countStr = Charm.charmClassList.charmCount;
    // 1～9の検索対象クラス名を生成し、検索
    const index = [...Array(9)].findIndex ((_, i) => this.classList.contains(`${countStr}${i + 1}`));
    return index !== -1 ? index + 1 : null;
  }

  /**
   * オプションの記号を取得するためのクラス名をチェック
   * @returns {string|null} 見つかったオプションの記号、またはnull
   */
  getClassSymbol = () => {
    const symbolStr = Charm.charmClassList.charmSymbol;
    // 1～48の検索対象クラス名を生成し、検索
    const index = [...Array(48)].findIndex((_, i) => {
      const numStr = (i + 1).toString().padStart(2, '0'); // 2桁で0埋め
      return this.classList.contains(`${symbolStr}${numStr}`) || this.classList.contains(`${symbolStr}${i + 1}`);
    });
    return index !== -1 ? Charm.symbols[index] : null;
  }

  /**
   * 省略表現をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkShort = () => {
    // データ指定での回数指定をチェック
    if (this.dataset.charmShort) {
      // dataにセットされている値を数値化できない場合は1文字の省略とする
      this.custom.option.count = +this.dataset.charmShort || 1;
    } else if (this.classList.contains(Charm.charmClassList.charmShort)) {
      // クラスでの回数指定をチェック、未指定のときはデフォルトをセット
      this.custom.option.count = this.getClassCount() || 1;
    } else {
      return false;
    }
    this.custom.expression.short = true;
    return true;
  }

  /**
   * 末尾カットをチェック
   * @returns {boolean} 処理が行われたかどうか
   */
  checkChop = () => {
    if (this.dataset.charmChop || this.classList.contains(Charm.charmClassList.charmChop)) {
      this.custom.expression.chop = true;
      return true;
    }
    return false;
  }

  /**
   * 最後の文字取得をチェック
   * @returns {boolean} 処理が行われたかどうか
   */
  checkLast = () => {
    if (this.dataset.charmLast || this.classList.contains(Charm.charmClassList.charmLast)) {
      this.custom.expression.last = true;
      return true;
    }
    return false;
  }

  /**
   * 先頭文字スキップをチェック
   * @returns {boolean} 処理が行われたかどうか
   */
  checkSkip = () => {
    if (this.dataset.charmSkip || this.classList.contains(Charm.charmClassList.charmSkip)) {
      this.custom.expression.skip = true;
      return true;
    }
    return false;
  }

  /**
   * 詰まり表現をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkStutter = () => {
    // データで指定がなければ以降は処理しない
    if (this.dataset.charmCall === 'stutter' || this.classList.contains(Charm.charmClassList.charmStutter)) {
      this.custom.expression.stutter = true;
    } else {
      return false;
    }
    if (this.dataset.charmCall === 'stutter') {
      // 回数指定と記号をチェック、dataにセットされている値を数値化できない場合はデフォルトをセット
      this.custom.option.count = +this.dataset.charmSttCount || Charm.sttCountDefault;
      this.custom.option.symbol = this.dataset.charmBreak || Charm.strStutter;
    };

    if (this.classList.contains(Charm.charmClassList.charmStutter)) {
      // クラスでの回数指定と記号をチェック、未指定のときはデフォルトをセット
      this.custom.option.count = this.getClassCount() || Charm.sttCountDefault;
      this.custom.option.symbol = this.getClassSymbol() || Charm.strStutter;
    }
    return true;
  }
  
  /**
   * 区切り表現をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkPause = () => {
    if (this.dataset.charmCall === 'pause') {
      // dataにセットされている値を数値化できない場合はデフォルトをセット
      this.custom.option.symbol = this.dataset.charmBreak || Charm.strPauseEcho;
    } else if (this.classList.contains(Charm.charmClassList.charmParse)) {
      // クラスでの記号指定をチェック、未指定のときはデフォルトをセット
      this.custom.option.symbol = this.getClassSymbol() || Charm.strPauseEcho;
    } else {
      return false;
    }
    this.custom.expression.pause = true;
    return true;
  }

  /**
   * 響き表現をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkEcho = () => {
    // 指定がなければ以降は処理しない
    if (this.dataset.charmCall === 'echo' || this.classList.contains(Charm.charmClassList.charmEcho)) {
      this.custom.expression.echo = true;
    } else {
      return false;
    }
    // データで回数指定
    if (this.dataset.charmCall === 'echo') {
      // 回数指定と記号をチェック、dataにセットされている値を数値化できない場合はデフォルトをセット
      this.custom.option.count = +this.dataset.charmEchCount || Charm.echoCountDefault;
      this.custom.option.symbol = this.dataset.charmBreak || Charm.strPauseEcho;
    };

    if (this.classList.contains(Charm.charmClassList.charmEcho)) {
      // クラスでの回数指定と記号をチェック、未指定のときはデフォルトをセット
      this.custom.option.count = this.getClassCount() || Charm.echoCountDefault;
      this.custom.option.symbol = this.getClassSymbol() || Charm.strPauseEcho;
    }
    return true;
  }

  /**
   * 逆順表現をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkRev = () => {
    if (this.dataset.charmRev || this.classList.contains(Charm.charmClassList.charmRev)) {
      this.custom.expression.rev = true;
      return true;
    }
    return false;
  }

  /**
   * 重ね表現をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkOverlap = () => {
    if (this.dataset.charmOverlap || this.classList.contains(Charm.charmClassList.charmOverlap)) {
      this.custom.expression.overlap = true;
    } else {
      return false;
    }
    // 重ね表現の規定数
    const overlapCount = 2;
    if (this.dataset.charmOverlap) {
      // 回数指定と記号をチェック、dataにセットされている値を数値化できない場合は規定数をセット
      this.custom.option.count = +this.dataset.charmOvlCount || overlapCount;
    };

    if (this.classList.contains(Charm.charmClassList.charmOverlap)) {
      // クラスでの回数指定をチェック、未指定のときは規定数をセット
      this.custom.option.count = this.getClassCount() || overlapCount;
    }
    return true;
  }

  /**
   * 母音のばし表現をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkVowel = () => {
    if (
      this.dataset.charmVowel || 
      this.classList.contains(Charm.charmClassList.charmVowel) || 
      this.dataset.charmVowelMin || 
      this.classList.contains(Charm.charmClassList.charmVowelMin)
    ) {
      this.custom.expression.vowel = true;
    } else {
      // 母音指定なし
      return false;
    }
    // 小文字指定
    if (this.dataset.charmVowelMin || this.classList.contains(Charm.charmClassList.charmVowelMin)) {
      this.custom.option.vowelMin = true;
    }
    // データで数指定
    if (this.dataset.charmVowelCount) {
      // dataにセットされている値を数値化できない場合はデフォルトをセット
      this.custom.option.count = +this.dataset.charmVowelCount || 0;
      return true;
    };

    // クラスでの回数指定をチェック、未指定のときはデフォルトをセット
    this.custom.option.count = this.getClassCount() || 0;
    return true;
  }

  /**
   * ひらがな指定をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkHira = () => {
    const hg = this.dataset.charmHira;
    if (
      hg === 'on' ||
      hg == '1' ||
      this.classList.contains(Charm.charmClassList.charmHira)) {
      this.custom.expression.hira = true;
      return true;
    }
    return false;
  }

  /**
   * カタカナ指定をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkKana = () => {
    const kn = this.dataset.charmKana;
    if (
      kn === 'on' ||
      kn == '1' ||
      this.classList.contains(Charm.charmClassList.charmKana)) {
      this.custom.expression.kana = true;
      return true;
    }
    return false;
  }

  /**
   * Mix指定をチェックし、必要に応じてオプションを設定
   * @returns {boolean} 処理が行われたかどうか
   */
  checkMix = () => {
    const mix = this.dataset.charmMix;
    if (
      mix === 'on' ||
      mix == '1' ||
      this.classList.contains(Charm.charmClassList.charmMix)) {
      this.custom.expression.mix = true;
      return true;
    }
    return false;
  }
}

class NameGeneration {

  // カスタム種類ごとの関数名
  static custom = {
    short: 'generateShort',
    skip: 'generateSkip',
    chop: 'generateChop',
    last: 'generateLast',
    stutter: 'generateStutter',
    pause: 'generatePause',
    echo: 'generateEcho',
    rev: 'generateRev',
    overlap: 'generateOverlap',
    vowel: 'generateVowel',
    // ひらがなカタカナMix変換は最後に実行
    hira: 'generateHira',
    kana: 'generateKana', 
    mix: 'generateMix', 
  };

  constructor(name, custom) {
    this.custom = custom;
    // 加工前の名前
    this.name = name;
    // 加工後の名前 初期値は加工前の名前
    this.generateName = name;
    // 自然な区切り処理に使用する名前分割配列
    this.splitName = [];
    // 母音判定の分類
    this.vowels = {};
    this.executeGenerate();
  }

  /**
   * カスタム変換処理も含めて変換する文字を呼び出す
   */
  executeGenerate = () => {
    this.nameSplit();
    // custom.expressionの各項目をループし、trueのものだけ対応する
    Object.keys(this.custom.expression).forEach(expression => {
      if (this.custom.expression[expression]) {
        // 対応するメソッド名を取得し、メソッドが存在する場合は実行
        const methodName = NameGeneration.custom[expression];
        if (typeof this[methodName] === 'function') {
          this[methodName]();  // 対応するメソッドを実行
        }
      }
    });
  }

  /**
   * 名前を自然な区切りの配列にしてthis.splitNameに格納
   *    小さい「ぁ」や「っ」など、1文字で使用しない文字を考慮して区切る
   *    「あいうえお」   ->  ['あ', 'い', 'う', 'え', 'お']
   *    「しゃしゅ」    ->  ['しゃ', 'しゅ']
   */
  nameSplit = () => {
    // 自然に区切りたい日本語の名前
    const name = this.name;
    // 小さい文字や特定の記号を識別するための正規表現
    const smallCharRegex = /[ぁぃぅぇぉゕゖっゃゅょゎァィゥェォヵㇰヶㇱㇲッㇳㇴㇵㇶㇷㇸㇹㇺャュョㇻㇼㇽㇾㇿヮｧｨｩｪｫｬｭｮｯ・ー]/;
    let splitName = [];
    let i = 0;
    // 名前の全文字を順に処理
    while (i < name.length) {
      let pushString = name[i]; // 現在の文字を取得
      i++; // インデックスを進める
      // 次の文字が小さい文字や特定の記号である間、現在の文字列に連結
      while (i < name.length && smallCharRegex.test(name[i])) {
        pushString += name[i];
        i++; // インデックスを進める
      }
      // 処理した文字列を配列に追加
      splitName.push(pushString);
    }
    this.splitName = splitName;
  }

  /**
   * 省略表現の文字列を作る
   */
  generateShort = () => {
    const count = this.custom.option.count;
    // 名前の文字数が指定文字数未満の場合、そのまま返す
    if (count >= this.splitName.length) {
      this.generateName = this.splitName.join('');
      return;
    }
    // 指定の長さに削った配列
    let result = this.splitName.slice(0, count);
    // 末尾の文字が特定の文字の場合、削除
    result[count - 1] = result[count - 1].replace(/[\u3063\u30c3\u30FCｯ・]/g, '');
    this.generateName = result.join('');
  }
  
  /**
   * 末尾カット表現の文字列を作る
   */
  generateChop = () => {
    // 配列の末尾の要素を削除する
    this.splitName.pop();
    this.generateName = this.splitName.join('');
  }

  /**
   * 最後の文字を作る
   */
  generateLast = () => {
    this.generateName = this.splitName[this.splitName.length - 1];
  }

  /**
   * 先頭スキップ表現の文字列を作る
   */
  generateSkip = () => {
    // 配列の先頭の要素を削除する
    this.splitName.shift();
    this.generateName = this.splitName.join('');
  }

  /**
   * 詰まり表現の文字列を作る
   */
  generateStutter = () => {
    const opt = this.custom.option;
    const count = opt.count;
    const symbol = opt.symbol;
    const sttStr = this.splitName[0];
    // 詰まり表現の文字列を作成
    let result = Array(count).fill(sttStr + symbol).join('');
    result = result.slice(0, -(symbol.length)); // 末尾の余分な記号を削除
    this.generateName = result;
  }

  /**
   * 区切り表現の文字列を作る
   */
  generatePause = () => {
    this.generateName = this.splitName.join(this.custom.option.symbol);
  }

  /**
   * 指定の組み合わせと回数で配列の名前を区切り、響き表現の文字列を作る
   */
  generateEcho = () => {
    const opt = this.custom.option;
    // 区切りの間に挿入する文字列
    const symbol = opt.symbol;
    const names = this.splitName;
    // 響きの回数を計算
    const count = Math.min(opt.count, names.length - 1);
    let result = [];
    // 後ろから名前を結合して響き表現を生成
    for (let i = count; i > 0; i--) {
      result.push(names.slice(i).join('')); // 名前の後方から文字を取り出し
    }
    this.generateName = result.join(symbol) + symbol; // 結果を記号で結合して最後にも記号を追加
  }
  
  /**
   * 逆順表現の文字列を作る
   */
  generateRev = () => {
    this.generateName = this.splitName.reverse().join('');
  }

  /**
   * 重ね表現の文字列を作る
   */
  generateOverlap = () => {
    this.generateName = this.splitName.map(elm => elm.repeat(this.custom.option.count)).join('');
  }

  generateVowel = () => {
    const repVowelsUppercase = ['あ', 'ア', 'い', 'イ', 'う', 'ウ', 'え', 'エ', 'お', 'オ'];
    const repVowelsLowercase = ['ぁ', 'ァ', 'ぃ', 'ィ', 'ぅ', 'ゥ', 'ぇ', 'ェ', 'ぉ', 'ォ'];
    // 母音パターンとその対応する母音
    const vowelPatterns = {
      'あかさたなはまやらわがざだばぱゃぁゕゎ': 0,
      'アカサタナハマヤラワガザダナパァヵㇵャㇻヮ': 1,
      'いきしちにひみりゐぎじぢびぃヰ': 2,
      'イキシチニヒミリギジヂビィㇱㇶㇼ': 3,
      'うくすつぬふむゆるぐずづぶぷゅぅっ': 4,
      'ウクスヌヌフムユルグズヅブプュゥㇰㇲッㇴㇷㇽ': 5,
      'えけせてねへめれゑげぜでべぺぇゖ': 6,
      'エケセテネヘメレゲゼデベペェヶㇸㇾ': 7,
      'おこそとのほもよろをごぞどぼぽょぉ': 8,
      'オコソトノホモヨロヲゴゾドボポョォㇳㇹㇺㇿ': 9,
      'んー〜ン': -1  // 母音変換せずにそのまま使用するパターン
    };

    const lastVal = this.splitName[this.splitName.length - 1];
    const opt = this.custom.option;
    // 繰り返し回数
    const count = opt.count ? (opt.count + 1) : 1;
    // 返す母音が大きい文字か小さい文字か
    const isUppercase = !opt.vowelMin;
    let found = false;
    Object.entries(vowelPatterns).forEach(([pattern, index]) => {
      if (new RegExp(`[${pattern}]$`).test(lastVal)) {
        if (index >= 0) {
          // 母音を大文字または小文字に変換
          const vowel = isUppercase ? repVowelsUppercase[index] : repVowelsLowercase[index];
          this.generateName = vowel.repeat(count);
        } else {
          // 特別な文字の場合、そのまま使用
          this.generateName = lastVal.repeat(count);
        }
        found = true;
      }
    });

    // 母音や特別な文字が見つからなかった場合、何もせずに終了
    if (!found) {
      this.generateName = "";  // 母音や特定の文字以外は無視
    }
  }

  /**
   * カタカナ → ひらがな変換共通処理
   */
  hiraTransform = char => {
    return char.replace(/[\u30A1-\u30F6]/g, match => String.fromCharCode(match.charCodeAt(0) - 0x60));
  }

  /**
   * ひらがな → カタカナ変換共通処理
   */
  kanaTransform = char => {
    return char.replace(/[\u3041-\u3096]/g, match => String.fromCharCode(match.charCodeAt(0) + 0x60));
  }

  /**
   * カタカナ → ひらがな変換呼び出し
   */
  generateHira = () => {
    this.generateName = this.hiraTransform(this.generateName);
  }

  /**
   * ひらがな → カタカナ変換呼び出し
   */
  generateKana = () => {
    this.generateName = this.kanaTransform(this.generateName);
  }

  /**
   * ひらがなとカタカナを交互に変換
   */
  generateMix = () => {
    this.name = this.generateName; // 加工済みの名前文字列をgenerateNameをnameに戻す
    this.nameSplit(); // nameSplitを再度呼び出して、加工済みの文字を配列分割
    this.generateName = this.splitName.map((v, i) => {
      if (i % 2 === 0) {
        return this.kanaTransform(v);
      } else {
        return this.hiraTransform(v);
      }
    }).join('');
  }
}

try {
  Charm.run();
} catch (error) {
  console.error('An error occurred while creating a Charm instance: ', error);
}
