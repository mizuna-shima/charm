/*!
 * Charm.js ver 3.7.1
 * Charm.js License (Revised January 14, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/charm/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */

class Charm {
  /**** 設定項目ここから ---------------------------- ****/

  // 登録する名前の入力フォームアイテム共通Class
  static nameClass = "charm";
  // 入力の自動保存のClass名
  static syncNow = "charmnow";
  // 入力の自動保存のClass名（一時保存）
  static syncNowSession = "charmnowsession";
  // 登録ボタンのId
  static setNameId = "charmset";
  // 一時登録ボタンのId
  static setSessionId = "charmsession";
  // 削除ボタンのId
  static unsetNameId = "charmunset";
  // 一時登録の表記をするid
  static viewRegisterSession = "charmsessionmsg";
  // 一時保存の際に表示できるメッセージ
  static sessionString = "（一時保存しました）";
  // WebStorageが使えない場合に表示するメッセージ枠のClass
  static storageErrorClass = "charm_storage_error";
  // WebStorageが使えない場合にメッセージ枠に表示するメッセージ
  static storageErrorString = "この環境ではWebStorageが利用できないため、名前は保存されません。";
  // localStorageまたはsessionStorageの保存キー
  static storageKeyName = "charm";
  // 簡易暗号化 使う:1 使わない:0
  static useEncryption = 0;
  // 登録できる最大文字数 オーバーした文字は「…」で登録
  // 無制限にする場合は0
  static maxSize = 50;
  // 登録または一時登録ボタンで名前登録時にページを再読み込み
  // する:1 しない:0
  static setReload = 0;
  // 名前削除時にページを再読み込み（自動保存も含む）
  // する:1 しない:0
  static unsetReload = 0;
  // Web Storageが使えないとき ウィンドウを出す:1 出さない:0
  static showStorageError = 0;
  // 響き（欠けた名前を連呼する）回数のデフォルト
  static echoCountDefault = 2;
  // 詰まり回数のデフォルト
  static sttCountDefault = 2;
  // クラスモード使用時に設定するクラス名
  static charmClassList = {
    // 名前省略
    charmShort: "charm_short",
    // 先頭文字スキップ
    charmSkip: "charm_skip",
    // 末尾カット
    charmChop: "charm_chop",
    // 最後の文字
    charmLast: "charm_last",
    // 区切り
    charmParse: "charm_pause",
    // 響き
    charmEcho: "charm_echo",
    // 重複
    charmOverlap: "charm_overlap",
    // 詰まり
    charmStutter: "charm_stutter",
    // 逆順
    charmRev: "charm_rev",
    // ひらがな
    charmHira: "charm_hira",
    // カタカナ
    charmKana: "charm_kana",
    // カナMix
    charmMix: "charm_mix",
    // 最後の母音
    charmVowel: "charm_vowel",
    // 最後の母音（小さい文字）
    charmVowelMin: "charm_vowel_min",
    // イニシャル
    charmInitial: "charm_initial",
    // 記号設定の共通
    charmSymbol: "charm_symbol",
    // 回数設定の共通
    charmCount: "charm_count",
  };

  /** v1.2以前の設定 **/
  // 登録・削除ボタンのId
  static oldSet = "charm-setname";
  static oldUnset = "charm-unsetname";

  /**** 設定項目ここまで ---------------------------- ****/

  /** 本体起動 **/
  static run() {
    const runner = globalThis?.CharmRunner;
    if (typeof runner?.start === "function") {
      runner.start();
    } else {
      console.warn("CharmRunner is not available.");
    }
  }
  static addExtension(name, ex) {
    CharmRunner.addExtension(name, ex);
  }
  static addEExtension(name, ex) {
    CharmRunner.addEExtension(name, ex);
  }
}

if (typeof window !== "undefined") {
  window.Charm = Charm;
}

!function(){"use strict";class t{static#t;static#e=()=>this.handleSetName("local");static#s=()=>this.handleSetName("session");static#a=new Map;static#i=null;static#r=!1;static setup(){this.#t??=this.#n(this.handleInputSync,100),this.#i=document.getElementsByClassName(Charm.nameClass),this.#r=this.#h(),this.#o(),this.setupButtonHandlers(),this.setupInputHandlers(),this.setInputVal()}static setupButtonHandlers(){[{newId:Charm.setNameId,oldId:Charm.oldSet,handler:this.#e},{newId:Charm.setSessionId,oldId:null,handler:this.#s},{newId:Charm.unsetNameId,oldId:Charm.oldUnset,handler:this.handleUnsetName}].forEach((({newId:t,oldId:e,handler:s})=>{let a=document.getElementById(t);!a&&e&&(a=document.getElementById(e)),a&&(a.removeEventListener("click",s,!1),a.addEventListener("click",s,!1))}))}static setupInputHandlers(){const t=document.getElementsByClassName(Charm.syncNow),e=document.getElementsByClassName(Charm.syncNowSession),s=this.#t,a=t=>{for(const e of[...t]){const t="select"===e.tagName.toLowerCase()?["change"]:["input","compositionend"];for(const a of t)e.removeEventListener(a,s,!1),e.addEventListener(a,s,!1)}};a(t),a(e)}static#n(t,e){return(...s)=>{const a=s[0].target;clearTimeout(this.#a.get(a));const i=setTimeout((()=>{this.#a.delete(a),t.apply(this,s)}),e);this.#a.set(a,i)}}static#c(){for(const t of this.#a.values())clearTimeout(t);this.#a.clear()}static#l(){for(const t of this.#i)!t||t.value.length<1||(CharmStorage.charm={nameId:t.id,value:t.value})}static setInputVal(){[...this.#i].forEach((t=>{if(!this.#a.has(t))if(Object.prototype.hasOwnProperty.call(CharmStorage.charm,t.id))t.value=CharmStorage.charm[t.id];else if("SELECT"===t.tagName){const e=[...t.options],s=e.filter((t=>t.defaultSelected));if(t.multiple)e.forEach((t=>{t.selected=t.defaultSelected}));else{const a=s[s.length-1]??(t.size<=1?e.find((t=>!(t.disabled||"OPTGROUP"===t.parentElement.tagName&&t.parentElement.disabled))):null);t.selectedIndex=a?a.index:-1}}else"input"===t.tagName.toLowerCase()&&"text"===t.type&&(t.value=t.defaultValue??"")}))}static handleSetName(t){this.#c(),this.#l(),CharmStorage.saveAndRender(CharmStorage.saveTarget[t]),this.setInputVal(),1===Charm.setReload&&location.reload()}static handleSetLocalName(){this.handleSetName("local")}static handleSetSessionName(){this.handleSetName("session")}static handleUnsetName(){t.#c(),CharmStorage.deleteStorage(),t.setInputVal(),(Charm.unsetReload||t.#h())&&location.reload()}static async handleInputSync(e){const s=e.target,a=s.classList.contains(Charm.syncNow),i=s.id,r=s.value;if(""!==r)return CharmStorage.charm={nameId:i,value:r,isBound:!0,isLocal:a},void t.setInputVal();r||CharmStorage.removeEntryById(i,a)}static#h(){const t=document.querySelector("script[data-charm-unset-reload]");return t?.hasAttribute("data-charm-unset-reload")||1===Charm.unsetReload}static unsetCheckAndReload(t=null){this.#r&&(this.#o(t),location.reload())}static#o(t=null){if(this.#r)try{if("string"==typeof t)sessionStorage.setItem("focusId",t);else{const t=sessionStorage.getItem("focusId"),e=document.getElementById(t);e&&e.focus(),sessionStorage.removeItem("focusId")}}catch(t){CharmStorage.showStorageErrorMessage(),console.warn("Charm: フォーカスの保存・復元ができませんでした。",t)}}}class e{static#m="C3D1A4F7B6E2A5B8C9D1F2A3B7E6F4D9";static#u=BigInt("0x"+this.#m.match(/.{1,4}/g).reverse().join(""));static#d={};static#p=!0;static#g="";static#C=!1;static saveTarget=Object.freeze({local:!0,session:!1});static setup(){this.#g=this.#S(),this.#f(),this.#y()}static#S(){const t=document.querySelector("script[data-charm-storage]");return t?.getAttribute("data-charm-storage")??Charm.storageKeyName}static#f(){let t=null,e=null;try{t=localStorage.getItem(this.#g),t||(t=sessionStorage.getItem(this.#g),this.#p=!t,e=!!t)}catch(e){this.#b(e),t=null}if(t){try{t=JSON.parse(t)}catch(e){console.warn("Charm: 保存データを読み取れませんでした。",e),t={}}t&&"object"==typeof t&&!Array.isArray(t)||(t={}),t=Object.fromEntries(Object.entries(t).filter((([,t])=>"string"==typeof t)))}else t={};e&&(TextRenderer.setSessionMessage(!0),this.#p=this.saveTarget.session),this.#d=this.maskObjectData(t)}static clearInternalData(){this.#d={}}static saveAndRender(t=this.saveTarget.local,e=null){if(TextRenderer.update(e),0===Object.keys(this.#d).length)return;this.#p=t;let s=this.#d;s=this.maskObjectData(s);try{let e=t?localStorage:sessionStorage,a=t?sessionStorage:localStorage;e.setItem(this.#g,JSON.stringify(s)),a.removeItem(this.#g)}catch(t){this.#b(t)}finally{TextRenderer.setSessionMessage(!this.#p)}Charm.setReload&&!this.#C&&location.reload()}static deleteStorage(){this.clearInternalData(),TextRenderer.ini();try{localStorage.removeItem(this.#g),sessionStorage.removeItem(this.#g)}catch(t){this.#b(t)}finally{TextRenderer.setSessionMessage(!1)}}static get charm(){return this.#d}static set charm({nameId:t,value:e,isBound:s=!1,isLocal:a=!0}){let i=e;if(Charm.maxSize&&i.length>Charm.maxSize){let t=Charm.maxSize;const e=i.charCodeAt(t-1),s=i.charCodeAt(t);e>=55296&&e<=56319&&s>=56320&&s<=57343&&t--,i=i.slice(0,t)+"…"}t&&void 0!==i&&Object.defineProperty(this.#d,t,{value:i,writable:!0,enumerable:!0,configurable:!0}),this.#C=s,s&&this.saveAndRender(a,t)}static removeEntryById(t,e=!0){delete this.#d[t],TextRenderer.resetRowTextElements(t);let s=null;Object.keys(this.#d).length?(s=t,this.saveAndRender(e)):this.deleteStorage(),CharmInput.unsetCheckAndReload(s)}static#y(){if(!document.getElementsByClassName(Charm.nameClass).length)return;let t=!1;this.#x()&&!this.#E("sessionStorage")&&(t=!0),this.#N()&&!this.#E("localStorage")&&(t=!0),t&&this.showStorageErrorMessage()}static#x(){const t=!!document.getElementById(Charm.setSessionId),e=document.getElementsByClassName(Charm.syncNowSession).length>0;return t||e}static#N(){const t=!!document.getElementById(Charm.setNameId),e=document.getElementsByClassName(Charm.syncNow).length>0;return t||e}static#E(t){const e="__charm_test__";try{const s=window[t];return s.setItem(e,"1"),s.removeItem(e),!0}catch(t){return!1}}static#b(t){let e="その他のエラーが発生しました";t instanceof DOMException&&"QuotaExceededError"===t.name?e="ローカルストレージの容量がいっぱいです。名前変換は行わずにデフォルトネームを表示します。":t instanceof DOMException&&"SecurityError"===t.name&&(e="セキュリティ設定によりローカルストレージが使用できません。名前変換は行わずにデフォルトネームを表示します。"),this.showStorageErrorMessage(),Charm.showStorageError&&!this.#C&&alert(e),console.warn(e,t)}static showStorageErrorMessage(){const t=document.getElementsByClassName(Charm.storageErrorClass);if(t.length)for(const e of t)e.textContent=Charm.storageErrorString}static maskObjectData(t={}){return Charm.useEncryption?Object.fromEntries(Object.entries(t).map((([t,e])=>[t,this.#I(e)]))):t}static#I(t){if(!Charm.useEncryption)return t;const e=this.#u;return t.split("").map(((t,s)=>String.fromCharCode(t.charCodeAt(0)^Number(e>>(BigInt(31&s)<<2n)&0xffn)))).join("")}}class s{static SYMBOLS=Object.freeze(["&#8230;&#8230;","&#8230;","&#12540;","&#8213;&#8213;","&#12336;&#12336;","&#12336;","&#12316;","&#65281;","&#65281;&emsp;","&#65311;","&#65311;&emsp;","&#63;","&#33;","&#12289;","&#12290;","&#12539;","&#44;","&#65292;","&#8741;","&#47;","&#65295;","&#9675;&#9675;","&#9675;","&#215;&#215;","&#215;","&#9734;&#9734;","&#9734;","&#9733;&#9733;","&#9733;","&#9825;&#9825;","&#9825;","&#9734;&emsp;","&#9733;&emsp;","&#9825;&emsp;","&#9834;","&#9834;&emsp;","&#65281;&#65311;","&#65281;&#65311;&emsp;","&#x3063;","&#x3063;&#65281;","&#x3063;&#65281;&emsp;","&#x3063;&#12289;","&#x3063;&#8230;&#8230;","&#x30c3;","&#x30c3;&#65281;","&#x30c3;&#65281;&emsp;","&#x30c3;&#12289;","&#x30c3;&#8230;&#8230;"]);static#k="&#12289;";static#v="&#8230;&#8230;";static get strStutter(){return this.#k}static get strPauseEcho(){return this.#v}}class a{static#L="data-charm-before";static#w=Object.create(null);static#O=Object.create(null);static setup(){this.ini(),this.update()}static ini(){this.resetAllTextElements(),this.#w=Object.create(null),this.#O=Object.create(null)}static update(t=null){if(t)return this.#O[t]=document.getElementsByClassName(t),void this.#M(t);this.#T()}static#T(){let t=CharmStorage.charm;for(const e in t)Object.prototype.hasOwnProperty.call(t,e)&&(this.#O[e]=document.getElementsByClassName(e),this.#M(e))}static#M(t){const e=this.#O[t];this.#w[t]||(this.#w[t]=[]);for(let s=0;s<e.length;s++){const a=e[s];if(!a.getAttribute(`${this.#L}`)){const e=a.textContent;this.#w[t].includes(e)||this.#w[t].push(e);const s=this.#w[t].indexOf(e);a.setAttribute(this.#L,s)}const i=CharmStorage.charm[t];this.#R(a,i)}}static#R(t,e){let s=e;const a=new CustomOptions(t.dataset,t.classList);s=new NameGeneration(e,a.custom).gName,this.safelySetText(t,s)}static resetAllTextElements(){let t=this.#w;for(const e in t)Object.prototype.hasOwnProperty.call(t,e)&&this.resetRowTextElements(e)}static resetRowTextElements(t){if(!this.#w[t])return;const e=document.querySelectorAll(`.${t}[${this.#L}]`);this.resetTextElements(e,t)}static resetTextElements(t,e){t.forEach((t=>{const s=parseInt(t.getAttribute(`${this.#L}`));this.safelySetText(t,this.#w[e][s]),t.removeAttribute(this.#L)}))}static setSessionMessage(t=!0){let e=document.getElementById(Charm.viewRegisterSession);e&&(e.textContent=t?Charm.sessionString:"")}static safelySetText(t,e){if(!t)return void console.warn("safelySetText: 無効な要素が渡されました");const s=(new DOMParser).parseFromString(e,"text/html");t.textContent=s.body.textContent||""}}globalThis.CharmInput=t,globalThis.CharmRunner=class{static extOrder=[];static endExtOrder=[];static extMap={};static endExtMap={};static async start(){await this.runExtensions(),CharmStorage.setup(),CharmInput.setup(),TextRenderer.setup(),await this.runEExtensions()}static addExtension(t,e){this.extMap[t]=e,this.extOrder.push(t)}static addEExtension(t,e){this.endExtMap[t]=e,this.endExtOrder.push(t)}static async runExtensionsFrom(t,e){for(const s of t){const t=e[s];t?.run instanceof Function&&await t.run()}}static async runExtensions(){await this.runExtensionsFrom(this.extOrder,this.extMap)}static async runEExtensions(){await this.runExtensionsFrom(this.endExtOrder,this.endExtMap)}},globalThis.CharmStorage=e,globalThis.CUtil=s,globalThis.CustomOptions=class{#A;#B;#j;#P;#U;constructor(t,e){this.#A=t,this.#B=e,this.#j={short:!1,skip:!1,chop:!1,last:!1,stutter:!1,pause:!1,echo:!1,rev:!1,overlap:!1,vowel:!1,ini:!1,hira:!1,kana:!1,mix:!1},this.#P={count:void 0,symbol:void 0,vowelMin:!1},this.#U={short:this.#V.bind(this),skip:this.#H.bind(this),chop:this.#D.bind(this),last:this.#F.bind(this),stutter:this.#K.bind(this),pause:this.#$.bind(this),echo:this.#z.bind(this),rev:this.#G.bind(this),overlap:this.#_.bind(this),vowel:this.#J.bind(this),initial:this.#q.bind(this)},this.#Y()}get custom(){return{expression:this.#j,option:this.#P}}#Y(){for(const t in this.#U)if(this.#U[t]())break;this.#Z(),this.#Q(),this.#W()}#X(){const t=Charm.charmClassList.charmCount,e=[...Array(9)].findIndex(((e,s)=>this.#B.contains(`${t}${s+1}`)));return-1!==e?e+1:null}#tt(){const t=Charm.charmClassList.charmSymbol,e=[...Array(48)].findIndex(((e,s)=>{const a=(s+1).toString().padStart(2,"0");return this.#B.contains(`${t}${a}`)||this.#B.contains(`${t}${s+1}`)}));return-1!==e?s.SYMBOLS[e]:null}#V(){if(this.#A.charmShort)this.#P.count=+this.#A.charmShort||1;else{if(!this.#B.contains(Charm.charmClassList.charmShort))return!1;this.#P.count=this.#X()||1}return this.#j.short=!0,!0}#et(t,e,s){return!(!this.#A[e]&&!this.#B.contains(Charm.charmClassList[s]))&&(this.#j[t]=!0,!0)}#H(){return this.#et("skip","charmSkip","charmSkip")}#D(){return this.#et("chop","charmChop","charmChop")}#F(){return this.#et("last","charmLast","charmLast")}#G(){return this.#et("rev","charmRev","charmRev")}#q(){return this.#et("initial","charmInitial","charmInitial")}#K(){return!("stutter"!==this.#A.charmCall&&!this.#B.contains(Charm.charmClassList.charmStutter))&&(this.#j.stutter=!0,"stutter"===this.#A.charmCall&&(this.#P.count=+this.#A.charmSttCount||Charm.sttCountDefault,this.#P.symbol=this.#A.charmBreak||s.strStutter),this.#B.contains(Charm.charmClassList.charmStutter)&&(this.#P.count=this.#X()||Charm.sttCountDefault,this.#P.symbol=this.#tt()||s.strStutter),!0)}#$(){if("pause"===this.#A.charmCall)this.#P.symbol=this.#A.charmBreak||s.strPauseEcho;else{if(!this.#B.contains(Charm.charmClassList.charmParse))return!1;this.#P.symbol=this.#tt()||s.strPauseEcho}return this.#j.pause=!0,!0}#z(){return!("echo"!==this.#A.charmCall&&!this.#B.contains(Charm.charmClassList.charmEcho))&&(this.#j.echo=!0,"echo"===this.#A.charmCall&&(this.#P.count=+this.#A.charmEchCount||Charm.echoCountDefault,this.#P.symbol=this.#A.charmBreak||s.strPauseEcho),this.#B.contains(Charm.charmClassList.charmEcho)&&(this.#P.count=this.#X()||Charm.echoCountDefault,this.#P.symbol=this.#tt()||s.strPauseEcho),!0)}#_(){if(!this.#A.charmOverlap&&!this.#B.contains(Charm.charmClassList.charmOverlap))return!1;this.#j.overlap=!0;return this.#A.charmOverlap&&(this.#P.count=+this.#A.charmOvlCount||2),this.#B.contains(Charm.charmClassList.charmOverlap)&&(this.#P.count=this.#X()||2),!0}#J(){return!!(this.#A.charmVowel||this.#B.contains(Charm.charmClassList.charmVowel)||this.#A.charmVowelMin||this.#B.contains(Charm.charmClassList.charmVowelMin))&&(this.#j.vowel=!0,(this.#A.charmVowelMin||this.#B.contains(Charm.charmClassList.charmVowelMin))&&(this.#P.vowelMin=!0),this.#A.charmVowelCount?(this.#P.count=+this.#A.charmVowelCount||0,!0):(this.#P.count=this.#X()||0,!0))}#st(t,e,s){const a=this.#A[e];return!("on"!==a&&"1"!==a&&!this.#B.contains(Charm.charmClassList[s]))&&(this.#j[t]=!0,!0)}#Z(){return this.#st("hira","charmHira","charmHira")}#Q(){return this.#st("kana","charmKana","charmKana")}#W(){return this.#st("mix","charmMix","charmMix")}},globalThis.NameGeneration=class{#at;#it;#rt;#nt;#ht;#ot;constructor(t,e){this.#at=e.expression,this.#it=e.option,this.#rt=t,this.#nt=t,this.#ht=[],this.#ot={short:this.applyShort.bind(this),skip:this.applySkip.bind(this),chop:this.applyChop.bind(this),last:this.applyLast.bind(this),stutter:this.applyStutter.bind(this),pause:this.applyPause.bind(this),echo:this.applyEcho.bind(this),rev:this.applyReverse.bind(this),overlap:this.applyOverlap.bind(this),vowel:this.applyVowel.bind(this),initial:this.applyInitial.bind(this),hira:this.generateHira.bind(this),kana:this.generateKana.bind(this),mix:this.generateMix.bind(this)},this.executeGenerate()}get gName(){return this.#nt}executeGenerate(){this.nameSplit(),Object.keys(this.#at).forEach((t=>{if(this.#at[t]){const e=this.#ot[t];"function"==typeof e&&e()}}))}nameSplit(t=null){const e=Array.from(t??this.#rt),s=/[ぁぃぅぇぉゕゖっゃゅょゎァィゥェォヵㇰヶㇱㇲッㇳㇴㇵㇶㇷㇸㇹㇺャュョㇻㇼㇽㇾㇿヮｧｨｩｪｫｬｭｮｯ・ー]/,a=[];let i=0;for(;i<e.length;){let t=e[i];for(i++;i<e.length&&s.test(e[i]);)t+=e[i],i++;a.push(t)}if(null!==t)return a;this.#ht=a}applyShort(){const{count:t}=this.#it,e=this.#ht;if(t>=e.length)return void(this.#nt=e.join(""));const s=e.slice(0,t);s[t-1]=s[t-1].replace(/[っッーｯ・]/g,""),this.#nt=s.join("")}applySkip(){this.#ht.shift(),this.#nt=this.#ht.join("")}applyChop(){this.#ht.pop(),this.#nt=this.#ht.join("")}applyLast(){this.#nt=this.#ht[this.#ht.length-1]}applyStutter(){const{count:t,symbol:e}=this.#it,s=this.#ht[0]+e;this.#nt=s.repeat(t).slice(0,-e.length)}applyPause(){this.#nt=this.#ht.join(this.#it.symbol)}applyEcho(){const{count:t,symbol:e}=this.#it,s=this.#ht,a=[];for(let e=Math.min(t,s.length-1);e>0;e--)a.unshift(s.slice(-e).join(""));this.#nt=a.join(e)+e}applyReverse(){this.#nt=this.#ht.reverse().join("")}applyOverlap(){this.#nt=this.#ht.map((t=>t.repeat(this.#it.count))).join("")}applyVowel(){const t=["あ","ア","い","イ","う","ウ","え","エ","お","オ"],e=["ぁ","ァ","ぃ","ィ","ぅ","ゥ","ぇ","ェ","ぉ","ォ"],s=new Map([["あかさたなはまやらわがざだばぱゃぁゕゎ",0],["アカサタナハマヤラワガザダバパァヵㇵャㇻヮ",1],["いきしちにひみりゐぎじぢびぴぃ",2],["イキシチニヒミリヰギジヂビピィㇱㇶㇼ",3],["うくすつぬふむゆるぐずづぶぷゅぅっ",4],["ウクスツヌフムユルグズヅブプュゥㇰㇲッㇴㇷㇽ",5],["えけせてねへめれゑげぜでべぺぇゖ",6],["エケセテネヘメレヱゲゼデベペェヶㇸㇾ",7],["おこそとのほもよろをごぞどぼぽょぉ",8],["オコソトノホモヨロヲゴゾドボポョォㇳㇹㇺㇿ",9],["んー〜～〰ン",-1]]),a=this.#rt.slice(-1),i=this.#it,r=Math.max(1,i.count??1),n=!i.vowelMin;for(const[i,h]of s)if(a&&i.includes(a)){if(h>=0){const s=n?t[h]:e[h];this.#nt=s.repeat(r)}else this.#nt=a.repeat(r);return}this.#nt=""}applyInitial(){const t=(this.#ht[0]??"").charAt(0);if(/^[a-zA-Zａ-ｚＡ-Ｚ]/.test(t))return void(this.#nt=t.normalize("NFKC").toUpperCase());if(!/^[ぁ-ゟァ-ヿ]/.test(t))return void(this.#nt="");const e=[[/^[がぎぐげごガギグゲゴ]/,"G"],[/^[ざじずぜぞザジズゼゾ]/,t=>/[じジ]/.test(t[0])?"J":"Z"],[/^[だぢでどダヂデド]/,t=>/[ぢヂ]/.test(t[0])?"J":"D"],[/^[づヅ]/,"Z"],[/^[ばびぶべぼバビブベボ]/,"B"],[/^[ぱぴぷぺぽパピプペポ]/,"P"],[/^[ゔヴ]/,"V"],[/^[あぁアァ]/,"A"],[/^[いぃイィゐヰ]/,"I"],[/^[うぅウゥ]/,"U"],[/^[えぇエェゑヱ]/,"E"],[/^[おぉオォ]/,"O"],[/^[か-こカ-コヵ]/,"K"],[/^[さ-そサ-ソ]/,"S"],[/^[た-とタ-ト]/,t=>/[ちチ]/.test(t[0])?"C":"T"],[/^[な-のナ-ノ]/,"N"],[/^[は-ほハ-ホ]/,t=>/[ふフ]/.test(t[0])?"F":"H"],[/^[ま-もマ-モ]/,"M"],[/^[ゃ-よャ-ヨ]/,"Y"],[/^[ら-ろラ-ロ]/,"R"],[/^[わをワヲ]/,"W"],[/^[んン]/,"N"]];for(const[s,a]of e){const e=t.match(s);if(e)return void(this.#nt="function"==typeof a?a(e):a)}this.#nt=""}hiraTransform(t){return t.replace(/[ァ-ヶ]/g,(t=>String.fromCharCode(t.charCodeAt(0)-96)))}kanaTransform(t){return t.replace(/[ぁ-ゖ]/g,(t=>String.fromCharCode(t.charCodeAt(0)+96)))}generateHira(){this.#nt=this.hiraTransform(this.#nt)}generateKana(){this.#nt=this.kanaTransform(this.#nt)}generateMix(){const t=this.nameSplit(this.#nt);this.#nt=t.map(((t,e)=>e%2==0?this.kanaTransform(t):this.hiraTransform(t))).join("")}},globalThis.TextRenderer=a,document.addEventListener("DOMContentLoaded",(()=>{try{window.Charm?.run()}catch(t){console.error("Charm.run() failed:",t)}}))}();
/*! - 拡張用コードは以下に追記するか、外部ファイルとしてcharm.jsの後に読み込み - */
