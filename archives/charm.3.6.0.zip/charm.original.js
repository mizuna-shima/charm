/*!
 * Charm.js ver 3.6.0
 * Charm.js License (Revised January 14, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/charm/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */

class Charm {
  /**** 設定項目ここから ---------------------------- ****/

  // 登録する名前の入力フォームアイテム共通Class
  static nameClass = "charm";
  // 入力の自動保存のClass名
  static syncNow = "charmnow";
  // 入力の自動保存のClass名（一時保存）
  static syncNowSession = "charmnowsession";
  // 登録ボタンのId
  static setNameId = "charmset";
  // 一時登録ボタンのId
  static setSessionId = "charmsession";
  // 削除ボタンのId
  static unsetNameId = "charmunset";
  // 一時登録の表記をするid
  static viewRegisterSession = "charmsessionmsg";
  // 一時保存の際に表示できるメッセージ
  static sessionString = "（一時保存しました）";
  // localStorageまたはsessionStorageの保存キー
  static storageKeyName = "charm";
  // 簡易暗号化 使う:1 使わない:0
  static useEncryption = 0;
  // 登録できる最大文字数 オーバーした文字は「…」で登録
  // 無制限にする場合は0
  static maxSize = 50;
  // 登録または一時登録ボタンで名前登録時にページを再読み込み
  // する:1 しない:0
  static setReload = 0;
  // 名前削除時にページを再読み込み（自動保存も含む）
  // する:1 しない:0
  static unsetReload = 0;
  // Web Storageが使えないとき ウィンドウを出す:1 出さない:0
  static showStorageError = 0;
  // 響き（欠けた名前を連呼する）回数のデフォルト
  static echoCountDefault = 2;
  // 詰まり回数のデフォルト
  static sttCountDefault = 2;
  // クラスモード使用時に設定するクラス名
  static charmClassList = {
    // 名前省略
    charmShort: "charm_short",
    // 先頭文字スキップ
    charmSkip: "charm_skip",
    // 末尾カット
    charmChop: "charm_chop",
    // 最後の文字
    charmLast: "charm_last",
    // 区切り
    charmParse: "charm_pause",
    // 響き
    charmEcho: "charm_echo",
    // 重複
    charmOverlap: "charm_overlap",
    // 詰まり
    charmStutter: "charm_stutter",
    // 逆順
    charmRev: "charm_rev",
    // ひらがな
    charmHira: "charm_hira",
    // カタカナ
    charmKana: "charm_kana",
    // カナMix
    charmMix: "charm_mix",
    // 最後の母音
    charmVowel: "charm_vowel",
    // 最後の母音（小さい文字）
    charmVowelMin: "charm_vowel_min",
    // イニシャル
    charmInitial: "charm_initial",
    // 記号設定の共通
    charmSymbol: "charm_symbol",
    // 回数設定の共通
    charmCount: "charm_count",
  };

  /** v1.2以前の設定 **/
  // 登録・削除ボタンのId
  static oldSet = "charm-setname";
  static oldUnset = "charm-unsetname";

  /**** 設定項目ここまで ---------------------------- ****/

  /** 本体起動 **/
  static run() {
    const runner = globalThis?.CharmRunner;
    if (typeof runner?.start === "function") {
      runner.start();
    } else {
      console.warn("CharmRunner is not available.");
    }
  }
  static addExtension(name, ex) {
    CharmRunner.addExtension(name, ex);
  }
  static addEExtension(name, ex) {
    CharmRunner.addEExtension(name, ex);
  }
}

if (typeof window !== "undefined") {
  window.Charm = Charm;
}

(function () {
  'use strict';

  class CharmInput$1 {
    /** 
     * @type {Function|null} 入力イベントを処理するためのデバウンス関数
     */
    static #debouncedSyncHandler;

    /**
     * @type {HTMLCollectionOf<HTMLInputElement>|null} 入力フォームのDOM要素コレクション
     */
    static #items = null;
    
    /**
     * @type {boolean} 項目削除時にページをリロードするかどうかのフラグ
     */
    static #isReloadAfterUnset = false;

    static setup() {
      this.#debouncedSyncHandler = this.#debounce(this.handleInputSync, 100);
      this.#items = document.getElementsByClassName(Charm.nameClass);
      this.#isReloadAfterUnset = this.#getUnsetReload();
      this.#sessionFocusId();
      this.setupButtonHandlers();
      this.setupInputHandlers();
      this.setInputVal();
    }

    /***
     * 登録ボタン・削除ボタンのイベント設定
     */
    static setupButtonHandlers() {
      const buttonActions = [
        {
          newId: Charm.setNameId,
          oldId: Charm.oldSet,
          handler: () => this.handleSetName("local"),
        },
        {
          newId: Charm.setSessionId,
          // 一時登録は過去仕様がない
          oldId: null,
          handler: () => this.handleSetName("session"),
        },
        {
          newId: Charm.unsetNameId,
          oldId: Charm.oldUnset,
          handler: this.handleUnsetName,
        },
      ];
      buttonActions.forEach(({ newId, oldId, handler }) => {
        let button = document.getElementById(newId);
        if (!button && oldId) {
          // 新仕様のIDでボタンが見つからない場合、過去のIDをチェック
          button = document.getElementById(oldId);
        }
        if (button) {
          button.removeEventListener("click", handler, false);
          button.addEventListener("click", handler, false);
        }
      });
    }

    /***
     * リアルタイム保存用のinputイベント設定
     */
    static setupInputHandlers() {
      // 自動保存classを持つinput要素にイベントリスナーを追加
      const boundLocal = document.getElementsByClassName(Charm.syncNow);
      const boundSession = document.getElementsByClassName(Charm.boundSession);
      const handler = this.#debouncedSyncHandler;

      const addListeners = (elms) => {
        for (const elm of [...elms]) {
          for (const eventName of ["input", "compositionend"]) {
            elm.removeEventListener(eventName, handler, false);
            elm.addEventListener(eventName, handler, false);
          }
        }
      };
      addListeners(boundLocal);
      addListeners(boundSession);
    }

    /**
     * 指定した関数をデバウンス（遅延実行）して返す
     * 連続したイベントの発火を抑制し、最後の呼び出しのみを実行する
     * @private
     * @param {Function} func - デバウンス対象の関数。
     * @param {number} delay - 遅延時間（ミリ秒）。
     * @returns {Function} デバウンスされた関数。
     */
    static #debounce(func, delay) {
      let timeoutId;
      return (...args) => {
        if (timeoutId) {
          clearTimeout(timeoutId);
        }
        timeoutId = setTimeout(() => {
          func.apply(this, args);
        }, delay);
      };
    }

    /**
     * 入力フォームの値を取得し、CharmStorage.charm に保存する
     * 空文字の入力は無視される
     * @private
     */
    static #getInputVal() {
      for (const item of this.#items) {
        if (!item || item.value.length < 1) continue;
        CharmStorage.charm = {
          nameId: item.id,
          value: item.value,
        };
      }
    }

    /**
     * CharmStorage.charm の保存内容を各入力フォームに反映する。
     * データが存在しない場合は空文字を設定する。
     */
    static setInputVal() {
      [...this.#items].forEach((item) => {
        if (item.id in CharmStorage.charm) {
          item.value = CharmStorage.charm[item.id];
        } else {
          item.value = "";
        }
      });
    }

    /***
     * 名前登録ボタンのクリック時処理（ローカル or セッション保存）
     * @param {"local" | "session"} type - 保存種別
     */
    static handleSetName(type) {
      this.#getInputVal();
      CharmStorage.saveAndRender(CharmStorage.saveTarget[type]);
      this.setInputVal();
      if (Charm.setReload === 1) location.reload();
    }

    /***
     * 登録ボタンのクリック時処理（ローカル保存）
     */
    static handleSetLocalName() {
      this.handleSetName("local");
    }

    /***
     * 一時登録ボタンのクリック時処理（セッション保存）
     */
    static handleSetSessionName() {
      this.handleSetName("session");
    }

    /***
     * 削除ボタンのクリック時処理（ストレージ削除）
     */
    static handleUnsetName() {
      CharmStorage.deleteStorage();
      CharmInput$1.setInputVal();
      if (Charm.unsetReload) location.reload();
    }

    /***
     * 入力イベント発火時（リアルタイム保存）
     */
    static async handleInputSync(e) {
      const target = e.target;
      const isLocal = target.classList.contains(Charm.syncNow);
      const nameId = target.id;
      const name = target.value;

      if (name !== "") {
        CharmStorage.charm = {
          nameId: nameId,
          value: name,
          isBound: true,
          isLocal: isLocal,
        };
        CharmInput$1.setInputVal();
        return;
      }

      if (!name) CharmStorage.removeEntryById(nameId, isLocal);
    }

    /**
     * unset操作後にページをリロードすべきかどうかを判定する
     * - HTMLの `<script>` タグに `data-charm-unset-reload` 属性がある場合、それを優先
     * - なければ `Charm.unsetReload === 1` で判断
     * @private
     * @returns {boolean} リロードすべきなら true、そうでなければ false。
     */
    static #getUnsetReload() {
      // scriptタグのdataに別指定セットされていれば取得（優先）
      const script = document.querySelector("script[data-charm-unset-reload]");
      return (
        script?.hasAttribute("data-charm-unset-reload") || Charm.unsetReload === 1
      );
    }

    /**
     * unsetReloadが有効のときリロードを実行
     * @param {string|null} nameId - 操作中の名前ID。自動保存の場合のみ設定
     */
    static unsetCheckAndReload(nameId = null) {
      if (this.#isReloadAfterUnset) {
        this.#sessionFocusId(nameId);
        location.reload();
      }
    }

    /**
     * セッションストレージにnameIdをセットまたは取得してフォーカス・削除
     * ただし、リロード直後でない場合は処理をスキップ
     * @private
     * @param {string|null} nameId - セットする場合は文字列。未指定（null）の場合は取得モード。
     */
    static #sessionFocusId(nameId = null) {
      if (!this.#isReloadAfterUnset) return;

      if (typeof nameId === "string") {
        sessionStorage.setItem("focusId", nameId);
      } else {
        const focusId = sessionStorage.getItem("focusId");
        const elm = document.getElementById(focusId);
        if (elm) {
          elm.focus();
        }
        sessionStorage.removeItem("focusId");
      }
    }
  }

  class CharmRunner {
    /***
     * 拡張機能の管理（内部用）
     */
    static extOrder = [];
    static endExtOrder = [];
    static extMap = {};
    static endExtMap = {};

    /***
     * Charm本体の初期化・起動
     * - CharmStorageクラスで保存内容読み込みor初期化
     * - CharmInputクラスでイベント監視を開始
     * - ElementクラスでDOM置換や表示処理を実行
     * - 拡張の実行順序：前→本体→後
     */
    static async start() {
      await this.runExtensions();

      CharmStorage.setup();
      CharmInput.setup();
      TextRenderer.setup();

      // 終了後拡張実行
      await this.runEExtensions();
    }

    /***
     * 拡張を追加する（本体前拡張）
     * @param {string} name
     * @param {object} ex
     */
    static addExtension(name, ex) {
      this.extMap[name] = ex;
      this.extOrder.push(name);
    }

    /***
     * 拡張を追加する（本体後拡張）
     * @param {string} name
     * @param {object} ex
     */
    static addEExtension(name, ex) {
      this.endExtMap[name] = ex;
      this.endExtOrder.push(name);
    }

    /***
     * 拡張をすべて実行する
     * @param {string[]} order 拡張名の順序リスト
     * @param {Object} map 拡張名→拡張オブジェクトのマップ
     */
    static async runExtensionsFrom(order, map) {
      for (const extName of order) {
        const ex = map[extName];
        if (ex?.run instanceof Function) {
          await ex.run();
        }
      }
    }

    /***
     * 拡張をすべて実行する（本体処理前）
     */
    static async runExtensions() {
      await this.runExtensionsFrom(this.extOrder, this.extMap);
    }

    /***
     * 拡張をすべて実行する（本体処理後）
     */
    static async runEExtensions() {
      await this.runExtensionsFrom(this.endExtOrder, this.endExtMap);
    }
  }

  class CharmStorage$1 {
    /**
     * @type {string} 暗号化に使用するキー（固定文字列）
     */
    static #eKey = "C3D1A4F7B6E2A5B8C9D1F2A3B7E6F4D9";

    /**
     * @type {bigint} 暗号化キーを変換したBigInt値
     */
    static #xKey = BigInt(
      "0x" +
        this.#eKey
          .match(/.{1,4}/g)
          .reverse()
          .join("")
    );

    /**
     * @type {Object.<string, string>} 保存データのオブジェクト
     */
    static #charm = {};

    /**
     * @type {boolean} データをlocalStorageに保存するかどうか
     */
    static #isLocal = true;

    /**
     * @type {string} 使用するストレージのキー名
     */
    static #storageName = "";

    /**
     * @type {boolean} 自動保存が有効かどうか
     */
    static #isBound = false;

    /**
     * @type {{local: boolean, session: boolean}} 保存先ストレージの区分定義
     */
    static saveTarget = Object.freeze({
      local: true,
      session: false,
    });

    /**
     * CharmStorageの初期設定を行う。
     * - ストレージキー名を取得
     * - ストレージから保存済みデータを読み込む
     * - 自動保存メッセージの表示なども含む
     */
    static setup() {
      this.#storageName = this.#getKeyParameter();
      this.#initialLoad();
    }

    /**
     * ストレージキーの取得（内部用）
     * @returns {string} - 'data-charm-storage'の値、またはCharm.storageKeyNameの値
     */
    static #getKeyParameter() {
      // scriptタグのdataに別指定セットされていれば取得（優先）
      const script = document.querySelector("script[data-charm-storage]");
      return script?.getAttribute("data-charm-storage") ?? Charm.storageKeyName;
    }

    /**
     * localStorageまたはsessionStorageからのデータ取得を試みる（内部用）
     */
    static #initialLoad() {
      let data = null;
      let isSaveSession = null;

      try {
        data = localStorage.getItem(this.#storageName);

        if (!data) {
          data = sessionStorage.getItem(this.#storageName);
          this.#isLocal = !data ? true : false;
          isSaveSession = data ? true : false;
        }
      } catch (e) {
        // localStorageまたはsessionStorageへのアクセスに失敗
        this.#handleStorageError(e);
        data = null;
      }

      if (data) {
        data = JSON.parse(data);
        if (!data || typeof data !== "object") data = {};
      } else {
        data = {};
      }

      // 一時保存されていた場合は一時保存メッセージを表示し、状態を保持しておく
      if (isSaveSession) {
        TextRenderer.setSessionMessage(true);
        this.#isLocal = this.saveTarget.session;
      }

      // マスキング判定と処理を通す
      this.#charm = this.maskObjectData(data);
    }

    /**
     * 内部に保持している保存データをすべて初期化する（ストレージには影響しない）。
     */
    static clearInternalData() {
      this.#charm = {};
    }

    /**
     * 保存とDOM更新呼び出しを行う
     * @param {boolean} isLocal true=localStorage / false=sessionStorage
     * @param {string} nameId 名前ID
     */
    static saveAndRender(isLocal = this.saveTarget.local, nameId = null) {
      TextRenderer.update(nameId);

      if (Object.keys(this.#charm).length === 0) return;

      // 利用する方のStorage
      let onSt = isLocal ? localStorage : sessionStorage;
      // 利用しない方のStorage
      let offSt = isLocal ? sessionStorage : localStorage;

      this.#isLocal = isLocal;

      // マスキング
      let data = this.#charm;
      data = this.maskObjectData(data);

      try {
        onSt.setItem(this.#storageName, JSON.stringify(data));
        offSt.removeItem(this.#storageName);
      } catch (e) {
        this.#handleStorageError(e);
      } finally {
        TextRenderer.setSessionMessage(!this.#isLocal);
      }

      if (Charm.setReload && !this.#isBound) {
        location.reload();
      }
    }

    /**
     * localStorageとsessionStorageの対象キーを削除し、UIも初期状態に戻す。
     * DOM初期化も同時に実行する。
     */
    static deleteStorage() {
      this.clearInternalData();
      TextRenderer.ini();

      try {
        localStorage.removeItem(this.#storageName);
        sessionStorage.removeItem(this.#storageName);
      } catch (e) {
        this.#handleStorageError(e);
      } finally {
        TextRenderer.setSessionMessage(false);
      }
    }

    /**
     * 現在の保存内容を取得
     */
    static get charm() {
      return this.#charm;
    }

    /**
     * 登録データを更新・保存する
     * @param {Object} param nameId, value, isBound?, isLocal?
     */
    static set charm({ nameId, value, isBound = false, isLocal = true }) {
      let val = value;

      // 文字数が登録上限数を超えていた場合はカットして丸める
      if (Charm.maxSize && val.length > Charm.maxSize) {
        val = val.slice(0, Charm.maxSize) + "…";
      }

      if (nameId && val !== undefined) {
        this.#charm[nameId] = val;
      }

      this.#isBound = isBound;

      if (isBound) {
        this.saveAndRender(isLocal, nameId);
      }
    }

    /**
     * 指定したnameIdのデータを削除する。
     * 必要に応じてストレージ全体の初期化、または再保存＋リロードを行う。
     * @param {string} nameId - 削除対象のキー名
     * @param {boolean} isLocal - 削除対象がlocalStorageかどうか
     */
    static removeEntryById(nameId, isLocal = true) {
      delete this.#charm[nameId];
      TextRenderer.resetRowTextElements(nameId);

      let focusId = null;

      // 1つも登録されていない場合はstorageのキーごと削除
      if (!Object.keys(this.#charm).length) {
        this.deleteStorage();
      } else {
        focusId = nameId;
        this.saveAndRender(isLocal);
      }

      CharmInput.unsetCheckAndReload(focusId);
    }

    /**
     * ストレージ操作中の例外処理
     * @param {DOMException} e
     */
    static #handleStorageError(e) {
      let msg = "その他のエラーが発生しました";
      if (e instanceof DOMException && e.name === "QuotaExceededError") {
        msg =
          "ローカルストレージの容量がいっぱいです。名前変換は行わずにデフォルトネームを表示します。";
      } else if (e instanceof DOMException && e.name === "SecurityError") {
        msg =
          "セキュリティ設定によりローカルストレージが使用できません。名前変換は行わずにデフォルトネームを表示します。";
      }
      // アラート表示を有効にしている、かつ自動保存ではない場合はアラート表示
      // 初回読み込みでは自動保存に関係なく表示
      if (Charm.showStorageError && !this.#isBound) {
        alert(msg);
      }
      console.warn(msg, e);
    }

    /**
     * 保存／復元共通のマスキング処理
     * `Charm.useEncryption` が有効であれば、全データを変換する。
     * @param {Object} data
     * @returns {Object}
     */
    static maskObjectData(data = {}) {
      if (!Charm.useEncryption) return data;

      return Object.fromEntries(
        Object.entries(data).map(([key, value]) => [
          key,
          this.#maskProcess(value),
        ])
      );
    }

    /**
     * マスキング処理
     * @private
     * @param {string} text 対象テキスト
     * @returns {string} 変換後テキスト
     */
    static #maskProcess(text) {
      if (!Charm.useEncryption) return text;
      const k = this.#xKey;
      return Array.from(text, (c, i) =>
        String.fromCharCode(
          c.charCodeAt(0) ^ Number((k >> (BigInt(i & 31) << 2n)) & 0xffn)
        )
      ).join("");
    }
  }

  class CUtil {
    /**
     * 変更不可な定数・内部用マジック変数類
     */

    // クラスモード使用時の記号
    static SYMBOLS = Object.freeze([
      "&#8230;&#8230;",
      "&#8230;",
      "&#12540;",
      "&#8213;&#8213;",
      "&#12336;&#12336;",
      "&#12336;",
      "&#12316;",
      "&#65281;",
      "&#65281;&emsp;",
      "&#65311;",
      "&#65311;&emsp;",
      "&#63;",
      "&#33;",
      "&#12289;",
      "&#12290;",
      "&#12539;",
      "&#44;",
      "&#65292;",
      "&#8741;",
      "&#47;",
      "&#65295;",
      "&#9675;&#9675;",
      "&#9675;",
      "&#215;&#215;",
      "&#215;",
      "&#9734;&#9734;",
      "&#9734;",
      "&#9733;&#9733;",
      "&#9733;",
      "&#9825;&#9825;",
      "&#9825;",
      "&#9734;&emsp;",
      "&#9733;&emsp;",
      "&#9825;&emsp;",
      "&#9834;",
      "&#9834;&emsp;",
      "&#65281;&#65311;",
      "&#65281;&#65311;&emsp;",
      "&#x3063;",
      "&#x3063;&#65281;",
      "&#x3063;&#65281;&emsp;",
      "&#x3063;&#12289;",
      "&#x3063;&#8230;&#8230;",
      "&#x30c3;",
      "&#x30c3;&#65281;",
      "&#x30c3;&#65281;&emsp;",
      "&#x30c3;&#12289;",
      "&#x30c3;&#8230;&#8230;",
    ]);

    // data指定の詰まりデフォルト文字
    static #strStutter = "&#12289;"; // 、
    // data指定の区切り、響きデフォルト文字
    static #strPauseEcho = "&#8230;&#8230;"; // ……

    /**
     * data指定の詰まりデフォルト文字を取得
     * @returns {string}
     */
    static get strStutter() {
      return this.#strStutter;
    }

    /**
     * data指定の区切り・響きデフォルト文字を取得
     * @returns {string}
     */
    static get strPauseEcho() {
      return this.#strPauseEcho;
    }
  }

  class CustomOptions$1 {
    /**
     * @type {Object} data-* 属性の集合（HTMLElement.dataset）
     * @private
     */
    #dataset;

    /**
     * @type {DOMTokenList} class属性のクラスリスト（HTMLElement.classList）
     * @private
     */
    #classList;

    /**
     * @type {Object} 変換表現のチェックリスト
     * @private
     */
    #exp;

    /**
     * @type {Object} オプションのチェックリスト
     * @private
     */
    #opt;

    /**
     * @type {Function[]} チェック用の処理関数の一覧（順番に評価）
     * @private
     */
    #checkMap;

    /**
     * カスタム変換オプションの初期化処理
     * @param {Object} dataset HTML要素の data-* 属性集合
     * @param {DOMTokenList} classList HTML要素のクラスリスト
     */
    constructor(dataset, classList) {
      this.#dataset = dataset;
      this.#classList = classList;
      this.#exp = {
        short: false,
        skip: false,
        chop: false,
        last: false,
        stutter: false,
        pause: false,
        echo: false,
        rev: false,
        overlap: false,
        vowel: false,
        ini: false,
        hira: false,
        kana: false,
        mix: false,
      };
      this.#opt = {
        count: undefined,
        symbol: undefined,
        vowelMin: false,
      };

      this.#checkMap = {
        short: this.#checkShort.bind(this),
        skip: this.#checkSkip.bind(this),
        chop: this.#checkChop.bind(this),
        last: this.#checkLast.bind(this),
        stutter: this.#checkStutter.bind(this),
        pause: this.#checkPause.bind(this),
        echo: this.#checkEcho.bind(this),
        rev: this.#checkReverse.bind(this),
        overlap: this.#checkOverlap.bind(this),
        vowel: this.#checkVowel.bind(this),
        initial: this.#checkInitial.bind(this),
      };

      this.#executeChecks();
    }

    get custom() {
      return {
        expression: this.#exp,
        option: this.#opt,
      };
    }

    /**
     * 各カスタム変換のチェック関数を順に実行し、最初に一致した表現に応じてcustomに記録する
     * hira/kana/mix は同時指定もあり得るため別処理で後から評価
     * @private
     */
    #executeChecks() {
      for (const key in this.#checkMap) {
        if (this.#checkMap[key]()) break;
      }
      // 以下は他のカスタムと同時指定可能なので別処理とする（ひらがな、カタカナ、Mix）
      this.#checkHira();
      this.#checkKana();
      this.#checkMix();
    }

    /**
     * クラスリストから「繰り返し回数」を抽出（例: .charm-count3 → 3）
     * @private
     * @returns {number|null} 見つかった場合は1～9、なければ null
     */
    #getClassCount() {
      const countStr = Charm.charmClassList.charmCount;
      // countStr + 数字（1〜9）という形式のクラス名を探す
      const index = [...Array(9)].findIndex((_, i) =>
        this.#classList.contains(`${countStr}${i + 1}`)
      );
      return index !== -1 ? index + 1 : null;
    }

    /**
     * オプションの記号を取得するためのクラス名を抽出
     * @private
     * @returns {string|null} 見つかったオプションの記号、なければnull
     */
    #getClassSymbol() {
      const symbolStr = Charm.charmClassList.charmSymbol;
      const index = [...Array(48)].findIndex((_, i) => {
        // 2桁で0埋め
        const numStr = (i + 1).toString().padStart(2, "0");
        return (
          this.#classList.contains(`${symbolStr}${numStr}`) ||
          this.#classList.contains(`${symbolStr}${i + 1}`)
        );
      });
      return index !== -1 ? CUtil.SYMBOLS[index] : null;
    }

    /**
     * 省略表現をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkShort() {
      if (this.#dataset.charmShort) {
        // dataにセットされている値を数値化できない場合は1文字の省略とする
        this.#opt.count = +this.#dataset.charmShort || 1;
      } else if (this.#classList.contains(Charm.charmClassList.charmShort)) {
        // クラスでの回数指定をチェック、未指定のときはデフォルトをセット
        this.#opt.count = this.#getClassCount() || 1;
      } else {
        return false;
      }
      this.#exp.short = true;
      return true;
    }

    /**
     * datasetまたはclassListに指定があれば true を返し、custom.expression にフラグを立てる
     * @private
     * @param {string} expressionKey - 記録する custom.expression のキー
     * @param {string} datasetKey - チェック対象の dataset のキー
     * @param {string} classKey - チェック対象の classList のキー（Charm.charmClassList 内のキー）
     * @returns {boolean} 指定が見つかれば true
     */
    #checkSimple(expressionKey, datasetKey, classKey) {
      if (
        this.#dataset[datasetKey] ||
        this.#classList.contains(Charm.charmClassList[classKey])
      ) {
        this.#exp[expressionKey] = true;
        return true;
      }
      return false;
    }

    /**
     * 先頭文字スキップをチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkSkip() {
      return this.#checkSimple("skip", "charmSkip", "charmSkip");
    }

    /**
     * 末尾カットをチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkChop() {
      return this.#checkSimple("chop", "charmChop", "charmChop");
    }

    /**
     * 最後の文字取得をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkLast() {
      return this.#checkSimple("last", "charmLast", "charmLast");
    }

    /**
     * 逆順表現をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkReverse() {
      return this.#checkSimple("rev", "charmRev", "charmRev");
    }

    /**
     * イニシャル表現をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkInitial() {
      return this.#checkSimple("initial", "charmInitial", "charmInitial");
    }

    /**
     * 詰まり表現をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkStutter() {
      if (
        this.#dataset.charmCall === "stutter" ||
        this.#classList.contains(Charm.charmClassList.charmStutter)
      ) {
        this.#exp.stutter = true;
      } else {
        // 指定がなければ以降は処理しない
        return false;
      }

      if (this.#dataset.charmCall === "stutter") {
        // 回数指定と記号をチェック、dataにセットされている値を数値化できない場合はデフォルトをセット
        this.#opt.count =
          +this.#dataset.charmSttCount || Charm.sttCountDefault;
        this.#opt.symbol =
          this.#dataset.charmBreak || CUtil.strStutter;
      }
      if (this.#classList.contains(Charm.charmClassList.charmStutter)) {
        // クラスでの回数指定と記号をチェック、未指定のときはデフォルトをセット
        this.#opt.count =
          this.#getClassCount() || Charm.sttCountDefault;
        this.#opt.symbol = this.#getClassSymbol() || CUtil.strStutter;
      }
      return true;
    }

    /**
     * 区切り表現をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkPause() {
      if (this.#dataset.charmCall === "pause") {
        this.#opt.symbol =
          this.#dataset.charmBreak || CUtil.strPauseEcho;
      } else if (this.#classList.contains(Charm.charmClassList.charmParse)) {
        this.#opt.symbol = this.#getClassSymbol() || CUtil.strPauseEcho;
      } else {
        return false;
      }
      this.#exp.pause = true;
      return true;
    }

    /**
     * 響き表現をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkEcho() {
      if (
        this.#dataset.charmCall === "echo" ||
        this.#classList.contains(Charm.charmClassList.charmEcho)
      ) {
        this.#exp.echo = true;
      } else {
        return false;
      }

      if (this.#dataset.charmCall === "echo") {
        this.#opt.count =
          +this.#dataset.charmEchCount || Charm.echoCountDefault;
        this.#opt.symbol =
          this.#dataset.charmBreak || CUtil.strPauseEcho;
      }
      if (this.#classList.contains(Charm.charmClassList.charmEcho)) {
        this.#opt.count =
          this.#getClassCount() || Charm.echoCountDefault;
        this.#opt.symbol = this.#getClassSymbol() || CUtil.strPauseEcho;
      }
      return true;
    }

    /**
     * 重ね表現をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkOverlap() {
      if (
        this.#dataset.charmOverlap ||
        this.#classList.contains(Charm.charmClassList.charmOverlap)
      ) {
        this.#exp.overlap = true;
      } else {
        return false;
      }
      // 重ね表現のデフォルト設定
      const overlapCount = 2;
      if (this.#dataset.charmOverlap) {
        this.#opt.count =
          +this.#dataset.charmOvlCount || overlapCount;
      }

      if (this.#classList.contains(Charm.charmClassList.charmOverlap)) {
        this.#opt.count = this.#getClassCount() || overlapCount;
      }
      return true;
    }

    /**
     * 母音のばし表現をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkVowel() {
      if (
        this.#dataset.charmVowel ||
        this.#classList.contains(Charm.charmClassList.charmVowel) ||
        this.#dataset.charmVowelMin ||
        this.#classList.contains(Charm.charmClassList.charmVowelMin)
      ) {
        this.#exp.vowel = true;
      } else {
        return false;
      }

      if (
        this.#dataset.charmVowelMin ||
        this.#classList.contains(Charm.charmClassList.charmVowelMin)
      ) {
        this.#opt.vowelMin = true;
      }

      if (this.#dataset.charmVowelCount) {
        this.#opt.count = +this.#dataset.charmVowelCount || 0;
        return true;
      }
      this.#opt.count = this.#getClassCount() || 0;
      return true;
    }

    /**
     * data-* または classList に指定があるかどうかを共通処理で確認する
     * @private
     * @param {string} expressionKey - this.#exp のキー
     * @param {string} datasetKey - dataset に含まれる属性名
     * @param {string} classKey - classList に含まれるべきクラス名
     * @returns {boolean} 条件に合致すれば true
     */
    #checkFlag(expressionKey, datasetKey, classKey) {
      const val = this.#dataset[datasetKey];
      if (
        val === "on" ||
        val === "1" ||
        this.#classList.contains(Charm.charmClassList[classKey])
      ) {
        this.#exp[expressionKey] = true;
        return true;
      }
      return false;
    }

    /**
     * ひらがな変換指定をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkHira() {
      return this.#checkFlag("hira", "charmHira", "charmHira");
    }

    /**
     * カタカナ変換指定をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkKana() {
      return this.#checkFlag("kana", "charmKana", "charmKana");
    }

    /**
     * ひらがなカタカナ交互変換（mix）をチェックする
     * @private
     * @returns {boolean} 該当指定が見つかれば true
     */
    #checkMix() {
      return this.#checkFlag("mix", "charmMix", "charmMix");
    }
  }

  class NameGeneration$1 {
    /**
     * カスタム変換指定情報（CustomOptionsで解析されたオブジェクトのexpression）
     * @type {Object.<string, boolean>}
     */
    #expression;

    /**
     * カスタム変換指定情報（CustomOptionsで解析されたオブジェクトのoption）
     * @type {Object<string, boolean>}
     */
    #option;

    /**
     * 変換前の元の名前文字列
     * @type {string}
     */
    #name;

    /**
     * 変換後の名前文字列
     * @type {string}
     */
    #generateName;

    /**
     * 自然な区切りで分割された名前配列
     * @type {string[]}
     */
    #splitName;

    /**
     * 各カスタム変換のメソッドをまとめたマッピング
     * @type {Object.<string, Function>}
     */
    #customMap;

    /**
     * @param {string} name - 加工対象の名前
     * @param {{ expression: Object.<string, boolean>, option: Object }} custom - CustomOptionsから渡される指定オブジェクト
     */
    constructor(name, custom) {
      this.#expression = custom.expression;
      this.#option = custom.option;
      this.#name = name;
      this.#generateName = name;
      this.#splitName = [];

      this.#customMap = {
        short: this.applyShort.bind(this),
        skip: this.applySkip.bind(this),
        chop: this.applyChop.bind(this),
        last: this.applyLast.bind(this),
        stutter: this.applyStutter.bind(this),
        pause: this.applyPause.bind(this),
        echo: this.applyEcho.bind(this),
        rev: this.applyReverse.bind(this),
        overlap: this.applyOverlap.bind(this),
        vowel: this.applyVowel.bind(this),
        initial: this.applyInitial.bind(this),
        hira: this.generateHira.bind(this),
        kana: this.generateKana.bind(this),
        mix: this.generateMix.bind(this),
      };

      this.executeGenerate();
    }

    get gName() {
      return this.#generateName;
    }

    /***
     * カスタム変換を実行する
     */
    executeGenerate() {
      this.nameSplit();
      Object.keys(this.#expression).forEach((expression) => {
        if (this.#expression[expression]) {
          const method = this.#customMap[expression];
          if (typeof method === "function") {
            method();
          }
        }
      });
    }

    /**
     * 名前を自然な区切りで分割する
     * 小文字・促音・長音記号などを先行文字に結合して1単位として分割
     *
     * @param {string|null} nameStr - 分割する対象の文字列。省略時は元の名前（this.#name）を使用。
     * @returns {string[]|void} 引数が指定された場合は分割配列を返す。省略時は this.#splitName に格納する。
     */
    nameSplit(nameStr = null) {
      const name = nameStr ?? this.#name;
      const smallCharRegex =
        /[ぁぃぅぇぉゕゖっゃゅょゎァィゥェォヵㇰヶㇱㇲッㇳㇴㇵㇶㇷㇸㇹㇺャュョㇻㇼㇽㇾㇿヮｧｨｩｪｫｬｭｮｯ・ー]/;
      const splitName = [];
      let i = 0;

      // 1文字ずつ処理して、「小文字など」が続くかぎり1チャンクとして結合
      while (i < name.length) {
        let chunk = name[i]; // 現在の文字
        i++;

        // 次の文字が「小さい文字」等なら続けて結合
        while (i < name.length && smallCharRegex.test(name[i])) {
          chunk += name[i];
          i++;
        }
        splitName.push(chunk);
      }

      // 引数が指定されていたら、結果を返して処理終了
      if (nameStr) return splitName;

      this.#splitName = splitName;
    }

    /**
     * 省略変換：指定した文字数だけ名前の先頭から表示する
     */
    applyShort() {
      const { count } = this.#option;
      const parts = this.#splitName;

      if (count >= parts.length) {
        this.#generateName = parts.join("");
        return;
      }

      const result = parts.slice(0, count);

      // 最後の文字から装飾的な文字（促音・長音記号など）を取り除く
      result[count - 1] = result[count - 1].replace(/[っッーｯ・]/g, "");
      this.#generateName = result.join("");
    }

    /**
     * 先頭スキップ：名前の最初の文字をスキップして変換
     */
    applySkip() {
      this.#splitName.shift();
      this.#generateName = this.#splitName.join("");
    }

    /**
     * 末尾カット：名前の最後の文字を削除して変換
     */
    applyChop() {
      this.#splitName.pop();
      this.#generateName = this.#splitName.join("");
    }
    /**
     * 最後の文字のみを表示する
     */
    applyLast() {
      this.#generateName = this.#splitName[this.#splitName.length - 1];
    }

    /**
     * 詰まり表現：最初の文字＋記号を複数回繰り返す
     * 例）["あ", "い", "う"], count=3, symbol="・" → "あ・あ・あ"
     */
    applyStutter() {
      const { count, symbol } = this.#option;

      // 最初の文字（例：「あ」）に記号（例：「・」）を付けた基本単位（例：「あ・」）を作成
      const base = this.#splitName[0] + symbol;

      // base を指定回数繰り返し → 最後の記号だけ余分なので slice で除去
      // 例：「あ・」×3 = 「あ・あ・あ・」→ 最後の「・」を除いて「あ・あ・あ」
      this.#generateName = base.repeat(count).slice(0, -symbol.length);
    }

    /**
     * 区切り変換：文字ごとに記号を挟んで表示する
     */
    applyPause() {
      this.#generateName = this.#splitName.join(this.#option.symbol);
    }

    /**
     * 響き表現：末尾から少しずつ切り出して記号でつなぐ
     * 例）["あ", "い", "う", "え", "お"], count=3, symbol="・" → "えお・うえお・いうえお・"
     */
    applyEcho() {
      const { count, symbol } = this.#option;
      const names = this.#splitName;

      // 安全な最大回数に制限
      const max = Math.min(count, names.length - 1); 
      const result = [];

      // namesの後方から max 回、少しずつ長くなる形で文字列を作成
      for (let i = max; i > 0; i--) {
        result.unshift(names.slice(-i).join(""));
      }

      // 記号で連結し、最後に記号をもう1つ追加
      this.#generateName = result.join(symbol) + symbol;
    }

    /**
     * 逆順表示：文字列を反転して変換
     */
    applyReverse() {
      this.#generateName = this.#splitName.reverse().join("");
    }

    /**
     * 重複表示：各文字を指定回数繰り返して変換
     */
    applyOverlap() {
      this.#generateName = this.#splitName
        .map((elm) => elm.repeat(this.#option.count))
        .join("");
    }

    /**
     * 母音のばし：最後の文字に応じた母音を繰り返し表示する
     */
    applyVowel() {
      const repVowelsUppercase = [
        "あ",
        "ア",
        "い",
        "イ",
        "う",
        "ウ",
        "え",
        "エ",
        "お",
        "オ",
      ];
      const repVowelsLowercase = [
        "ぁ",
        "ァ",
        "ぃ",
        "ィ",
        "ぅ",
        "ゥ",
        "ぇ",
        "ェ",
        "ぉ",
        "ォ",
      ];
      // 母音パターンとその対応する母音
      const vowelPatterns = new Map([
        ["あかさたなはまやらわがざだばぱゃぁゕゎ", 0],
        ["アカサタナハマヤラワガザダナパァヵㇵャㇻヮ", 1],
        ["いきしちにひみりゐぎじぢびぃヰ", 2],
        ["イキシチニヒミリギジヂビィㇱㇶㇼ", 3],
        ["うくすつぬふむゆるぐずづぶぷゅぅっ", 4],
        ["ウクスヌヌフムユルグズヅブプュゥㇰㇲッㇴㇷㇽ", 5],
        ["えけせてねへめれゑげぜでべぺぇゖ", 6],
        ["エケセテネヘメレゲゼデベペェヶㇸㇾ", 7],
        ["おこそとのほもよろをごぞどぼぽょぉ", 8],
        ["オコソトノホモヨロヲゴゾドボポョォㇳㇹㇺㇿ", 9],
        ["んー〜～〰ン", -1],
      ]);

      // 判定と加工のために最後の要素とりだし
      const lastVal = this.#name.slice(-1);
      const opt = this.#option;

      // 繰り返し回数 最低1回
      const count = Math.max(1, opt.count ?? 1);
      // 返す母音が大きい文字か小さい文字か
      const isUppercase = !opt.vowelMin;

      for (const [pattern, index] of vowelPatterns) {
        // 最後の文字が、現在の母音パターンに一致するかを確認
        if (new RegExp(`[${pattern}]$`).test(lastVal)) {
          if (index >= 0) {
            // 対応する母音インデックスがある場合は、母音表から取得
            const vowel = isUppercase
              ? repVowelsUppercase[index] // 大きい文字（あ、い、う 等）
              : repVowelsLowercase[index]; // 小さい文字（ぁ、ぃ、ぅ 等）
            this.#generateName = vowel.repeat(count); // 指定回数だけ母音を繰り返す
          } else {
            // 「ん」「ー」など変換不要な文字はそのまま繰り返す
            this.#generateName = lastVal.repeat(count);
          }
          // 最初にマッチしたパターンで確定するので、ループ終了
          return;
        }
      }

      // 母音や特別な文字が見つからなかった場合は空文字を設定
      this.#generateName = "";
    }

    /**
     * イニシャル変換：日本語または英語の名前をアルファベット1文字に変換
     * - 英語名の場合：先頭文字を正規化・大文字化して使用
     * - 日本語名の場合：対応するイニシャル（母音/子音）を割り当て
     * - 濁音・半濁音や特定文字は個別ルールで柔軟に対応
     */
    applyInitial() {
      // 先頭要素の先頭一文字をチェック
      const firstChar = this.#splitName[0].charAt(0);

      // ローマ字(a-zA-Z)なら先頭文字を大文字にして格納
      if (/^[a-zA-Zａ-ｚＡ-Ｚ]/.test(firstChar)) {
        // 全角を半角に正規化し、大文字化
        this.#generateName = firstChar.normalize("NFKC").toUpperCase();
        return;
      }

      // 先頭一文字が平仮名またはカタカナ以外
      if (!/^[ぁ-ゟァ-ヿ]/.test(firstChar)) {
        this.#generateName = "";
        return;
      }

      // イニシャル変換ルールを [正規表現, 値 or 関数] のペアでまとめる
      const rules = [
        [/^[がぎぐげごガギグゲゴ]/, "G"],
        [/^[ざじずぜぞザジズゼゾ]/, (m) => (/[じジ]/.test(m[0]) ? "J" : "Z")],
        [/^[だぢでどダヂデド]/, (m) => (/[ぢヂ]/.test(m[0]) ? "J" : "D")],
        [/^[づヅ]/, "Z"],
        [/^[ばびぶべぼバビブベボ]/, "B"],
        [/^[ぱぴぷぺぽパピプペポ]/, "P"],
        // 特殊
        [/^[ゔヴ]/, "V"],
        // 母音
        [/^[あぁアァ]/, "A"],
        [/^[いぃイィゐヰ]/, "I"],
        [/^[うぅウゥ]/, "U"],
        [/^[えぇエェゑヱ]/, "E"],
        [/^[おぉオォ]/, "O"],
        // 子音グループ
        [/^[か-こカ-コヵ]/, "K"],
        [/^[さ-そサ-ソ]/, "S"],
        [/^[た-とタ-ト]/, (m) => (/[ちチ]/.test(m[0]) ? "C" : "T")],
        [/^[な-のナ-ノ]/, "N"],
        [/^[は-ほハ-ホ]/, (m) => (/[ふフ]/.test(m[0]) ? "F" : "H")],
        [/^[ま-もマ-モ]/, "M"],
        [/^[ゃ-よャ-ヨ]/, "Y"],
        [/^[ら-ろラ-ロ]/, "R"],
        [/^[わをワヲ]/, "W"],
        [/^[んン]/, "N"],
      ];

      // マッチしたら即格納
      for (const [pattern, val] of rules) {
        const match = firstChar.match(pattern);
        if (match) {
          this.#generateName = typeof val === "function" ? val(match) : val;
          return;
        }
      }
      // 適合パターンがなければ空
      this.#generateName = "";
    }

    /**
     * カタカナをひらがなに変換する
     * @param {string} char - 対象文字列
     * @returns {string} ひらがな文字列
     */
    hiraTransform(char) {
      return char.replace(/[ァ-ヶ]/g, (match) =>
        String.fromCharCode(match.charCodeAt(0) - 0x60)
      );
    }

    /**
     * ひらがなをカタカナに変換する
     * @param {string} char - 対象文字列
     * @returns {string} カタカナ文字列
     */
    kanaTransform(char) {
      return char.replace(/[ぁ-ゖ]/g, (match) =>
        String.fromCharCode(match.charCodeAt(0) + 0x60)
      );
    }

    /** カタカナ変換 */
    generateHira() {
      this.#generateName = this.hiraTransform(this.#generateName);
    }

    /** ひらがな変換 */
    generateKana() {
      this.#generateName = this.kanaTransform(this.#generateName);
    }

    /** カナMix変換 */
    generateMix() {
      // 加工済みの名前文字列で文字を配列分割
      const split = this.nameSplit(this.#generateName);
      this.#generateName = split
        .map((v, i) =>
          i % 2 === 0 ? this.kanaTransform(v) : this.hiraTransform(v)
        )
        .join("");
    }
  }

  class TextRenderer$1 {
    /**
     * @type {string} 名前変換前のテキストを記録する属性名
     */
    static #beforeMap = "data-charm-before";

    /**
     * @type {Object.<string, string[]>} 名前IDごとに記録された変換前の文字列リスト
     */
    static #beforeList = {};

    /**
     * @type {Object.<string, HTMLCollection>} 名前IDごとの対象DOMエレメント
     */
    static #elements = {};

    /**
     * 初期化処理：全変換対象を初期化し、最新の状態に更新する
     */
    static setup() {
      this.ini();
      this.update();
    }

    /**
     * 内部状態（beforeList, elements）を初期化し、画面の文字もリセットする
     */
    static ini() {
      this.resetAllTextElements();
      this.#beforeList = [];
      this.#elements = {};
    }

    /**
     * 名前IDを指定してその対象エレメントだけ更新するか、指定がなければ全エレメントを更新対象として処理する
     * @param {string|null} nameId - 更新対象の名前ID（未指定時は全体を処理）
     */
    static update(nameId = null) {
      if (nameId) {
        // 登録後の名前
        this.#elements[nameId] = document.getElementsByClassName(nameId);
        this.#processingTargetNameId(nameId);
        return;
      }

      this.#getElements();
    }

    /**
     * 全ての登録済みnameIdに対して、対応するエレメントを取得し処理を行う
     * @private
     */
    static #getElements() {
      let charm = CharmStorage.charm;

      for (const nameId in charm) {
        if (charm.hasOwnProperty(nameId)) {
          this.#elements[nameId] = document.getElementsByClassName(nameId);
          this.#processingTargetNameId(nameId);
        }
      }
    }

    /**
     * 指定されたnameIdのエレメントを処理し、テキスト置換を実行する
     * - 元のテキストを記録
     * - data属性で変換管理
     * @private
     * @param {string} nameId - 処理対象の名前ID
     */
    static #processingTargetNameId(nameId) {
      const elements = this.#elements[nameId];

      // nameIdが未登録の場合に空配列で初期化
      if (!this.#beforeList[nameId]) {
        this.#beforeList[nameId] = [];
      }

      for (let i = 0; i < elements.length; i++) {
        const elm = elements[i];

        // 置換前にデフォルト表示が内部保持の連携Map値を取得
        const beforeData = elm.getAttribute(`${this.#beforeMap}`);

        // 変換前Map値がdata設定されていない場合
        if (!beforeData) {
          const text = elm.textContent;
          // 変換前文字列がmapに既出かチェック
          if (!this.#beforeList[nameId].includes(text)) {
            this.#beforeList[nameId].push(text);
          }

          const beforeIndex = this.#beforeList[nameId].indexOf(text);
          elm.setAttribute(this.#beforeMap, beforeIndex);
        }

        const newText = CharmStorage.charm[nameId];
        this.#replaceText(elm, newText);
      }
    }

    /**
     * テキスト変換処理を実行し、カスタム設定がある場合は反映させる
     * @private
     * @param {Element} elm - 対象のDOM要素
     * @param {string} text - 設定する変換テキスト
     */
    static #replaceText(elm, text) {
      let newText = text;

      // カスタム変換指定を取得
      const custom = new CustomOptions(elm.dataset, elm.classList);

      // カスタム変換指定を通して名前を加工（無指定の場合は加工されない）
      const nameGen = new NameGeneration(text, custom.custom);
      newText = nameGen.gName;

      // 要素の内容を変換後の名前に更新
      this.safelySetText(elm, newText);
    }

    /**
     * 全ての変換対象タグを元のテキストに戻す（beforeListベース）
     */
    static resetAllTextElements() {
      let list = this.#beforeList;
      for (const nameId in list) {
        if (list.hasOwnProperty(nameId)) {
          this.resetRowTextElements(nameId);
        }
      }
    }

    /**
     * 指定されたnameIdの変換対象を元に戻す
     * @param {string} nameId - 対象の名前ID
     */
    static resetRowTextElements(nameId) {
      if (!this.#beforeList[nameId]) return;
      const elms = document.querySelectorAll(`.${nameId}[${this.#beforeMap}]`);
      this.resetTextElements(elms, nameId);
    }

    /**
     * 特定の要素集合に対して変換前のテキストを復元する
     * @param {NodeListOf<Element>} elms - 対象のDOM要素群
     * @param {string} nameId - 名前ID
     */
    static resetTextElements(elms, nameId) {
      elms.forEach((elm) => {
        const beforeIndex = parseInt(elm.getAttribute(`${this.#beforeMap}`));
        this.safelySetText(elm, this.#beforeList[nameId][beforeIndex]);
        // 属性を動的に削除
        elm.removeAttribute(this.#beforeMap);
      });
    }

    /**
     * セッション登録時にメッセージを表示または非表示にする
     * @param {boolean} isShow - メッセージを表示するかどうか
     */
    static setSessionMessage(isShow = true) {
      // 一時登録テキスト表示エリアエレメント
      let ssnMsg = document.getElementById(Charm.viewRegisterSession);
      if (!ssnMsg) return;
      ssnMsg.textContent = isShow ? Charm.sessionString : "";
    }

    /**
     * テキストを安全にエスケープしてDOMに挿入する
     * @param {Element} elm - 対象DOM要素
     * @param {string} text - 設定するテキスト
     */
    static safelySetText(elm, text) {
      if (!elm) {
        console.warn("safelySetText: 無効な要素が渡されました");
        return;
      }

      const parser = new DOMParser();
      // DOMParserを使用して、エンティティ化された文字列を解析
      const doc = parser.parseFromString(text, "text/html");
      // 解析結果から安全なテキストを取得
      // もし何らかの理由でtextContentが空であれば、空文字列をデフォルト値として使用
      elm.textContent = doc.body.textContent || "";
    }
  }

  // グローバル登録
  globalThis.CharmInput = CharmInput$1;
  globalThis.CharmRunner = CharmRunner;
  globalThis.CharmStorage = CharmStorage$1;
  globalThis.CUtil = CUtil;
  globalThis.CustomOptions = CustomOptions$1;
  globalThis.NameGeneration = NameGeneration$1;
  globalThis.TextRenderer = TextRenderer$1;

  // 起動処理
  document.addEventListener("DOMContentLoaded", () => {
    try {
      window.Charm?.run();
    } catch (e) {
      console.error("Charm.run() failed:", e);
    }
  });

})();


/*! - 拡張用コードは以下に追記するか、外部ファイルとしてcharm.jsの後に読み込み - */