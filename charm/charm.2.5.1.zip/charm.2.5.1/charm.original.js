/*!
 * Charm.js License (Revised January 14, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/charm/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */

// Charm.js ver 2.5

class Charm {
  
  /***************      設定変更可能 ここから      ***************/
  // 登録する名前の入力フォームアイテム共通Class
  static nameClass = 'charm';
  // 登録ボタンのId
  static setNameId = 'charmset';
  // 一時登録ボタンのId
  static setSessionId = 'charmsession';
  // 削除ボタンのId
  static unsetNameId = 'charmunset';
  // 一時登録の表記をするid
  static viewRegistSession = 'charmsessionmsg';
  // 一時保存の際に表示できるメッセージ
  static sessionString = '（一時保存しました）';
  
  // localStorageまたはsessionStorageの保存キー
  static storageKeyName = 'charm';

  // 登録できる最大文字数
  // この文字数を超える文字は「…」として登録されます。この機能を使用しない場合は0を設定します。
  static maxSize = 50;

  // 名前登録時にページを再読み込みをするかどうか
  // 再読み込みをする場合は1、再読み込みをしない場合は0を設定してください。
  static setReload = 0;
  // 名前削除時にページを再読み込みをするかどうか
  // 再読み込みをする場合は1、再読み込みをしない場合は0を設定してください。
  static unsetReload = 1;
  // 名前登録時、ブラウザの設定で「Web Storage」が使えないときにウィンドウを出すかどうか
  // 出す場合は1を設定します。
  static showStorageError = 0;

  // 響き（欠けた名前を連呼する）回数のデフォルト
  static echoCountDefault = 2;
  // 詰まり回数のデフォルト
  static sttCountDefault = 2;
  
  // クラスモード使用時に設定するクラス名
  static charmClassList = {
    // 名前省略（1文字）
    charmShort : 'charm_short',
    // 先頭文字スキップ
    charmSkip : 'charm_skip',
    // 区切り
    charmParse : 'charm_pause',
    // 響き
    charmEcho : 'charm_echo',
    // 詰まり
    charmStutter : 'charm_stutter',
    // カタカナ変換
    charmKana : 'charm_kana',
    // charmKana : 'c_kn',
    // 最後の母音
    charmVowel : 'charm_vowel',
    // 最後の母音（小さい文字）
    charmVowelMin : 'charm_vowel_min',
    // 記号設定の共通部分
    charmSymbol : 'charm_symbol',
    // 回数設定の共通部分
    charmCount : 'charm_count',
  }
  // クラスモード使用時に設定する記号
  static symbols = [
    '&#8230;&#8230;', // ……
    '&#8230;', // …
    '&#12540;', // ー
    '&#8213;&#8213;', // ――
    '&#12336;&#12336;', // 〰〰
    '&#12336;', // 〰
    '&#12316;', // 〜
    '&#65281;', // ！
    '&#65281;&emsp;', // ！　（！の後ろに全角スペース）
    '&#65311;', // ？
    '&#65311;&emsp;', // ？　（？の後ろに全角スペース）
    '&#63;', // 半角の「?」
    '&#33;', // 半角の「!」
    '&#12289;', // 、
    '&#12290;', // 。
    '&#12539;', // ・
    '&#44;', // ,
    '&#65292;', // ，
    '&#8741;', // ∥
    '&#47;', // /
    '&#65295;', // ／
    '&#9675;&#9675;', // ○○
    '&#9675;', // ○
    '&#215;&#215;', // ××
    '&#215;', // ×
    '&#9734;&#9734;', // ☆☆
    '&#9734;', // ☆
    '&#9733;&#9733;', // ★★
    '&#9733;', // ★
    '&#9825;&#9825;', // ♡♡
    '&#9825;', // ♡
    '&#9734;&emsp;', // ☆（☆の後ろに全角スペース）
    '&#9733;&emsp;', // ★（★の後ろに全角スペース）
    '&#9825;&emsp;', // ♡（♡の後ろに全角スペース）
    '&#9834;', // ♪
    '&#9834;&emsp;', // ♪（♪の後ろに全角スペース）
    '&#65281;&#65311;', // ！？
    '&#65281;&#65311;&emsp;', // ！？（！？の後ろに全角スペース）
    '&#x3063;', // 「っ」
    '&#x3063;&#65281;', // 「っ！」
    '&#x3063;&#65281;&emsp;', //「っ！　」
    '&#x3063;&#12289;', // 「っ、」
    '&#x3063;&#8230;&#8230;', // 「っ……」
    '&#x30c3;', // 「ッ」
    '&#x30c3;&#65281;', // 「ッ！」
    '&#x30c3;&#65281;&emsp;', //「ッ！　」
    '&#x30c3;&#12289;', // 「ッ、」
    '&#x30c3;&#8230;&#8230;', // 「ッ……」
  ];

  /************** v1.2以前の設定ここから **************/
  // 登録ボタンのId
  static oldSetName = 'charm-setname';
  // 削除ボタンのId
  static oldUnsetName = 'charm-unsetname';

  /*************** 設定変更可能 ここまで 以降の行はシステム部分のため、触らないでください *******/

  constructor() {
    this.symbol = {}; // この行は触らない
    // 登録した名前
    this.charm = {};
    // ファイル内保持の名前（Storage無効対策）
    this.tmpCharm = {};
    // sessionStorageからの名前読み込みの場合はtrue
    this.isSession = false;
    // 変換前のデフォルトtextContent
    this.beforeList = [];
    // クラスモード使用時に呼び出す回数オプション
    this.countOption = {};
    for (let i = 1; i <= 9; i++) {
        this.countOption[`n${i}`] = i;
    }
    // data指定の詰まりデフォルト文字
    this.strStutter = '&#12289;'; // 、
    // data指定の区切り、響きデフォルト文字
    this.strPauseEcho = '&#8230;&#8230;'; // ……
    // 変換前の文字列マッピング用data
    this.attributeBeforeName = 'data-charm-before';
    // 母音判定の分類
    this.vowels = {};
    this.vowels.patternA1 = /[あかさたなはまやらわがざだばぱゃぁゕゎ]/;
    this.vowels.patternA2 = /[アカサタナハマヤラワガザダナパァヵㇵャㇻヮ]/;
    this.vowels.patternI1 = /[いきしちにひみりゐぎじぢびぃヰ]/;
    this.vowels.patternI2 = /[イキシチニヒミリギジヂビィㇱㇶㇼ]/;
    this.vowels.patternU1 = /[うくすつぬふむゆるぐずづぶぷゅぅっ]/;
    this.vowels.patternU2 = /[ウクスヌヌフムユルグズヅブプュゥㇰㇲッㇴㇷㇽ]/;
    this.vowels.patternE1 = /[えけせてねへめれゑげぜでべぺぇゖ]/;
    this.vowels.patternE2 = /[エケセテネヘメレゲゼデベペェヶㇸㇾ]/;
    this.vowels.patternO1 = /[おこそとのほもよろをごぞどぼぽょぉ]/;
    this.vowels.patternO2 = /[オコソトノホモヨロヲゴゾドボポョォㇳㇹㇺㇿ]/;
    this.vowels.patternN = /[んー〜ン]/;
    this.repVowelsUppercase = ['あ', 'ア', 'い', 'イ', 'う', 'ウ', 'え', 'エ', 'お', 'オ'];
    this.repVowelsLowercase = ['ぁ', 'ァ', 'ぃ', 'ィ', 'ぅ', 'ゥ', 'ぇ', 'ェ', 'ぉ', 'ォ'];
    // 配列をループしてオブジェクトにキーと値を追加
    Charm.symbols.forEach((code, index) => {
      this.symbol[`c${String(index + 1).padStart(2, '0')}`] = code;
    });
    this.nameTransformation = new NameTransformation(this);
  }

  static run =()=> {
    let instance = new Charm();
    instance.start();
    return instance;
  }

  start =()=> {
    // 過去に使用していたCookieを削除（過去版対応）
    let charmCookie = document.cookie;
    if (charmCookie) {
      let cookieNames = charmCookie.split('; ');
      let date = new Date();
      date.setTime(date.getTime() - 60 * 60 * 24 * 1000); // 1日前の日付を設定

      cookieNames.forEach(cookie => {
        let pair = cookie.split('='); // [=]区切りで配列にする
        document.cookie = decodeURIComponent(pair[0]) + '=; path=/; expires=' + date.toUTCString(); // 空の情報をセット
      });
    }
    const buttonActions = [
      { newId: Charm.setNameId, oldId: Charm.oldSetName, handler: this.setNameHandler(true) },
      { newId: Charm.setSessionId, oldId: null, handler: this.setNameHandler(false) }, // 一時登録は過去仕様がない
      { newId: Charm.unsetNameId, oldId: Charm.oldUnsetName, handler: this.unsetNameHandler }
    ];
  
    buttonActions.forEach(({ newId, oldId, handler }) => {
      let button = document.getElementById(newId);
      if (!button && oldId) {
        // 新仕様のIDでボタンが見つからない場合、過去のIDをチェック
        button = document.getElementById(oldId);
      }
      if (button) {
        button.removeEventListener('click', handler, false); // 既存のリスナーを削除
        button.addEventListener('click', handler, false); // リスナーを再登録
      }
    });
  
    this.viewName();
  }

  /**
   * ストレージから名前を削除
   * このメソッドは、ローカルストレージとセッションストレージの両方から名前を削除し、
   * ページを再読み込みします。主に名前削除イベントで使用されます。
   */
  unsetStorage =()=> {
    // 入力エリア削除処理
    const elements = document.querySelectorAll('.' + Charm.nameClass);
    elements.forEach(element => {
        element.value = '';
    });
    if (!this.charm && !this.tmpCharm) {
      return;
    }
    // ストレージ削除処理
    try { 
      localStorage.removeItem(Charm.storageKeyName);
      sessionStorage.removeItem(Charm.storageKeyName);
    } catch (e) {
      // Storageアクセス不可
    }
    if (Charm.unsetReload) {
      // 再読み込み
      location.reload(true);
    } else {
      // 再読み込みせずにdata属性から再セット
      this.resetElements();
    }
    this.beforeList = [];
  }
  // data属性から再セット
  resetElements = () => {
    const elements = document.querySelectorAll(`[${this.attributeBeforeName}]`);
    elements.forEach(element => {
      const beforeIndex = parseInt(element.getAttribute(`${this.attributeBeforeName}`));
      this.writeText(element, this.beforeList[beforeIndex]);
      element.removeAttribute(this.attributeBeforeName); // 属性を動的に削除
    });
    // 一時登録テキスト表示エリアエレメント
    let sessionMsg = document.getElementById(Charm.viewRegistSession);
    sessionMsg.textContent = '';
    this.beforeList = this.charm = this.tmpCharm = {};
  }
  setNameHandler = (isLocal) => {
    return () => {
      if (this.setStorage(isLocal)) {    
        this.viewName();
      }
    };
  }
  unsetNameHandler =()=> {
    this.unsetStorage();
  }
  /**
   * ローカルストレージまたはセッションストレージに名前を設定
   * このメソッドは、ユーザーが入力した名前をローカルストレージまたはセッションストレージに保存します。
   * エスケープ処理と文字数の制限もこのメソッド内で行われます。
   * 
   * @param {boolean} isLocal - trueの場合はローカルストレージ、falseの場合はセッションストレージに保存します。
   * @return {boolean} 保存が成功したかどうか。
   */
  setStorage =(isLocal = true)=> {
    // 入力要素を取得
    let nameItems = document.getElementsByClassName(Charm.nameClass);
    // LocalStorageに登録するobject
    let nameObj = {};
    // nameClassで指定したclassをもっている要素（input想定）のループ
    // 指定classの数だけループして id = value のペアをセット
    for (let i = 0; i < nameItems.length; i++) {
      let name = nameItems[i];
      if (!name || name.value.length < 1) {
        continue;
      }
      let nameString = name.value;
      // 文字数が登録上限数を超えていた場合はカットして丸める
      if (Charm.maxSize !== undefined && Charm.maxSize !== 0 && nameString.length > Charm.maxSize) {
        nameString = nameString.slice(0, Charm.maxSize) + '…';
      }
      // 保存用objectにも仮objectにも格納
      nameObj[name.id] = this.tmpCharm[name.id] =encodeURIComponent(nameString);
    }

    try {
      // 利用する方のStorage
      let validStorage = (isLocal) ? localStorage : sessionStorage;
      // 利用しない方のStorage
      let invalidStorage = (isLocal) ? sessionStorage : localStorage;
      validStorage.setItem(Charm.storageKeyName, JSON.stringify(nameObj));
      invalidStorage.removeItem(Charm.storageKeyName);
      if (Charm.setReload) location.reload(true); // 再読み込み
    } catch (e) {
      if (Charm.showStorageError) {
        alert('Web Storageが利用できません。ブラウザの設定を確認してください。');
      }
    }
    return true;
  }
  viewName = () => {
    this.readName();
    if (this.charm) {
      for (const key in this.charm) {
        this.replaceEdit(key, this.charm[key]);
        this.setFormName(key);
      }      
      this.setSessionMessage();
    }
  }
  /**
   * 名前置換メインメソッド
   *    表示メソッドviewName()から呼び出して使用
   *    置換先要素を取得、設定に合わせた置換処理を通して置換先要素にセットする
   * @param {String} key  登録情報配列のkey
   * @param {String} name 登録情報配列のvalue
   */
  replaceEdit(key, name) {
    // 名前が空の場合は何もせずに戻る
    if (!name) return;
  
    // 指定されたクラス名を持つ要素をすべて選択し、配列に変換する
    const elements = Array.from(document.getElementsByClassName(key));
    elements.forEach(element => {
      // 名前を変換ルールに従って変換する前の準備
      let splitName = this.nameTransformation.nameSplit(name);
      let rName = name;
      const classList = element.classList;
      const dataset = element.dataset;
      let isProcessed = false;
  
      // 変換ルールを定義する
      const transformations = [
        {
          check: () => this.nameTransformation.checkCharmShort(dataset, classList),
          action: repNum => this.nameTransformation.replaceShortArray(splitName, repNum).join(''),
        },
        {
          check: () => this.nameTransformation.checkCharmSkip(dataset, classList),
          action: repNum => this.nameTransformation.replaceSkipArray(splitName).join(''),
        },
        {
          check: () => !isProcessed && this.nameTransformation.checkCharmPause(dataset, classList),
          action: pause => splitName.join(pause),
        },
        {
          check: () => !isProcessed && this.nameTransformation.checkCharmEcho(dataset, classList),
          action: echo => {
            const echoCount = this.nameTransformation.getEchoSttCount(dataset, classList, true);
            return this.nameTransformation.replaceEcho(splitName, echo, echoCount);
          }
        },
        {
          check: () => !isProcessed && this.nameTransformation.checkCharmStutter(dataset, classList),
          action: stutter => {
            const stutterCount = this.nameTransformation.getEchoSttCount(dataset, classList, false);
            return this.nameTransformation.replaceStutter(splitName[0], stutter, stutterCount);
          }
        },
        {
          check: () => !isProcessed && this.nameTransformation.checkLastVowel(dataset, classList, rName),
          action: vowel => vowel,
        },
        {
          check: () => this.nameTransformation.checkReplaceKana(dataset, classList),
          action: () => this.nameTransformation.replaceKana(rName),
          final: true // 最終的な変換を示すフラグ
        }
      ];
  
      // 定義した変換ルールを適用する
      transformations.forEach(transformation => {
        if (transformation.check()) {
          rName = transformation.action(transformation.check());
          isProcessed = !transformation.final; // 最終変換以外では処理済みとマーク
        }
      });
  
      // 条件に応じて変換前の内容を保存
      this.setBeforeStrIndex(element);
      
      // 要素の内容を変換後の名前に更新
      this.writeText(element, rName);
    });
  }

  /**
   * 指定されたElementに、エンティティ化された文字列を安全にテキストとして挿入
   * 
   * @param {Element} element - テキストを挿入する対象のDOM Element
   * @param {string} rName - 置換後にセットする予定の名前文字列
   */
  writeText =(element, rName)=> {
    const parser = new DOMParser();
    // DOMParserを使用して、エンティティ化された文字列を解析
    const doc = parser.parseFromString(rName, 'text/html');
    // 解析結果から安全なテキストを取得
    // もし何らかの理由でtextContentが空であれば、空文字列をデフォルト値として使用
    const safeText = doc.body.textContent || "";
    element.textContent = safeText;
  }

  /**
   * 変換前の文字を内部に保持する
   * @param {element} element
   */
  setBeforeStrIndex = (element) => {
    // 登録削除時にリロードする設定の場合は以降の処理を行わない
    if (Charm.unsetReload) return;
    const elementBeforeIndex = element.getAttribute(this.attributeBeforeName);
    // 変換前の文字を内部保存する前の場合は保持する（登録と一時登録を繰り返す場合の対処）
    if (elementBeforeIndex === null || elementBeforeIndex === '') {
      const beforeIndex = this.beforeList.length;
      this.beforeList[beforeIndex] = element.textContent;
      element.setAttribute(this.attributeBeforeName, beforeIndex);
    }
  }

  /**
   * 登録してある名前を取得する
   *    viewName()から呼び出して使用
   */
  readName = () => {
    this.isSession = false;
    let getItem = null;
    // JS上に格納したデータkey
    let charmTmpKeys;
  
    // localStorageとsessionStorageからのデータ取得を試みる
    try {
      getItem = JSON.parse(localStorage.getItem(Charm.storageKeyName));
      if (!getItem) {
        getItem = JSON.parse(sessionStorage.getItem(Charm.storageKeyName));
        this.isSession = !!getItem;
      }
    } catch (e) {
      // localStorageまたはsessionStorageへのアクセスに失敗
      charmTmpKeys = Object.keys(this.tmpCharm);
      // データが登録も登録操作もされていなければそれ以上処理しない
      if (!getItem && charmTmpKeys.length < 1) {
        return;
      }
      // データは登録されていないが、登録操作はあった場合（Storage無効対策）
      if (!getItem && charmTmpKeys.length > 0) {
        charmTmpKeys.forEach(key => this.charm[key] = decodeURIComponent(this.tmpCharm[key]));
      }
      return;
    }
    if (getItem === null) {
      return;
    }
    // データが登録されている場合
    Object.keys(getItem).forEach(key => this.charm[key] = decodeURIComponent(getItem[key]));
  }

  /**
   * 一時登録メッセージを表示する（セッション保存専用）
   */
  setSessionMessage = () => {
    // 表示エリアエレメント
    let sessionMsg = document.getElementById(Charm.viewRegistSession);
    if (sessionMsg !== null) {
      if (this.isSession) {
        sessionMsg.textContent = Charm.sessionString;
      } else {
        sessionMsg.textContent = '';
      }
    }
  }
  /**
   * 入力フォームに登録内容を挿入する
   * @param {String} key 登録key名 
   */
  setFormName = (key) => {
    let formItem = document.getElementById(key);
    // keyの入力フォームが取得できないときはスキップ
    if (!formItem) {
      return;
    }
    formItem.value = this.charm[key];
  }
}

class NameTransformation {
  constructor(charmInstance) {
    this.Charm = charmInstance;
  }

  /**
   * classListからオプション回数の値を取得するメソッド
   * @param {element.classList} classList 置換対象のclassリスト
   * @return {Boolean or integer} 回数指定がない場合はfalse, 指定があれば数値
   */
  getOptCount =(classList)=> {
    // オプション回数のキーを取得
    const countOptAry = Object.keys(this.Charm.countOption);
    // 条件を満たす最初のキーを探す
    const foundKey = countOptAry.find(key => {
      // 検索対象のクラス名を生成（'charm_count' + 通し番号下一桁）
      let symbolIndex = Charm.charmClassList.charmCount + key.slice(-1);
      // classListに含まれるかチェック
      return classList.contains(symbolIndex);
    });

    // 条件を満たすキーが見つかったら、そのオプション回数を返す。そうでなければfalseを返す
    return foundKey ? this.Charm.countOption[foundKey] : false;
  }
  /**
   * classListから記号を取得するメソッド
   * @param {element.classList} classList 置換対象のclassリスト
   * @return {Boolean or String} 記号指定がない場合はfalse, 指定があればエンコード文字列
   */
  getSymbol =(classList)=> {
    // 記号のキーを取得
    const symbolKeyAry = Object.keys(this.Charm.symbol);
    // 条件を満たす最初のキーを探す
    const foundKey = symbolKeyAry.find(key => {
      // 検索対象のクラス名を生成（'charm_symbol' + 記号リストの通し番号下二桁）
      let symbolIndex = Charm.charmClassList.charmSymbol + key.slice(-2);
      // classListに含まれるかチェック
      return classList.contains(symbolIndex);
    });

    // 条件を満たすキーが見つかったら、その記号を返す。そうでなければfalseを返す
    return foundKey ? this.Charm.symbol[foundKey] : false;
  }
  /**
   * 響き回数 または 詰まり回数判定メソッド
   *    名前置換メインメソッドreplaceEdit()から呼び出して使用
   * @param {element.dataset} dataset  置換対象のdataリスト
   * @param {element.classList} classList 置換対象のclassリスト
   * @param {boolean} isEcho 置換対象のclassリスト
   * @return {String} 指定の響き回数またはデフォルト回数を返却
   */
  getEchoSttCount = (dataset, classList, isEcho = true) => {
    let num = 1;
    let defaultCount = isEcho ? Charm.echoCountDefault : Charm.sttCountDefault;
    // データで響き回数指定
    if (isEcho && dataset.charmEchCount) {
      // dataにセットされている値を数値化できない場合はデフォルトの回数とする
      num = parseInt(dataset.charmEchCount) ? parseInt(dataset.charmEchCount) : defaultCount;
      return num;
    };
    // データで響き回数指定
    if (!isEcho && dataset.charmSttCount) {
      // dataにセットされている値を数値化できない場合はデフォルトの回数とする
      num = parseInt(dataset.charmSttCount) ? parseInt(dataset.charmSttCount) : defaultCount;
      return num;
    };
    // クラス指定があるか検索
    num = this.getOptCount(classList);
    return num ? num : Charm.echoCountDefault;
  }
  /**
   * 名前省略指定判定と、出力文字数判定メソッド
   *    名前置換メインメソッドreplaceEdit()から呼び出して使用
   * @param {element.dataset} dataset  置換対象のdataリスト
   * @param {element.classList} classList 置換対象のclassリスト
   * @return {Boolean or integer} 処理不要の場合はfalse, 処理対象の場合は出力文字数
   */
  checkCharmShort =(dataset, classList)=> {
    let num = 1;
    // データで名前省略指定
    if (dataset.charmShort && parseInt(dataset.charmShort)) {
      // dataにセットされている値を数値化できない場合は1文字の省略とする
      num = parseInt(dataset.charmShort) ? parseInt(dataset.charmShort) : 1;
      return num;
    };
    // クラスでの名前省略指定が無い場合
    if (!classList.contains(Charm.charmClassList.charmShort)) {
      return false;
    }
    // 省略表示の指定があるか検索
    num = this.getOptCount(classList);
    return num ? num : 1;
  }
  /**
   * 名前省略指定判定と、出力文字数判定メソッド
   *    名前置換メインメソッドreplaceEdit()から呼び出して使用
   * @param {element.dataset} dataset  置換対象のdataリスト
   * @param {element.classList} classList 置換対象のclassリスト
   * @return {Boolean or integer} 処理不要の場合はfalse, 処理対象の場合は出力文字数
   */
  checkCharmSkip =(dataset, classList)=> {
    // データで名前省略指定
    if (dataset.charmSkip || classList.contains(Charm.charmClassList.charmSkip)) {
      return true;
    };
    return false;
  }
  /**
   * 区切り指定判定と、区切り文字判定メソッド
   *    名前置換メインメソッドreplaceEdit()から呼び出して使用
   * @param {element.dataset} dataset  置換対象のdataリスト
   * @param {element.classList} classList 置換対象のclassリスト
   * @return {Boolean or String} 処理不要の場合はfalse, 処理対象の場合は区切り文字
   */
  checkCharmPause = (dataset, classList) => {
    // データで区切り指定
    if (dataset.charmCall === 'pause') {
      return dataset.charmBreak ? dataset.charmBreak : this.Charm.strPauseEcho;
    }
    // クラスでの区切り指定もない場合は処理不要として返却
    if (!classList.contains(Charm.charmClassList.charmParse)) {
      return false;
    }
    // 区切り文字の指定があるか検索
    let str = this.getSymbol(classList);
    return str ? str : this.Charm.strPauseEcho;
  }
  /**
   * 響き指定判定と、響き文字判定メソッド
   *    名前置換メインメソッドreplaceEdit()から呼び出して使用
   * @param {element.dataset} dataset  置換対象のdataリスト
   * @param {element.classList} classList 置換対象のclassリスト
   * @return {Boolean or String} 処理不要の場合はfalse, 処理対象の場合は響き文字
   */
  checkCharmEcho = (dataset, classList) => {
    // データで響き指定
    if (dataset.charmCall === 'echo') {
      return dataset.charmBreak ? dataset.charmBreak : this.Charm.strPauseEcho;
    }
    // クラスでの響き指定もない場合は処理不要として返却
    if (!classList.contains(Charm.charmClassList.charmEcho)) {
      return false;
    }
    // 響き文字の指定があるか検索
    let str = this.getSymbol(classList);
    return str ? str : this.Charm.strPauseEcho;
  }
  /**
   * 詰まり指定判定と、詰まり文字判定メソッド
   *    名前置換メインメソッドreplaceEdit()から呼び出して使用
   * @param {element.dataset} dataset  置換対象のdataリスト
   * @param {element.classList} classList 置換対象のclassリスト
   * @return {Boolean or String} 処理不要の場合はfalse, 処理対象の場合は詰まり文字
   */
  checkCharmStutter = (dataset, classList) => {
    // データで詰まり指定
    if (dataset.charmCall === 'stutter') {
      return dataset.charmBreak ? dataset.charmBreak : this.Charm.strStutter;
    }
    // クラスでの区切り指定もない場合は処理不要として返却
    if (!classList.contains(Charm.charmClassList.charmStutter)) {
      return false;
    }
    // 詰まり文字の指定があるか検索
    let str = this.getSymbol(classList);
    return str ? str : this.Charm.strStutter;
  }
  /**
   * 母音指定判定と母音連結処理呼び出しメソッド
   *    名前置換メインメソッドreplaceEdit()から呼び出して使用
   * @param {element.dataset} dataset  置換対象のdataリスト
   * @param {element.classList} classList 置換対象のclassリスト
   * @return {Boolean or String} 処理不要の場合はfalse, 処理対象の場合は母音文字
   */
  checkLastVowel =(dataset, classList, rName)=> {
    // データでもクラスでも母音指定がなければ使用しない
    if (
      !dataset.charmVowel &&
      !dataset.charmVowelMin &&
      !classList.contains(Charm.charmClassList.charmVowel) &&
      !classList.contains(Charm.charmClassList.charmVowelMin)
    ) {
      return false;
    }
    // 最後の一文字
    let lastStr = rName.slice(-1);
    // 最後の母音
    let lastVowel = '';
    // 返す母音が大文字ならtrue
    let isUppercase = true;
    if (dataset.charmVowelMin || classList.contains(Charm.charmClassList.charmVowelMin)) {
      isUppercase = false;
    }
    // 母音のための各オブジェクトを一度配列にする
    const vowelsKeyAry = Object.keys(this.Charm.vowels);
    for (let i = 0; i < vowelsKeyAry.length; i++) {
      let pattern = new RegExp(this.Charm.vowels[vowelsKeyAry[i]]);
      // 最後の一文字が対象の母音に当てはまらない場合
      if (!lastStr.match(pattern)) { 
        continue;
      }
      if (i < vowelsKeyAry.length - 2) {
        // patternAからpatternOのうちに入っている場合
        lastVowel = isUppercase ? this.Charm.repVowelsUppercase[i] : this.Charm.repVowelsLowercase[i];
      } else {
        // vowels.patternNに当てはまる場合は最後の文字をそのまま返す
        lastVowel = lastStr;
      }
      break;
    }
    return this.concatVowel(dataset, classList, lastVowel);
  }

  /**
   * 母音連結処理
   * @param {element.dataset} dataset  置換対象のdataリスト
   * @param {element.classList} classList 置換対象のclassリスト
   * @param {String} lastVowel 母音
   * @returns 
   */
  concatVowel =(dataset, classList, lastVowel)=> {
    let num = 0;
    // クラスでの複数指定があるか検索
    const countClass = this.getOptCount(classList);
    // データでの複数指定があるか検索
    if (dataset.charmVowelCount) {
      num = parseInt(dataset.charmVowelCount) || 1;
    } else if (countClass) {
      num = countClass;
    } else {
      return lastVowel;
    }
    let contains = (num > 0) ? lastVowel.repeat(num + 1) : lastVowel;
    return contains;
  }

  /**
   * カタカナ変換判定メソッド
   *    名前置換メインメソッドreplaceEdit()から呼び出して使用
   * @param {element.dataset} dataset  置換対象のdataリスト
   * @param {element.classList} classList 置換対象のclassリスト
   * @return {Boolean} 処理不要の場合はfalse, 処理対象の場合はtrue
   */
  checkReplaceKana =(dataset, classList)=> {
    if (
      dataset.charmKana === 'on' ||
      dataset.charmKana == '1' ||
      classList.contains(Charm.charmClassList.charmKana)) {
      return true;
    }
    return false;
  }
  /**
   * 名前を自然な区切りの配列にして返す
   *    小さい「ぁ」や「っ」など、1文字で使用しない文字を考慮して区切る
   *    「あいうえお」   ->  ['あ', 'い', 'う', 'え', 'お']
   *    「しゃしゅ」    ->  ['しゃ', 'しゅ']
   * @param {String} name
   * @return {Array} 自然な区切り位置で分割した名前配列
   */
  nameSplit = (name) => {
    // 返却する自然な区切りの配列
    let splitName = [];
    // 小さい文字や特定の記号を識別するための正規表現
    const smallCharRegex = /[ぁぃぅぇぉゕゖっゃゅょゎァィゥェォヵㇰヶㇱㇲッㇳㇴㇵㇶㇷㇸㇹㇺャュョㇻㇼㇽㇾㇿヮｧｨｩｪｫｬｭｮｯ・ー]/;
    let i = 0; // 文字列を検査するためのインデックス
    while (i < name.length) { // 名前の全文字をチェック
      let pushString = name[i]; // 現在の文字を格納する変数
      i++; // 次の文字に移動
      // 次の文字が小さい文字や特定の記号であれば連結
      while (i < name.length && name[i].match(smallCharRegex)) {
        pushString += name[i];
        i++; // さらに次の文字に移動
      }
      // 処理した文字列を配列に追加
      splitName.push(pushString);
    }
    return splitName; // 分割結果を返す
  }
  /**
   * 名前の文字配列を減らす
   *    指定の文字列を、指定の数に丸めて配列で返す（末尾が[っ][ッ]の場合は削除）
   * @param   {Array}   splitName  名前文字配列
   * @param   {integer} num        減らした結果の文字数（デフォルトあり）
   * @return  {String}             減らした結果の文字配列
   */
  replaceShortArray = (splitName, num) => {
    // 名前の文字数が指定文字数未満の場合、そのまま返す
    if (splitName.length <= num) {
      return splitName;
    }
    // 指定された数に丸めた配列を取得
    let result = splitName.slice(0, num);
    // 末尾の文字が特定の文字の場合、削除
    result[num - 1] = result[num - 1].replace(/[\u3063\u30c3\u30FCｯ・]/g, '');
    return result;
  }
  /**
   * 先頭の1ブロックを省いた名前の文字配列を返す
   * @param   {Array}   splitName  名前文字配列
   * @return  {String}             減らした結果の文字配列
   */
  replaceSkipArray = (splitName) => {
    // 配列の先頭の要素を削除する
    splitName.shift();
    return splitName;
  }
  /**
   * 指定の組み合わせと回数で配列の名前を区切り、響きを返す
   * 
   * @param   {Array}     name        響きに使用する名前配列
   * @param   {String}    echoString  区切りの間に挿入する文字列（デフォルトあり）
   * @param   {integer}   echoCount   欠けた名前を連呼する回数（デフォルトあり）
   * @return  {String}                響き文字列
   */
  replaceEcho = (name, echoString, echoCount) => {
    // 返却文字列
    let result = echoString;
    let count;
    // 名前の文字数と、指定の響き回数の小さい方に合わせる
    if (name.length - 1 > echoCount) {
      count = echoCount;
    } else {
      count = name.length - 1;
    }
    // 呼びかけられる回数
    for (let i = 1; i <= count; i++) {
      // 名前の自然な文字数分ループ
      for (let j = 0; j < name.length; j++) {
        // 呼ぶ合計数から呼んだ回数を引いて、それより大きいkeyをその呼びかけにセットする
        if (j > count - i) {
          result += name[j];
        }
      }
      // 呼びかけ回数1巡　区切り文字で区切る
      result += echoString;
    }
    return result;
  }
  /**
   * 指定の組み合わせと回数で配列の名前を区切り、詰まり文字列を返す
   * 
   * @param   {String}      sttName       詰まりに使用する名前1区切り
   * @param   {String}      sttPause      詰まりに使用する区切り文字列
   * @param   {integer}     stutterCount  どもらせる回数（デフォルトあり）
   * @return  {String}                    詰まり文字列
   */
  replaceStutter = (sttName, pauseString, stutterCount) => {
    let result = '';
    for (let i = 0; i < stutterCount; i++) {
      if (i !== stutterCount - 1) {
        result += sttName + pauseString;
      } else {
        result += sttName;
      }
    }
    return result;
  }
  /**
   * ひらがな → カタカナ変換
   *    受け取った文字列のひらがな部分をカタカナに置換して返す
   * @param   {String}  name  名前文字列
   * @return  {String}        ひらがなをカタカナに置換した名前文字列
   */
  replaceKana = (name) => {
    // 当てはまるものを置換してreturn
    return name.replace(/[\u3041-\u3096]/g, (match)=> {
      let chr = match.charCodeAt(0) + 0x60;
      return String.fromCharCode(chr);
    });
  }
}

try {
  Charm.run();
} catch (error) {
  console.error('An error occurred while creating a Charm instance: ', error);
}
